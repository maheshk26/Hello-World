var helpers = require('ts-helpers');
require('ts-node/register');

exports.config = {
    params: {
        environment: 'dev'
    },

    seleniumAddress: '',

    ignoreUncaughtExceptions: true,

    framework: 'custom',
    // path relative to the current config file
    frameworkPath: require.resolve('protractor-cucumber-framework'),

    multiCapabilities: [{
        browserName: 'chrome-without-sandbox',
        shardTestFiles: false,
        maxInstances: 1,
        chromeOptions: {
          'args': ['--window-size=1440,1024', '--test-type', '--no-sandbox']
        }
      },{
      browserName: 'chrome',
      shardTestFiles: false,
      maxInstances: 1
    }],

    // Spec patterns are relative to this directory.
    specs: [
      'e2e/features/*.feature'
    ],

    exclude: [],

    cucumberOpts: {
        compiler: 'ts:ts-node/register',
        require: ["e2e/features/**/*.ts", "e2e/features/support/*.js"],
        tags: ["~@backlog","~@manual"],
        format: ['pretty', 'json:./reports/' + Date.now() + '.json'],
        profile: false,
        'no-source': true
    },

    beforeLaunch: function() {
        require('ts-node').register({
            project: 'e2e'
        });
        // clean up reports directory before starting
        clearReportsFolder();
    },

    onPrepare: function () {
        browser.params.data = require('./e2e/data/' + browser.params.environment + '.json');
        browser.driver.manage().window().maximize();
    },

    allScriptsTimeout: 110000,


    /**
     * Angular 2 configuration
     *
     * useAllAngular2AppRoots: tells Protractor to wait for any angular2 apps on the page instead of just the one matching
     * `rootEl`
     *
     */
    useAllAngular2AppRoots: true
};

var fs = require('fs');
var p = require("path");
var clearReportsFolder = function() {
    var path = "./reports";
    if( fs.existsSync(path) ) {
        fs.readdirSync(path).forEach(function(file,index){
            var curPath = p.join(path, file);
            fs.unlinkSync(curPath);
        });
        fs.rmdirSync(path);
    }
    fs.mkdirSync(path);
};
