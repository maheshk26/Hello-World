gitlabBuilds(builds: ['Npm Build', 'Unit Test']) {

  stage('Npm Build') {
    gitlabCommitStatus(name: 'Npm Build') {
      sh "npm install && npm run build 2>&1"
    }
  }

  stage('Unit Test') {
    gitlabCommitStatus(name: 'Unit Test') {
      sh "npm run test-pipeline"
    }
  }
}
