var myHooks = function () {

    this.setDefaultTimeout(30 * 1000);

    this.After(function(){
        function getWindowLocation() {
            return window.location;
        }

        function clearStorage() {
            window.sessionStorage.clear();
            window.localStorage.clear();
        }

        return browser.executeScript(getWindowLocation).then(function(location) {
            // If no page is loaded in the scneario then calling clearStorage will cause exception
            // so guard against this by checking hostname (If no page loaded then hostname == '')
            if (location.hostname.length > 0) {
                return browser.executeScript(clearStorage);
            }
            else {
                return Promise.resolve();
            }
        });
    });

    var outputDir = 'reports/';
    this.After(function(scenario, callback) {
        if (scenario.isFailed()) {
            // Don't need to print browser logs currently
            // browser.manage().logs().get('browser').then(function(browserLog) {
            //     console.log('Browser Log - ' + scenario.getName() + ':');
            //     console.log(require('util').inspect(browserLog));
            // });

            browser.takeScreenshot().then(function(png) {
                var decodedImage = new Buffer(png, 'base64');
                scenario.attach(decodedImage, 'image/png');
                callback();
            }, function(err) {
                callback(err);
            });
        } else {
            callback();
        }
    });

    var createHtmlReport = function(sourceJson) {
        var CucumberHtmlReport = require('cucumber-html-report');
        try {
            var report = new CucumberHtmlReport({
                source: sourceJson, // source json
                dest: outputDir // target directory (will create if not exists)
            });
            report.createReport();
        } catch (err) {
            console.log('Unable to set cucumber html report: ' + err);
        }
    };

    var Cucumber = require('cucumber'),
        fs = require('fs');
    path = require('path');
    var JsonFormatter = Cucumber.Listener.JsonFormatter();
    JsonFormatter.log = function(string) {
        if (string !== '[]') {
            if (!fs.existsSync(outputDir)) {
                fs.mkdirSync(outputDir);
            }

            var targetJson = outputDir + 'cucumber_report.json';
            // check if file exists already
            try {
                fs.statSync(targetJson);
                console.log("file already exists!");

                // remove trailing ']' and add ',' from existing file
                var existingFileContents = fs.readFileSync(targetJson, 'UTF-8');
                var modifiedFileContents = existingFileContents.replace(/]$/, "") + ",";

                // remove leading '[' from new string
                var modifiedString = string.replace(/^\[/, "");

                // create new contents with modified original content and modified string to append
                var newContents = modifiedFileContents + modifiedString;

                // write string to file
                fs.writeFile(targetJson, newContents, function (err) {
                    if (err) {
                        console.log('Failed to save cucumber test results to json file.');
                        console.log(err);
                    } else {
                        createHtmlReport(targetJson);
                    }
                });
            } catch (err) {
                console.log("file doesn't exist");
                fs.writeFile(targetJson, string, function (err) {
                    if (err) {
                        console.log('Failed to save cucumber test results to json file.');
                        console.log(err);
                    } else {
                        createHtmlReport(targetJson);
                    }
                });
            }
        }

    };

    this.registerListener(JsonFormatter);

};

module.exports = myHooks;

