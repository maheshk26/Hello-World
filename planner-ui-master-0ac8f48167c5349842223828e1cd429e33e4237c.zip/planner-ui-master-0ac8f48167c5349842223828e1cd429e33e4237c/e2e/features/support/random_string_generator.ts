export class RandomStringGenerator {

    public getRandomAlphaNumericString(length: number): string {
        let characterSet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

        let randomString = '';

        for (let i = 0; i < length; i++) {
            let randomPosition: number = Math.floor(Math.random() * characterSet.length);
            randomString += characterSet.substring(randomPosition, randomPosition + 1);
        }

        return randomString;
    }

    public getRandomString(length: number): string {
        let characterSet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';

        let randomString = '';

        for (let i = 0; i < length; i++) {
            let randomPosition: number = Math.floor(Math.random() * characterSet.length);
            randomString += characterSet.substring(randomPosition, randomPosition + 1);
        }

        return randomString;
    }

    public getRandomNumber(length: number, suppliedCharacterSet?: string): string {
        let characterSet: string = suppliedCharacterSet || '0123456789';

        let randomString = '';

        for (let i = 0; i < length; i++) {
            let randomPosition: number = Math.floor(Math.random() * characterSet.length);
            randomString += characterSet.substring(randomPosition, randomPosition + 1);
        }

        return randomString;
    }

    public getRandomNumberInRange(minimum: number, maximum: number): number {
      var randomnumber = Math.floor(Math.random() * (maximum - minimum + 1)) + minimum;
      return randomnumber;
    }
}
