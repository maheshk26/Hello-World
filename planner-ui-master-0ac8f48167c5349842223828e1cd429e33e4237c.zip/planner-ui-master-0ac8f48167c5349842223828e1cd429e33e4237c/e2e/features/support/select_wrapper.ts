import {by, element} from 'protractor';

export class SelectWrapper {

    private webElement: any;

    constructor(selector: any) {
        this.webElement = element(selector);
    }

    public getOptions(): Promise<any[]> {
        return this.webElement.all(by.tagName('option'));
    }

    public getSelectedOption(): Promise<string> {
        return this.webElement.$('option:checked').getText();
    }

    public getSelectedOptionValue(): Promise<string> {
        return this.webElement.$('option:checked').getAttribute('value');
    }

    public selectByPartialText(text: string): Promise<any[]> {
        return this.webElement.all(by.cssContainingText('option', text)).click();
    }

    public selectByText(text: string): Promise<any[]> {
        return this.webElement.all(by.xpath('option[.="' + text + '"]')).click();
    }

    public isEnabled(): Promise<any[]> {
        return this.webElement.isEnabled();
    }

    public isPopulated(): Promise<boolean> {
        return this.webElement.$('option:checked').isPresent();
    }
}
