let chai = require('chai');
chai.use(require('chai-as-promised'));

export { IWorld, World } from './world';
export var expect = chai.expect;
