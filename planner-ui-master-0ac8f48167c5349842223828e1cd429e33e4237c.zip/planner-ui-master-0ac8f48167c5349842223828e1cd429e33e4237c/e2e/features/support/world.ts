import {browser,protractor} from 'protractor';
import {ProfileDetails} from "../../models/profile_details";
import {EventDetails} from "../../models/event_details";

export function World() {
    this.currentUrl = () => browser.getCurrentUrl();
    this.defaultProfileDetails = () => new ProfileDetails();
    this.defaultEventDetails = () => new EventDetails();
}

export interface IWorld {
    currentUrl(): Promise<string>;
}

export function chain() {
  let defer = protractor.promise.defer();
  defer.fulfill(true);
  return defer.promise;
}

