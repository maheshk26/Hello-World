import {browser, protractor} from 'protractor';
import {expect} from '../support/asserts.config';
import {User} from '../../models/user';
import {BookingInformation} from '../../models/booking.information';
import {EventDetails} from "../../models/event_details";
import {ProfileDetails} from "../../models/profile_details";
import {BookingResponse} from "../../models/booking.response";
import {promise} from 'selenium-webdriver';

let ServiceCall = require('../support/service_calls.js');
let serviceCall = new ServiceCall();


export class ServiceUtils {

    private authToken: string;
    private xsrfToken: string;
    private baseApiUrl: string = browser.params.data.baseApiUrl;

    public getAuthToken(user: User) {
        let authLoginUrl: string = this.baseApiUrl + 'auth/login';

        function login(): Promise<any> {
            return serviceCall.httpPostJson(authLoginUrl, user);
        }

        let flow = protractor.promise.controlFlow();

        flow.execute(login).then((response) => {
            expect([200], 'Authentication failed: '
                + response.bodyString).to.include(response.statusCode);
            this.authToken = String(response.headers['set-cookie'][1]).match(/(.*);path=/)[1];
            this.xsrfToken = String(response.headers['set-cookie'][0]).match(/(.*);path=/)[1];
        });
    }

    public createEvent(date: string, bookingInfo: BookingInformation, centerId?: string) {
        let bookingUrl: string = this.baseApiUrl + 'booking/' + date;
        let authToken = this.authToken;
        let xsrfToken = this.xsrfToken;

        function create(): Promise<any> {
          if(centerId) {
            return serviceCall.httpPostJson(bookingUrl, bookingInfo, authToken, xsrfToken, centerId);
          } else {
            return serviceCall.httpPostJson(bookingUrl, bookingInfo, authToken, xsrfToken);
          }
        }

        let flow = protractor.promise.controlFlow();

        flow.execute(create).then((response) => {
            expect([200], 'Create event failed: '
                + JSON.stringify(response.bodyString)).to.include(response.statusCode);
        });
    }

    public getEvents(fromDate: string, toDate: string, isCenterAvailable?: boolean,profileInfo?:ProfileDetails) {
        let getEventsUrl: string = this.baseApiUrl + 'events?from=' + fromDate + '&to=' + toDate;
        let authToken = this.authToken;
        let xsrfToken = this.xsrfToken;

        function getEvents(): Promise<any> {
          if(isCenterAvailable) {
            let centerVal = profileInfo.centerId;
            getEventsUrl += getEventsUrl + '&locationId=' + centerVal + '&locationCode=' +'C';
            return serviceCall.httpGet(getEventsUrl,authToken,centerVal.trim());
          } else {
            return serviceCall.httpGet(getEventsUrl, authToken,);
          }
        }

        let flow = protractor.promise.controlFlow();

        return flow.execute(getEvents).then((response) => {
            expect([200], 'Get events failed: '
                + JSON.stringify(response.bodyString)).to.include(response.statusCode);
            let eventsJson: JSON = response.json['body'];
            return eventsJson;
        });
    }

    public chain() {
      var defer = protractor.promise.defer();
      defer.fulfill(true);
      return defer.promise;
    };

    public deleteEvent(bookingInfoId: string,isCenterAvailable?: boolean,profileInfo?:ProfileDetails) {
        let deleteEventUrl: string = this.baseApiUrl + 'booking/' + bookingInfoId;
        let authToken = this.authToken;
        let xsrfToken = this.xsrfToken;


      function deleteEvent(): Promise<any> {
        if(isCenterAvailable){
          let centerVal = profileInfo.centerId;
          return serviceCall.httpDeleteResource(deleteEventUrl, authToken, xsrfToken,centerVal)
        }
        else{
          return serviceCall.httpDeleteResource(deleteEventUrl, authToken, xsrfToken);
        }
      }

        let flow = protractor.promise.controlFlow();

        flow.execute(deleteEvent).then((response) => {
            expect([200], 'Delete event failed: '
                + JSON.stringify(response.bodyString)).to.include(response.statusCode);
        });
    }

  public bookSlotThroughApi(date: string,eventDetails: EventDetails, centerId?: string): void {
    let user: User = new User();
    user.username = browser.params.data.validHqUser.username;
    user.password = browser.params.data.validHqUser.password;

    let customerNameDisplayed = eventDetails.customerName;
    let bookingInfo = new BookingInformation();
    bookingInfo.customerName = eventDetails.customerName;
    bookingInfo.zipCode = eventDetails.zipCode;
    bookingInfo.orderNumber = eventDetails.orderNumber;
    bookingInfo.opportunityNumber = eventDetails.opportunityNumber;
    bookingInfo.estimateNumber = eventDetails.estimateNumber;
    bookingInfo.locationType = eventDetails.locationType;

    this.chain()
      .then(() => {
        this.getAuthToken(user);
      })
      .then(() => {
        this.createEvent(date, bookingInfo, centerId);
      });
  }

  public bookThroughApi(date: string): void {
    let user: User = new User();
    user.username = browser.params.data.validHqUser.username;
    user.password = browser.params.data.validHqUser.password;
    let bookingInfo = new BookingInformation();
      bookingInfo.customerName = 'Automation';
      bookingInfo.zipCode = '63049';
      bookingInfo.orderNumber = '111';
      bookingInfo.opportunityNumber= '333';
      bookingInfo.estimateNumber = '123';
      bookingInfo.locationType = 'ORIGIN';

      this.chain()
      .then(() => {
        this.getAuthToken(user);
      })
      .then(() => {
        this.createEvent(date, bookingInfo);
      });
  }

  public deleteSlotsThroughApi(user: User,fromDate: string, toDate: string,isCenterAvailable?: boolean,profileInfo?:ProfileDetails): Promise<any[]>{

    this.chain()
      .then(() => {
        this.getAuthToken(user);
      })
      .then(() => {
        return this.getEvents(fromDate, toDate, isCenterAvailable,profileInfo);
      })
      .then((eventDetails) => {
        for (let i in eventDetails) {
         if (('BOOKED' === eventDetails[i].status) || ('RESERVED' === eventDetails[i].status)) {
           this.deleteEvent(eventDetails[i].bookingInformation.id, isCenterAvailable, profileInfo);
          }
        }
      });
    return promise.all([
      expect(true).to.be.true
    ]);
  }


  public deleteSchedule(isCenterAvailable: boolean,scheduleId: string,profileInfo?: ProfileDetails ) {
    let deleteProfileUrl: string = this.baseApiUrl + 'manage/schedule/' + scheduleId;
    let authToken = this.authToken;
    let xsrfToken = this.xsrfToken;

    function deleteProfile(): Promise<any> {
      if(isCenterAvailable){
        let centerVal = profileInfo.centerId;
        return serviceCall.httpDeleteResource(deleteProfileUrl, authToken, xsrfToken,centerVal)
      }else {
        return serviceCall.httpDeleteResource(deleteProfileUrl, authToken, xsrfToken);
      }
    }

    let flow = protractor.promise.controlFlow();

    flow.execute(deleteProfile).then((response) => {
      expect([200], 'Delete schedule failed: '
        + JSON.stringify(response.bodyString)).to.include(response.statusCode);
    });
  }

  public deleteProfileThrApi(userInfo:User, profileInfo:ProfileDetails, isCenterAvailable: boolean){

    let user: User = new User();
    user.username = userInfo.username;
    user.password = userInfo.password;
    let profileName: string = profileInfo.profileName;

    this.chain()
      .then(() => {
        this.getAuthToken(user);
      })
      .then(() => {
        if(isCenterAvailable){
          return this.getSchedules(profileInfo,isCenterAvailable)
        }else {
          return this.getSchedules();
        }
      })
      .then((schedules) => {
        for (let i in schedules) {
          if (profileName.trim() === schedules[i].profileName.trim()) {
            this.deleteSchedule(isCenterAvailable,schedules[i].id.trim(), profileInfo);
          }
        }
      });
  }

  public deleteAllEventsAndAppliedProfiles(user: User, fromDate: string, toDate: string,isCenterAvailable?: boolean,profileInfo?:ProfileDetails) {
      this.chain()
        .then(() => {
         this.deleteSlotsThroughApi(user,fromDate, toDate,isCenterAvailable,profileInfo);
        })
        .then(() => {
         this.deleteAllAppliedProfileUsingApi(user, isCenterAvailable, profileInfo);
        });
  }

  public deleteAllAppliedProfileUsingApi(user:User,isCenterAvailable?: boolean,profileInfo?:ProfileDetails): Promise<any[]>{

      this.chain()
      .then(() => {
        this.getAuthToken(user);
      })
      .then(() => {
        return this.getSchedules(profileInfo, isCenterAvailable);
      })
      .then((schedules) => {
        for (let i in schedules) {
          this.deleteSchedule(isCenterAvailable,schedules[i].id,profileInfo);
        }
      });
    return promise.all([
      expect(true).to.be.true
    ]);

  }

  public getProfile(profileInfo?:ProfileDetails, isCenterAvailable?: boolean) {
    let profileUrl: string = this.baseApiUrl + 'manage/profiles';
    let authToken = this.authToken;
    let xsrfToken = this.xsrfToken;

    function getProfile(): Promise<any> {
      if(isCenterAvailable){
        let centerVal = profileInfo.centerId;
        return serviceCall.httpGet(profileUrl,authToken,centerVal);
      }else {
        return serviceCall.httpGet(profileUrl, authToken);
      }
    }

    let flow = protractor.promise.controlFlow();

    return flow.execute(getProfile).then((response) => {
      expect([200], 'Get profile failed: '
        + JSON.stringify(response.bodyString)).to.include(response.statusCode);
      let profilesJson: JSON = response.json['body'];
      return profilesJson;
    });
  }

  public getSchedules(profileInfo?:ProfileDetails, isCenterAvailable?: boolean) {
    let profileUrl: string = this.baseApiUrl + 'manage/schedules';
    let authToken = this.authToken;
    let xsrfToken = this.xsrfToken;

    function getSchedule(): Promise<any> {
      if(isCenterAvailable){
        let centerVal = profileInfo.centerId;
        return serviceCall.httpGet(profileUrl,authToken,centerVal);
      }else {
        return serviceCall.httpGet(profileUrl, authToken);
      }
    }

    let flow = protractor.promise.controlFlow();

    return flow.execute(getSchedule).then((response) => {
      expect([200], 'Get schedule failed: '
        + JSON.stringify(response.bodyString)).to.include(response.statusCode);
      let profilesJson: JSON = response.json['body'];
      return profilesJson;
    });
  }

  public createProfile(profileInfo: ProfileDetails, isCenterAvailable: boolean ) {
    let bookingUrl: string = this.baseApiUrl + 'manage/profile';
    let authToken = this.authToken;
    let xsrfToken = this.xsrfToken;
    function create(): Promise<any> {
      if(isCenterAvailable){
        let centerVal = profileInfo.centerId;
        return serviceCall.httpPostJson(bookingUrl, profileInfo, authToken, xsrfToken,profileInfo.centerId);
      }else {
        return serviceCall.httpPostJson(bookingUrl, profileInfo, authToken, xsrfToken);
      }
    }
    let flow = protractor.promise.controlFlow();

    flow.execute(create).then((response) => {
      expect([200], 'Create profile failed: '
        + JSON.stringify(response.bodyString)).to.include(response.statusCode);
    });
  }

  public applyProfile(profileId: string ,fromDate: string, toDate: string,profileInfo: ProfileDetails,isCenterAvailable: boolean) {
    let bookingUrl: string = this.baseApiUrl + 'manage/schedule' + '/?profileId=' + profileId + '&from=' + fromDate + '&to=' + toDate;
    let authToken = this.authToken;
    let xsrfToken = this.xsrfToken;

    function apply(): Promise<any> {
      if(isCenterAvailable){
        let centerVal = profileInfo.centerId;
        return serviceCall.httpPostJson(bookingUrl, profileInfo, authToken, xsrfToken,profileInfo.centerId);
      }else {
        return serviceCall.httpPostJson(bookingUrl, profileId, authToken, xsrfToken);
      }
    }

    let flow = protractor.promise.controlFlow();

    flow.execute(apply).then((response) => {
      expect([200], 'Apply Profile failed: '
        + JSON.stringify(response.bodyString)).to.include(response.statusCode);
    });
  }

  public applyProfileThrApi(profileInfo:ProfileDetails, fromDate: string, toDate: string, userInfo:User,isCenterAvailable: boolean) {
    let user: User = new User();
    user.username = userInfo.username;
    user.password = userInfo.password;

    this.chain()
      .then(() => {
        this.getAuthToken(user);
      })
      .then(() => {
        this.createProfile(profileInfo, isCenterAvailable);
      })
      .then(() => {
        return this.getProfile(profileInfo,isCenterAvailable);
      })
      .then((profiles) => {
        for (let i in profiles) {
          if (profileInfo.profileName.toString().trim() === profiles[i].profileName.toString().trim()) {
            this.applyProfile(profiles[i].id,fromDate,toDate,profileInfo,isCenterAvailable);
          }
        }
      });
  }

  public reserveEventThroughApi(bookingInfo: BookingInformation, expectedResponse) {
    let bookingInfoUrl: string = this.baseApiUrl + 'integration/requests';

    function getBookingInfo(): Promise<any> {
      return serviceCall.httpPostJsonForEventBooking(bookingInfoUrl, bookingInfo);
    }

    let flow = protractor.promise.controlFlow();

    return flow.execute(getBookingInfo).then((response) => {
      expect([expectedResponse], 'Get Booking Info failed: '
        + JSON.stringify(response.bodyString)).to.include(response.statusCode);
      let profilesJson: JSON = response.json['body'];
      return profilesJson;
    });
  }

  public reserveFlexEventThroughApi(bookingInfo: BookingInformation, expectedResponse){
      let flexReserveBookingInfoUrl: string = this.baseApiUrl + 'integration/requests/flex';
      function  getBookingInfo() : Promise<any> {
        return serviceCall.httpPostJsonForEventBooking(flexReserveBookingInfoUrl, bookingInfo);
      }
      let flow = protractor.promise.controlFlow();

    return flow.execute(getBookingInfo).then((response) => {
      expect([expectedResponse], 'Get Booking Info failed: '
        + JSON.stringify(response.bodyString)).to.include(response.statusCode);
      let profilesJson: JSON = response.json['body'];
      return profilesJson;
    });
  }

  public estimateFlexEventThroughApi(bookingInfo: BookingInformation, expectedResponse) {
      let flexEstimateBokingInfoUrl: string = this.baseApiUrl + 'integration/estimates/flex';
    function getPriceAvailabiltyInfo(): Promise<any> {
      return serviceCall.httpPostJsonForEventBooking(flexEstimateBokingInfoUrl, bookingInfo)
    }
    let flow = protractor.promise.controlFlow();
    return flow.execute(getPriceAvailabiltyInfo).then((response) => {
      expect([200],'Get Price and Availablity Info failed : '
        +JSON.stringify(response.bodyString)).to.include(response.statusCode);
      let profileJson : JSON = response.json['body'];
      return profileJson;

    });
  }

  public bookingEventThroughApi(bookingResponse: BookingResponse, exceptedResponse): Promise<any> {
    let estimateNumber:string = bookingResponse.estimateNo;
    let bookingInfoUrl: string = this.baseApiUrl + 'integration/requests/'+estimateNumber;

    function getBookingInfo(): Promise<any> {
      return serviceCall.httpPostJsonForEventBooking(bookingInfoUrl, bookingResponse);
    }

    let flow = protractor.promise.controlFlow();

    return flow.execute(getBookingInfo).then((response) => {
      expect([exceptedResponse], 'Get Booking Info failed: '
        + JSON.stringify(response.bodyString)).to.include(response.statusCode);
      let profilesJson: JSON = response.json['body'];
      return profilesJson;
    });
  }

  public priceAndAvailablityCheckThurApi(bookingInfo: BookingInformation) {
      let priceAvailabilityInfoUrl:  string = this.baseApiUrl + 'integration/estimates';

      function getPriceAvailabiltyInfo(): Promise<any> {
        return serviceCall.httpPostJsonForEventBooking(priceAvailabilityInfoUrl, bookingInfo)
      }
      let flow = protractor.promise.controlFlow();
      return flow.execute(getPriceAvailabiltyInfo).then((response) => {
        expect([200],'Get Price and Availablity Info failed : '
        +JSON.stringify(response.bodyString)).to.include(response.statusCode);
        let profileJson : JSON = response.json['body'];
        return profileJson;

      });
  }
}
