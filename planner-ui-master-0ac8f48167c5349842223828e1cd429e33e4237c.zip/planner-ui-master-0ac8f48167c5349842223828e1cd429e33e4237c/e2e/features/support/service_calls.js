var request = require('request');
var crypto = require('crypto');

var ServiceCall = function() {

    this.httpGet = function (url, token) {
        var defer = protractor.promise.defer();

        var options = {
            method: 'GET',
            uri: url,
            headers: {
                'Content-Type': 'application/json',
                'Cookie': token
            },
            json: {}
        };

        request(options, function(error, response, body){
            console.log('Done calling GET ' + url);
            if(error) {
                defer.reject('Got http.get error: ' + error.message);
            } else {
                defer.fulfill({
                    statusCode: response.statusCode,
                    bodyString: body,
                    json: response
                });
            }

        });

        return defer.promise;
    };

  this.httpGet = function (url, token,centerValue) {
    var defer = protractor.promise.defer();
    var options = {
      method: 'GET',
      uri: url,
      headers: {
        'Content-Type': 'application/json',
        'Cookie': token,
        'CENTER_ID': centerValue
      },
      json: {}
    };

    request(options, function(error, response, body){
      console.log('Done calling GET Method ' + url);
      if(error) {
        defer.reject('Got http.get method error: ' + error.message);
      } else {
        defer.fulfill({
          statusCode: response.statusCode,
          bodyString: body,
          json: response
        });
      }

    });

    return defer.promise;
  };


  this.httpPostJsonForEventBooking = function(url, jsonPayload) {
    var defer = protractor.promise.defer();
    var xAuthValue = 'Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJRVU9URVMtVE8tR08iLCJpYXQiOjE0OTMzMTA1OTUsImlzcyI6IlFVT1RFUy1UTy1HTyIsImdyb3VwcyI6IlFVT1RFUy1UTy1HTyJ9.6YNEsH1dR1EUQ5KaWojLF7MccpNBpeG6Tub35h0uGoODU886PC0rAiuutcoE8vEFuQFv0-MA6R4cKWg840HrVg';
    var options = {
      method: 'POST',
      uri: url,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'X-Authorization': xAuthValue
      },
      json: jsonPayload
    };

    request(options, function(error, response, body){
      console.log('Done calling POST-With-Params');
      if(error) {
        defer.reject('Got http.post error: ' + error.message);
      } else {
        defer.fulfill({
          statusCode: response.statusCode,
          headers: response.headers,
          bodyString: body,
          json: response
        });
      }
    });
    return defer.promise;
  };


      this.httpPostJson = function(url, jsonPayload, authToken, xsrfToken) {
          var defer = protractor.promise.defer();
          var xsrfTokenValue = this.getXsrfTokenValue(xsrfToken);

          var options = {
              method: 'POST',
              uri: url,
              headers: {
                  'Content-Type': 'application/json',
                  'Cookie': [authToken, xsrfToken],
                  'X-XSRF-TOKEN': xsrfTokenValue
              },
              json: jsonPayload
          };

          console.log('Calling POST ' + url);

          request(options, function(error, response, body){
              console.log('Done calling POST');
              if(error) {
                  defer.reject('Got http.post error: ' + error.message);
              } else {
                  defer.fulfill({
                      statusCode: response.statusCode,
                      headers: response.headers,
                      bodyString: body
                  });
              }

          });

          return defer.promise;
      };

  this.httpPostJson = function(url, jsonPayload, authToken, xsrfToken,centerValue) {
    var defer = protractor.promise.defer();
    var xsrfTokenValue = this.getXsrfTokenValue(xsrfToken);

    var options = {
      method: 'POST',
      uri: url,
      headers: {
        'Content-Type': 'application/json',
        'Cookie': [authToken, xsrfToken],
        'X-XSRF-TOKEN': xsrfTokenValue,
        'CENTER_ID': centerValue
      },
      json: jsonPayload
    };

    request(options, function(error, response, body){
      console.log('Done calling POST ' + url);
      if(error) {
        defer.reject('Got http.post error: ' + error.message);
      } else {
        defer.fulfill({
          statusCode: response.statusCode,
          headers: response.headers,
          bodyString: body
        });
      }

    });

    return defer.promise;
  };


  this.httpPut = function(url, jsonPayload, token) {
        var defer = protractor.promise.defer();

        var options = {
            method: 'PUT',
            uri: url,
            headers: {
                'Content-Type': 'application/json',
                'Cookie': token
            },
            json: jsonPayload
        };

        request(options, function(error, response, body){
            console.log('Done calling PUT ' + url);
            if(error) {
                defer.reject('Got http.put error: ' + error.message);
            } else {
                defer.fulfill({
                    statusCode: response.statusCode,
                    bodyString: body
                });
            }

        });

        return defer.promise;
    };

    this.httpDeleteResource = function(url, authToken, xsrfToken) {
        var defer = protractor.promise.defer();
        var xsrfTokenValue = this.getXsrfTokenValue(xsrfToken);

        var options = {
            method: 'DELETE',
            uri: url,
            headers: {
                'Content-Type': 'application/json',
                'Cookie': [authToken, xsrfToken],
                'X-XSRF-TOKEN': xsrfTokenValue
            }
        };

        request(options, function(error, response, body){
            console.log('Done calling DELETE ' + url);
            if(error) {
                defer.reject('Got http.delete error: ' + error.message);
            } else {
                defer.fulfill({
                    statusCode: response.statusCode,
                    bodyString: body
                });
            }
        });

        return defer.promise;
    };

  this.httpDeleteResource = function(url, authToken, xsrfToken, centerIdValue) {
    var defer = protractor.promise.defer();
    var xsrfTokenValue = this.getXsrfTokenValue(xsrfToken);

    var options = {
      method: 'DELETE',
      uri: url,
      headers: {
        'Content-Type': 'application/json',
        'Cookie': [authToken, xsrfToken],
        'X-XSRF-TOKEN': xsrfTokenValue,
        'CENTER_ID': centerIdValue
      }
    };

    request(options, function(error, response, body){
      console.log('Done calling DELETE ' + url);
      if(error) {
        defer.reject('Got http.delete method error: ' + error.message);
      } else {
        defer.fulfill({
          statusCode: response.statusCode,
          bodyString: body
        });
      }
    });

    return defer.promise;
  };

  this.getXsrfTokenValue = function(xsrfToken) {
        var xsrfTokenValue = null;

        if (xsrfToken != null) {
            xsrfTokenValue = xsrfToken.replace(/XSRF-TOKEN=/, '');
        }

        return xsrfTokenValue;
    }
};

module.exports = ServiceCall;
