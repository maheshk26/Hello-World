import {browser} from 'protractor';

import {ElementFinder} from 'protractor';

export class Utils {
    public scrollIntoView(el: ElementFinder): void {
        browser.executeScript(function(el2) {
            el2.scrollIntoView();
        }, el.getWebElement());
    }

    public getCurrentSystemDateAsString(): string {
        let date = new Date();
        let strDate = (date.getFullYear())+ "-" +("0" + (date.getMonth() + 1).toString()).substr(-2) + "-" + ("0" + date.getDate().toString()).substr(-2);
        return strDate;
    }

  public getCurrentSystemDate(): Date {
    return new Date();
  }

    public getDayInStringFormat(date:Date): string {
    let strDate = (date.getFullYear())+ "-" +("0" + (date.getMonth() + 1).toString()).substr(-2) + "-" + ("0" + date.getDate().toString()).substr(-2);
    return strDate;
  }

    public getWeekName(number : number): string{
      let CurrentWeek: string[] = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
      return CurrentWeek[number];
    }

    public getCurrentSystemMonth(): number {
        let date = new Date();
        return date.getMonth();
    }

    public convertDateIntoSpecificFormat(date: string): string {
        var splitDate: string[] = date.split("-");
        let strDate = (splitDate[2])+ "-" +("0" + (this.getMonthNumber(splitDate[1])).toString()).substr(-2) + "-" + ("0" + splitDate[0].toString()).substr(-2);
        return strDate;
    }

  public convertDateIntoRequiredFormat(date: string): string {
    var splitDate: string[] = date.split("-");
    let strDate = splitDate[1]+ "/" +splitDate[2] + "/" + splitDate[0];
    return strDate;
  }

    public getMonthName(month: number): string {
        let CurrentMonth: string[] = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December",];
        return CurrentMonth[month];
    }

    public getMonthNumber(monthName: string): number {
      let num = 0;
        switch (monthName) {
          case 'January' : case 'Jan' :
          num = 1;
          break;
          case 'February' : case 'Feb' :
          num = 2;
          break;
          case 'March' : case 'Mar' :
          num = 3;
          break;
          case 'April' : case 'Apr' :
          num = 4;
          break;
          case 'May' : case 'May' :
          num = 5;
          break;
          case 'June' : case 'Jun' :
          num = 6;
          break;
          case 'July' : case 'Jul' :
          num = 7;
          break;
          case 'August' : case 'Aug' :
          num = 8;
          break;
          case 'September' : case 'Sep' :
          num = 9;
          break;
          case 'October' : case 'Oct' :
          num = 10;
          break;
          case 'November' : case 'Nov' :
          num = 11;
          break;
          case 'December' : case 'Dec' :
          num = 12;
          break;
        }
      return num;
    }

    public stringToDate(_date,_format,_delimiter) {
      let formatLowerCase =_format.toLowerCase();
      let formatItems=formatLowerCase.split(_delimiter);
      let dateItems=_date.split(_delimiter);
      let monthIndex=formatItems.indexOf("mm");
      let dayIndex=formatItems.indexOf("dd");
      let yearIndex=formatItems.indexOf("yyyy");
      let month=parseInt(dateItems[monthIndex]);
      month-=1;
      let formatedDate = new Date(dateItems[yearIndex],month,dateItems[dayIndex]);
      return formatedDate;
    }


    public reFormatDate(date): string{
      let formattedDate = this.stringToDate(date,"yyyy-mm-dd","-");
      let selectDay = formattedDate.getDate();
      let selectMonth = formattedDate.getMonth();
      let selectYear = formattedDate.getFullYear();
      var months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      let mm = months[selectMonth];
      let strDate = selectDay+ "-" +mm + "-" + selectYear;
      return  strDate;
    }

    public addDaysAsString(theDate, days: number): string {
      let date1 = new Date(theDate);
      let date = new Date(date1.getTime() + days*24*60*60*1000);
      let specificDate = (date.getFullYear())+ "-" +("0" + (date.getMonth() + 1).toString()).substr(-2) + "-" + ("0" + date.getDate()).substr(-2);
      return specificDate;
    }

    public subtractDaysAsString(theDate, days: number): string {
      let date1 = new Date(theDate);
      let date = new Date(date1.getTime() - days*24*60*60*1000);
      let specificDate = (date.getFullYear())+ "-" +("0" + (date.getMonth() + 1).toString()).substr(-2) + "-" + ("0" + date.getDate()).substr(-2);
      return specificDate;
    }

  public addDaysAsDate(theDate: Date, days: number): Date {
    return new Date(theDate.getTime() + days*24*60*60*1000);
  }
}

