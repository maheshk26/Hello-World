/**
 * Created by TSXA2 on 6/9/2017.
 */


import {binding,when, then} from 'cucumber-tsflow';
import {browser, by, element, protractor} from 'protractor';
import {expect} from '../support/asserts.config';
import {CalendarPage} from '../../pages/calendar.page';
import {promise} from 'selenium-webdriver';
import {RandomStringGenerator} from '../support/random_string_generator';
import {CreateEventComponent} from "../../pages/components/create.event.component";
import {ServiceUtils} from '../support/service.utils';
import {Utils} from '../support/utils';
import {EventStatus} from '../../enums/event.status';
import {EventDetails} from "../../models/event_details";
import {SlotDetails} from '../../models/slot_details';
import {chain} from "../support/world";
import {User} from "../../models/user";
import {DayCalendarPage} from "../../pages/daycalendar.page";
import {BookingResponse} from "../../models/booking.response";
import {BookingInformation} from "../../models/booking.information";

var world = require('../support/world');

@binding()
class marketViewStepDefinitions{

  private eventDetails: EventDetails;
  private serviceUtils: ServiceUtils = new ServiceUtils();
  private utils: Utils = new Utils();
  private stringGenerator: RandomStringGenerator = new RandomStringGenerator();
  private slotDetails: SlotDetails = new SlotDetails();
  private bookingResponseDetails: BookingResponse = new BookingResponse();
  private bookingInfo: BookingInformation = new BookingInformation();

  @when(/^event has been created in St.louis centers$/,'',90000)
  public eventHasBeenCreatedInStlCenters(): Promise<any[]> {
    let availableCount : any;
    let bookedCount: any;
    let calendarPage = new CalendarPage().confirmPageHasLoaded();
    let createEventComponent = this.createEvent(calendarPage);
    createEventComponent.clickAddEvent();
    let date = this.utils.getCurrentSystemDateAsString();
    calendarPage.getHeaderComponent().selectDateFromCalendar(date);
    calendarPage.readSlots(date, EventStatus.AVAILABLE).then(availableSlot =>{
      let availableSlotInt : number = availableSlot;
      availableCount = availableSlotInt;
    })
    calendarPage.readSlots(date,EventStatus.BOOKED).then(bookedSlot => {
      let bookedSlotInt: number = bookedSlot;
      bookedCount = bookedSlotInt;
    })
    calendarPage.getHeaderComponent().selectCenter(browser.params.data.centerCalendarRealms.stLouis01);
    calendarPage.confirmPageHasLoaded();
    createEventComponent = this.createEvent(calendarPage);
    createEventComponent.clickAddEvent();
    calendarPage.getHeaderComponent().selectDateFromCalendar(date);
    calendarPage.readSlots(date, EventStatus.AVAILABLE).then(availableData =>{
      let availableDataInt : number = availableData;
      availableCount = availableCount + availableDataInt;
      this.slotDetails.available = availableCount;
    })
    calendarPage.readSlots(date,EventStatus.BOOKED).then(bookedData => {
      let bookedDataInt: number = bookedData;
      bookedCount = bookedCount + bookedDataInt;
      this.slotDetails.booked = bookedCount;
    })

    return promise.all([
      expect(calendarPage.getClassAttributeOfCalendarView(), 'User is not able to view month calendar').to.eventually.contain('month-view')
    ])
  }

  private createEvent(calendarPage: CalendarPage) {
    calendarPage.getHeaderComponent().clickCreateEventButton();
    let createEventComponent: CreateEventComponent = new CreateEventComponent().confirmComponentIsAvailable();

    world.defaultEventDetails = new EventDetails(browser.params.data.createNewEventValidData);
    world.defaultEventDetails.customerName = this.stringGenerator.getRandomString(6);
    world.defaultEventDetails.zipCode = this.stringGenerator.getRandomNumber(5);
    world.defaultEventDetails.orderNumber = this.stringGenerator.getRandomAlphaNumericString(25);
    world.defaultEventDetails.opportunityNumber = this.stringGenerator.getRandomAlphaNumericString(25);
    world.defaultEventDetails.estimateNumber = this.stringGenerator.getRandomAlphaNumericString(25);
    createEventComponent.enterCustomerName(world.defaultEventDetails.customerName);
    createEventComponent.selectLocationType(browser.params.data.createNewEventValidData.locationType);
    createEventComponent.enterZipCode(world.defaultEventDetails.zipCode);
    createEventComponent.selectShipmentType(browser.params.data.createNewEventValidData.shipmentType);
    createEventComponent.enterOrderNumber(world.defaultEventDetails.orderNumber);
    createEventComponent.enterTrackingNumber(world.defaultEventDetails.opportunityNumber);
    createEventComponent.enterQuoteNumber(world.defaultEventDetails.estimateNumber);
    return createEventComponent;
  }

  @then(/^combined center data for booked event of St.Louis market is shown in month$/)
  public combinedCenterDataForBookedEventStlMarketIsShown(): void {
    let calendarPage = new CalendarPage().confirmPageHasLoaded();
    calendarPage.getHeaderComponent().selectCenter(browser.params.data.centerCalendarRealms.stLouisMarket);
    calendarPage.confirmPageHasLoaded();
    let date = this.utils.getCurrentSystemDateAsString();
    let availableSlot :number;
    let bookedSlot :  number;

    chain()
      .then(() => {
        calendarPage.readSlots(date, EventStatus.AVAILABLE).then(availableSlotsInMarket => {
          availableSlot = availableSlotsInMarket;
          expect(availableSlot,'Available Slot In St.Louis Market is different').to.equal(this.slotDetails.available);
          }
        )}
      )
      .then( () => {
        calendarPage.readSlots(date, EventStatus.BOOKED).then(bookedSlotsInMarket => {
        bookedSlot = bookedSlotsInMarket;
        expect(bookedSlot, 'Booked Slot In ST.Louis Market is different').to.equal(this.slotDetails.booked);
      })
      }
     )
  }

  @when (/^combined center data for reserved event of Chicago market view is shown in month$/ ,'',60000)
  public navigateToChicagoMarket(): void {
    let availableCount : number = 0;
    let reservedCount: number = 0;
    let calendarPage  = new CalendarPage();
    let date = this.utils.getCurrentSystemDateAsString();

    //Chicago One
    calendarPage.getHeaderComponent().selectCenter(browser.params.data.centerCalendarRealms.chicagoOne);
    calendarPage.confirmPageHasLoaded();

    calendarPage.readSlots(date, EventStatus.AVAILABLE).then(availableData => {
      availableCount = availableData;
      this.slotDetails.available = availableCount;
    })
    calendarPage.readSlots(date, EventStatus.RESERVED).then(reservedData => {
      reservedCount = reservedData;
      this.slotDetails.reserved = reservedCount;
    })

    //Chicago Two
    calendarPage.getHeaderComponent().selectCenter(browser.params.data.centerCalendarRealms.chicagoTwo);
    calendarPage.confirmPageHasLoaded();

    calendarPage.readSlots(date, EventStatus.AVAILABLE).then(availableData => {
      availableCount = availableCount + availableData;
      this.slotDetails.available = availableCount;
    })
    calendarPage.readSlots(date, EventStatus.RESERVED).then(reservedData => {
      reservedCount = reservedCount + reservedData;
      this.slotDetails.reserved = reservedCount;
    })

    //Chicago Market
    calendarPage.getHeaderComponent().selectCenter(browser.params.data.centerCalendarRealms.chicagoMarket);
    calendarPage.confirmPageHasLoaded();
    let availableSlot :number;
    let reservedSlot :  number;
    calendarPage.readSlots(date, EventStatus.AVAILABLE).then(availableSlotsInMarket => {
      availableSlot = availableSlotsInMarket;
      expect(availableSlot,'Available Slot In St.Louis Market is different').to.equal(this.slotDetails.available);
    });
    calendarPage.readSlots(date, EventStatus.RESERVED).then(reservedSlotsInMarket => {
      reservedSlot = reservedSlotsInMarket;
      expect(reservedSlot,'Available Slot In St.Louis Market is different').to.equal(this.slotDetails.reserved);
    });
  }

  @then (/^combined center data for booked event of Chicago market view is shown in month$/)
  public combinedCenterDataBookedEventOfChicagoMarketView(): Promise <any> {

    let availableCount : number = 0;
    let bookedCount: number = 0;
    let calendarPage  = new CalendarPage();
    let date = this.utils.getCurrentSystemDateAsString();

    //Chicago One
    calendarPage.getHeaderComponent().selectCenter(browser.params.data.centerCalendarRealms.chicagoOne);
    calendarPage.confirmPageHasLoaded();
    calendarPage.readSlots(date, EventStatus.AVAILABLE).then(availableData => {
      availableCount = availableData;
      this.slotDetails.available = availableCount;
    })
    calendarPage.readSlots(date, EventStatus.BOOKED).then(bookedData => {
      bookedCount = bookedData;
      this.slotDetails.booked = bookedCount;
    })

    //Chicago Two
    calendarPage.getHeaderComponent().selectCenter(browser.params.data.centerCalendarRealms.chicagoTwo);
    calendarPage.confirmPageHasLoaded();
    calendarPage.readSlots(date, EventStatus.AVAILABLE).then(availableData => {
      availableCount = availableCount + availableData;
      this.slotDetails.available = availableCount;
    })
    calendarPage.readSlots(date, EventStatus.BOOKED).then(bookedData => {
      bookedCount = bookedCount + bookedData;
      this.slotDetails.booked = bookedCount;
    })

    //Chicago Market
    calendarPage.getHeaderComponent().selectCenter(browser.params.data.centerCalendarRealms.chicagoMarket);
    calendarPage.confirmPageHasLoaded();
    let availableSlot :number;
    let bookedSlot :  number;
    calendarPage.readSlots(date, EventStatus.AVAILABLE).then(availableSlotsInMarket => {
      availableSlot = availableSlotsInMarket;
      expect(availableSlot,'Available Slot In St.Louis Market is different').to.equal(this.slotDetails.available);
    });
    calendarPage.readSlots(date, EventStatus.RESERVED).then(bookedSlotsInMarket => {
      bookedSlot = bookedSlotsInMarket;
      expect(bookedSlot,'Available Slot In St.Louis Market is different').to.equal(this.slotDetails.booked);
    });
    return promise.all([

    ]);
  }
  private setFlexEventData() {
    this.bookingInfo.estimateNumber = this.stringGenerator.getRandomNumber(10);
    this.bookingResponseDetails.estimateNo = this.bookingInfo.estimateNumber;
    this.bookingInfo.customerName = this.stringGenerator.getRandomString(6);
    this.bookingInfo.originZipCode = '60687';
    this.bookingInfo.destinationZipCode = '90001';
    this.bookingInfo.surveyWeightInPounds = this.stringGenerator.getRandomNumber(3);
    //earlyLoadDate
    let date = this.utils.getCurrentSystemDateAsString();
    let formattedDate = this.utils.reFormatDate(date);
    this.bookingInfo.earlyLoadDate = formattedDate;
    // lateLoad Date
    let lateLoadFormattedDate = this.utils.addDaysAsString(this.utils.getCurrentSystemDate(), 4);
    let lateLoadDate = this.utils.reFormatDate(lateLoadFormattedDate);
    this.bookingInfo.lateLoadDate = lateLoadDate;
    //earlyDeliveryDate
    let strDate = this.utils.addDaysAsString(this.utils.getCurrentSystemDate(), 2);
    let deliveryDate = this.utils.reFormatDate(strDate);
    this.bookingInfo.earlyDeliveryDate = deliveryDate;
    //lateDeliveryDate
    let lateDeliveryFormattedDate = this.utils.addDaysAsString(this.utils.getCurrentSystemDate(), 6);
    let lateDeliveryDate = this.utils.reFormatDate(lateDeliveryFormattedDate);
    this.bookingInfo.lateDeliveryDate = lateDeliveryDate;

    this.bookingInfo.orderNumber = this.stringGenerator.getRandomNumber(9);
    this.bookingInfo.opportunityNumber = this.stringGenerator.getRandomNumber(12);
    this.bookingInfo.timeToExpire = 2;
    this.bookingInfo.temporalUnit = 'DAYS';
    this.bookingInfo.flex = 'true';
  }


  @when(/^I reserve a flex booking through api reserved booking should show in those reserved centers$/ ,'',60000)
  public whenReservedFlexBookingEventThroughApi() : Promise<any> {
    this.setFlexEventData();

    chain()
      .then(() => {
        return this.serviceUtils.reserveFlexEventThroughApi(this.bookingInfo, 200);
      })
      .then((bookingResponseDetails) => {
        this.verifyReservedEvent(this.bookingInfo,bookingResponseDetails);
      });
    let calendarPage = new CalendarPage();

    return promise.all([
      expect(calendarPage.getClassAttributeOfCalendarView(), 'User is not able to view month calendar').to.eventually.contain('month-view')
    ]);
  }

  public verifyReservedEvent(bookingInfo:BookingInformation, reserveResponseDetails: any) : Promise <any> {
    console.log(reserveResponseDetails);
    this.bookingResponseDetails.originCenterCode = reserveResponseDetails.origin.centerCode;
    this.bookingResponseDetails.originDate = reserveResponseDetails.origin.date;
    this.bookingResponseDetails.destCenterCode = reserveResponseDetails.destination.centerCode;
    this.bookingResponseDetails.destDate = reserveResponseDetails.destination.date;

    //Origin
    let calendarPage = new CalendarPage().confirmPageHasLoaded();

    let centerCode:string = reserveResponseDetails.origin.centerCode;
    calendarPage.getHeaderComponent().selectCenter(centerCode);
    calendarPage.confirmPageHasLoaded();

    calendarPage.getHeaderComponent().selectDateFromCalendar(reserveResponseDetails.origin.date);
    let formattedDate = this.utils.convertDateIntoSpecificFormat(reserveResponseDetails.origin.date);
    let customerNameDisplayed = bookingInfo.customerName;
    expect(calendarPage.isFlexIconPresent(),"Flex event Icon is not showing").to.eventually.contains.true;
    expect(calendarPage.isEventReservedInMonthView(formattedDate,customerNameDisplayed),"New Event is Not created").to.eventually.be.true;
    let dayCalendarPage: DayCalendarPage = new DayCalendarPage().confirmPageHasLoaded();
    expect(dayCalendarPage.readShipmentType(customerNameDisplayed),'Shipment type is not visible').to.eventually.contain('CONTAINER');
    expect(dayCalendarPage.readZipCode(customerNameDisplayed), 'Origin zipCode is NOT displayed').to.eventually.contain(bookingInfo.originZipCode);
    expect(dayCalendarPage.readOrderNumber(customerNameDisplayed),'Order number is not visible').to.eventually.contain(bookingInfo.orderNumber);
    expect(dayCalendarPage.readTrackingNumber(customerNameDisplayed),'Tracking number is not visible').to.eventually.contain(bookingInfo.opportunityNumber);
    expect(dayCalendarPage.readQuoteNumber(customerNameDisplayed),'Quote number is not visible').to.eventually.contain(bookingInfo.estimateNumber);

    let formattedEarlyLoadDate = this.utils.convertDateIntoSpecificFormat(bookingInfo.earlyLoadDate);
    let earlyLoadDate = this.utils.convertDateIntoRequiredFormat(formattedEarlyLoadDate);
    let formattedLateLoadDate = this.utils.convertDateIntoSpecificFormat(bookingInfo.lateLoadDate);
    let lateLoadDate = this.utils.convertDateIntoRequiredFormat(formattedLateLoadDate);
    this.verifyFlexDate(dayCalendarPage.readFlexDate(customerNameDisplayed), earlyLoadDate, lateLoadDate, centerCode);

    calendarPage.getHeaderComponent().clickMonthButton();
    calendarPage.confirmPageHasLoaded();
    //destination

    calendarPage.getHeaderComponent().selectCenter(reserveResponseDetails.destination.centerCode)
    calendarPage.confirmPageHasLoaded();
    calendarPage.getHeaderComponent().selectDateFromCalendar(reserveResponseDetails.destination.date);
    formattedDate = this.utils.convertDateIntoSpecificFormat(reserveResponseDetails.destination.date);
    expect(calendarPage.isEventReservedInMonthView(formattedDate,bookingInfo.customerName),"New Event is Not created").to.eventually.be.true;
    expect(dayCalendarPage.readShipmentType(customerNameDisplayed),'Shipment type is not visible').to.eventually.contain('CONTAINER');
    expect(dayCalendarPage.readZipCode(customerNameDisplayed), 'Origin zipCode is NOT displayed').to.eventually.contain(bookingInfo.destinationZipCode);
    expect(dayCalendarPage.readOrderNumber(customerNameDisplayed),'Order number is not visible').to.eventually.contain(bookingInfo.orderNumber);
    expect(dayCalendarPage.readTrackingNumber(customerNameDisplayed),'Tracking number is not visible').to.eventually.contain(bookingInfo.opportunityNumber);
    expect(dayCalendarPage.readQuoteNumber(customerNameDisplayed),'Quote number is not visible').to.eventually.contain(bookingInfo.estimateNumber);
    let formattedEarlyDeliveryDate = this.utils.convertDateIntoSpecificFormat(bookingInfo.earlyDeliveryDate);
    let earlyDeliveryDate = this.utils.convertDateIntoRequiredFormat(formattedEarlyDeliveryDate);
    let formattedLateDeliveryDate = this.utils.convertDateIntoSpecificFormat(bookingInfo.lateDeliveryDate);
    let lateDeliveryDate = this.utils.convertDateIntoRequiredFormat(formattedLateDeliveryDate)
    this.verifyFlexDate(dayCalendarPage.readFlexDate(customerNameDisplayed), earlyDeliveryDate, lateDeliveryDate, reserveResponseDetails.destination.centerCode);


    calendarPage.getHeaderComponent().clickMonthButton();

    return promise.all([
      expect(calendarPage.getClassAttributeOfCalendarView(), 'User is not able to view month calendar').to.eventually.contain('month-view')
    ]);
  }

  @when(/^I estimate a felx event through api event should not reserved in centers$/)
  public estimateFlexEventThroughApi(): Promise <any> {
    this.setFlexEventData();
    let calendarPage = new CalendarPage();

     this.serviceUtils.estimateFlexEventThroughApi(this.bookingInfo, 200).then((responseDetails)=>{
       console.log(responseDetails);
       let bookingResponseDetails:any = responseDetails;
       let centerCode: string = bookingResponseDetails.origin.centerCode;
       calendarPage.getHeaderComponent().selectCenter(centerCode);
       calendarPage.confirmPageHasLoaded();
       calendarPage.getHeaderComponent().selectDateFromCalendar(bookingResponseDetails.origin.date);
       let formattedDate = this.utils.convertDateIntoSpecificFormat(bookingResponseDetails.origin.date);
       let customerNameDisplayed = this.bookingInfo.customerName;
       expect(calendarPage.isEventBookedInMonthView(formattedDate,customerNameDisplayed),"New Event is created").to.eventually.be.false;

       centerCode = bookingResponseDetails.destination.centerCode;
       calendarPage.getHeaderComponent().selectCenter(centerCode);
       calendarPage.confirmPageHasLoaded();
       calendarPage.getHeaderComponent().selectDateFromCalendar(bookingResponseDetails.destination.date);
       formattedDate = this.utils.convertDateIntoSpecificFormat(bookingResponseDetails.destination.date);
       expect(calendarPage.isEventBookedInMonthView(formattedDate,customerNameDisplayed), " New Event is created").to.eventually.be.false;
     });

    return promise.all([
      expect(calendarPage.getClassAttributeOfCalendarView(), 'User is not able to view month calendar').to.eventually.contain('month-view')
    ]);
  }

  private verifyFlexDate(flexDateLocator: any, formatEarlyDate: string, formatLateDate: string, center: string): void {
    flexDateLocator.getText().then(function (textData) {
      let getFlexDateStr: string[] = textData.split(' - ');
      let earlyFlexDateFromScreen: string = getFlexDateStr[0];
      let lateFlexDateFromScreen: string = getFlexDateStr[1];


      expect(earlyFlexDateFromScreen,'Flex Dates are not equal displayed :'+center).to.equal(formatEarlyDate);
      expect(lateFlexDateFromScreen,'Flex Dates are not equal displayed: '+center).to.equal(formatLateDate);
    });
  }
}
export = marketViewStepDefinitions;
