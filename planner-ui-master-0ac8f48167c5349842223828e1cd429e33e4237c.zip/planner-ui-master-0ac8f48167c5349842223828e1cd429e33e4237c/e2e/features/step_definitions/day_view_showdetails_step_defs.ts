import {binding, when, then} from 'cucumber-tsflow';
import {expect} from '../support/asserts.config';
import {CalendarPage} from '../../pages/calendar.page';
import {EventDetails} from '../../models/event_details';
import {browser} from 'protractor';
import {Utils} from '../support/utils';
import {RandomStringGenerator} from '../support/random_string_generator';
import {ServiceUtils} from '../support/service.utils';
import {DayCalendarPage} from '../../pages/daycalendar.page';
import {promise} from 'selenium-webdriver';
import {CreateEventComponent} from '../../pages/components/create.event.component';
import {DeleteUpdateEventComponent} from '../../pages/components/delete.update.event.component';
import {EventStatus} from '../../enums/event.status';
import DeleteUpdateEventStepDefinitions = require('./delete_update_step_defs');

@binding()
class DayViewShowsDetailsStepDefinitions {

  private eventDetails: EventDetails;
  private eventDetails2: EventDetails;
  private stringGenerator: RandomStringGenerator = new RandomStringGenerator();
  private serviceUtils: ServiceUtils = new ServiceUtils();
  private utils: Utils = new Utils();

  @when(/^an event is booked in month calendar$/)
  public eventIsBookedForToday(): void {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let date = this.utils.getCurrentSystemDateAsString();
    let formattedDate = this.utils.reFormatDate(date);
    let centerId: string = browser.params.data.centerIdForCenterCalendarRealm.centerIdForCalendarOne;

    this.eventDetails = new EventDetails(browser.params.data.createNewEventValidData);
    this.eventDetails.customerName = this.stringGenerator.getRandomString(6);
    this.eventDetails.zipCode = this.stringGenerator.getRandomNumber(5);
    this.eventDetails.orderNumber = this.stringGenerator.getRandomAlphaNumericString(30);
    this.eventDetails.opportunityNumber = this.stringGenerator.getRandomAlphaNumericString(30);
    this.eventDetails.estimateNumber = this.stringGenerator.getRandomAlphaNumericString(30);
    this.serviceUtils.bookSlotThroughApi(formattedDate,this.eventDetails, centerId);

    browser.refresh();
  }

  @when(/^the user navigates to the day view$/)
  public navigateToDayView(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let date = this.utils.getCurrentSystemDateAsString();

    let dayCalendarPage: DayCalendarPage = calendarPage.clickSlotsRow(date, EventStatus.BOOKED);

    return promise.all([
      expect(dayCalendarPage.getHeaderComponent().readCurrentCalendarDate(),
        'Unable to click booked slots for date ' + date).to.eventually.not.be.null
    ]);
  }

  @then(/^all of the details for the booked event are visible$/)
  public detailsForBookedEventAreVisible(): Promise<any[]> {
    let customerNameDisplayed  = this.eventDetails.customerName;
    let dayCalendarPage: DayCalendarPage = new DayCalendarPage().confirmPageHasLoaded();

    return promise.all([
      expect(dayCalendarPage.readLocationType(customerNameDisplayed),
        'Location type is not visible').to.eventually.contain(this.eventDetails.locationType),
      expect(dayCalendarPage.readZipCode(customerNameDisplayed),
        'Zip code is not visible').to.eventually.contain(this.eventDetails.zipCode),
      expect(dayCalendarPage.readShipmentType(customerNameDisplayed),
        'Shipment type is not visible').to.eventually.contain(this.eventDetails.shipmentType),
      expect(dayCalendarPage.readOrderNumber(customerNameDisplayed),
        'Order number is not visible').to.eventually.contain(this.eventDetails.orderNumber),
      expect(dayCalendarPage.readTrackingNumber(customerNameDisplayed),
        'Tracking number is not visible').to.eventually.contain(this.eventDetails.opportunityNumber),
      expect(dayCalendarPage.readQuoteNumber(customerNameDisplayed),
        'Quote number is not visible').to.eventually.contain(this.eventDetails.estimateNumber),
    ]);
  }

  @when(/^multiple events are booked for a single day$/)
  public multipleEventsAreBookedFoRSingleDay(): void{
   let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
   let date = this.utils.getCurrentSystemDateAsString();
   let formattedDate = this.utils.reFormatDate(date);
    let centerId: string = browser.params.data.centerIdForCenterCalendarRealm.centerIdForCalendarOne;

    this.eventDetails = new EventDetails(browser.params.data.createNewEventValidData);
    this.eventDetails.customerName = this.stringGenerator.getRandomString(6);
    this.eventDetails.zipCode = this.stringGenerator.getRandomNumber(5);
    this.eventDetails.orderNumber = this.stringGenerator.getRandomAlphaNumericString(30);
    this.eventDetails.opportunityNumber = this.stringGenerator.getRandomAlphaNumericString(30);
    this.eventDetails.estimateNumber = this.stringGenerator.getRandomAlphaNumericString(30);


    // book first event
    this.serviceUtils.bookSlotThroughApi(formattedDate,this.eventDetails, centerId);

    // book second event
    this.eventDetails2 = new EventDetails(browser.params.data.createNewEventValidData);
    this.eventDetails2.customerName = this.stringGenerator.getRandomString(6);
    this.eventDetails2.estimateNumber = this.stringGenerator.getRandomAlphaNumericString(30);
    this.serviceUtils.bookSlotThroughApi(formattedDate, this.eventDetails2, centerId);

    browser.refresh();
  }

  @then(/^all of the details for multiple events booked on that day are visible$/)
  public allDetailsForAllEventsAreVisible(): Promise<any[]>{
    let dayCalendarPage: DayCalendarPage = new DayCalendarPage().confirmPageHasLoaded();

    return promise.all([
      expect(dayCalendarPage.isEventBookedInDayView(this.eventDetails.customerName),
        'Unable to find first booked event: ' + this.eventDetails.customerName).to.eventually.be.true,
      expect(dayCalendarPage.isEventBookedInDayView(this.eventDetails2.customerName),
        'Unable to find second booked event: ' + this.eventDetails2.customerName).to.eventually.be.true
    ]);
  }

  @when(/^an event is booked that uses the maximum character lengths for customer name, order number, tracking number, and quote number$/)
  public eventBookedWithMaximumCharacterLength(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let date = this.utils.getCurrentSystemDateAsString();
    let createEventComponent: CreateEventComponent = calendarPage.clickSlotsRow(date, EventStatus.AVAILABLE);

    this.eventDetails = new EventDetails(browser.params.data.createNewEventValidData);
    this.eventDetails.customerName = this.stringGenerator.getRandomString(32);
    this.eventDetails.zipCode = this.stringGenerator.getRandomNumber(5);
    this.eventDetails.orderNumber = this.stringGenerator.getRandomAlphaNumericString(32);
    this.eventDetails.opportunityNumber = this.stringGenerator.getRandomAlphaNumericString(32);
    this.eventDetails.estimateNumber = this.stringGenerator.getRandomAlphaNumericString(32);

    createEventComponent.enterCustomerName(this.eventDetails.customerName);
    createEventComponent.selectLocationType(browser.params.data.createNewEventValidData.locationType);
    createEventComponent.enterZipCode(this.eventDetails.zipCode);
    createEventComponent.selectShipmentType(browser.params.data.shipmentType);
    createEventComponent.enterOrderNumber(this.eventDetails.orderNumber);
    createEventComponent.enterTrackingNumber(this.eventDetails.opportunityNumber);
    createEventComponent.enterQuoteNumber(this.eventDetails.estimateNumber);

    return promise.all([
      expect(createEventComponent.readCustomerName(),
        'Incorrect customer name entered').to.eventually.equal(this.eventDetails.customerName),
      expect(createEventComponent.readZipCode(),
        'Incorrect zip code entered').to.eventually.equal(this.eventDetails.zipCode),
      expect(createEventComponent.readOrderNumber(),
        'Incorrect order number entered').to.eventually.equal(this.eventDetails.orderNumber),
      expect(createEventComponent.readTrackingNumber(),
        'Incorrect tracking number entered').to.eventually.equal(this.eventDetails.opportunityNumber),
      expect(createEventComponent.readQuoteNumber(),
        'Incorrect quote number entered').to.eventually.equal(this.eventDetails.estimateNumber),
      createEventComponent.clickAddEvent()
    ]);
  }

  @when(/^the event is edited$/)
  public eventIsEditable(): Promise<any> {
    let dayCalendarPage: DayCalendarPage = new DayCalendarPage().confirmPageHasLoaded();
    let customerName = this.eventDetails.customerName;
    dayCalendarPage.clickBookedSlotsRowInDayCalendar(customerName);

    let createEventComponent: CreateEventComponent = new CreateEventComponent();

    this.eventDetails = new EventDetails(browser.params.data.createNewEventValidData);
    this.eventDetails.customerName = this.stringGenerator.getRandomString(10);
    this.eventDetails.zipCode = this.stringGenerator.getRandomNumber(5);
    this.eventDetails.orderNumber = this.stringGenerator.getRandomAlphaNumericString(5);
    this.eventDetails.opportunityNumber = this.stringGenerator.getRandomAlphaNumericString(5);
    this.eventDetails.estimateNumber = this.stringGenerator.getRandomAlphaNumericString(5);

    createEventComponent.enterCustomerName(this.eventDetails.customerName);
    createEventComponent.enterZipCode(this.eventDetails.zipCode);
    createEventComponent.enterOrderNumber(this.eventDetails.orderNumber);
    createEventComponent.enterTrackingNumber(this.eventDetails.opportunityNumber);
    createEventComponent.enterQuoteNumber(this.eventDetails.estimateNumber);

    let deleteUpdateEventComponent: DeleteUpdateEventComponent = new DeleteUpdateEventComponent();

    return promise.all([
      deleteUpdateEventComponent.clickUpdateEventButton()
    ]);
  }

  @then(/^the event details are updated on the day view$/)
  public eventDetailsAreUpdated(): Promise<any[]> {
    let customerNameDisplayed  = this.eventDetails.customerName;
    let dayCalendarPage: DayCalendarPage = new DayCalendarPage().confirmPageHasLoaded();

    return promise.all([
      expect(dayCalendarPage.readLocationType(customerNameDisplayed),'Location type is not updated').to.eventually.contain(this.eventDetails.locationType),
      expect(dayCalendarPage.readZipCode(customerNameDisplayed),'Zip code is not updated').to.eventually.contain(this.eventDetails.zipCode),
      expect(dayCalendarPage.readShipmentType(customerNameDisplayed),'Shipment type is not updated').to.eventually.contain(this.eventDetails.shipmentType),
      expect(dayCalendarPage.readOrderNumber(customerNameDisplayed),'Order number is not updated').to.eventually.contain(this.eventDetails.orderNumber),
      expect(dayCalendarPage.readTrackingNumber(customerNameDisplayed),'Tracking number is not updated').to.eventually.contain(this.eventDetails.opportunityNumber),
      expect(dayCalendarPage.readQuoteNumber(customerNameDisplayed),'Quote Number is not updated').to.eventually.contain(this.eventDetails.estimateNumber)
    ]);
  }

}
export = DayViewShowsDetailsStepDefinitions;
