import {binding, given, when, then} from 'cucumber-tsflow';
import {CallbackStepDefinition} from 'cucumber';
import {browser, by, element, protractor} from 'protractor';
import {expect} from '../support/asserts.config';
import {CalendarPage} from "../../pages/calendar.page";

import {ServiceUtils} from '../support/service.utils';
import {promise} from "selenium-webdriver";
import {WeekCalendarPage} from "../../pages/weekcalendar.page";
import {DayCalendarPage} from "../../pages/daycalendar.page";
import {Utils} from "../support/utils";
import {LoginPage} from "../../pages/login.page";
import AdminAddProfileStepDefinitions = require('./admin_add_profile_step_defns');
import {ProfileDetails} from "../../models/profile_details";
import {RandomStringGenerator} from "../support/random_string_generator";
import {User} from "../../models/user";

@binding()
class CalendarStepDefinitions {

    private serviceUtils: ServiceUtils = new ServiceUtils();
    private utils: Utils = new Utils();
    private profileDetails: ProfileDetails = new ProfileDetails();

    @given(/^I login to the Crew Service Calendar application$/)
    public loginToCrewServiceCalendarApp(): Promise<any[]> {
      // SETUP - delete applied profiles/events and add a new one
      let hqUser: User = new User();
      hqUser.username = browser.params.data.validHqUser.username;
      hqUser.password = browser.params.data.validHqUser.password;
      let fromDate = this.utils.getCurrentSystemDateAsString();
      let formattedFromDate = this.utils.reFormatDate(fromDate);
      let toDate = this.utils.addDaysAsString(this.utils.getCurrentSystemDate(), 90);
      let formattedToDate = this.utils.reFormatDate(toDate);
      this.profileDetails.centerId = browser.params.data.centerIdForCenterCalendarRealm.centerIdForCalendarOne;
      this.serviceUtils.deleteAllEventsAndAppliedProfiles(hqUser, formattedFromDate, formattedToDate, true, this.profileDetails);

      this.addProfile();

      browser.get(browser.params.data.baseUrl);

      let user: User = new User();
      user.username = browser.params.data.validCenterUser.username;
      user.password = browser.params.data.validCenterUser.password;
      let loginPage: LoginPage = new LoginPage().confirmPageHasLoaded();
      let calendarPage: CalendarPage = loginPage.login(browser.params.data.validCenterUser.username, browser.params.data.validCenterUser.password);
      calendarPage.confirmPageHasLoaded();

      return promise.all([
        expect(calendarPage.readCurrentDate()).to.eventually.be.not.null
      ]);
    }

  @given(/^I login to the Crew Service Calendar application as an HQ user$/)
  public loginToCrewServiceCalendarAppAsHqUser(): Promise<any[]> {
    // SETUP - delete applied profiles and add a new one
    let user: User = new User();
    user.username = browser.params.data.validHqUser.username;
    user.password = browser.params.data.validHqUser.password;
    let fromDate = this.utils.getCurrentSystemDateAsString();
    let formattedFromDate = this.utils.reFormatDate(fromDate);
    let toDate = this.utils.addDaysAsString(this.utils.getCurrentSystemDate(), 90);
    let formattedToDate = this.utils.reFormatDate(toDate);
    this.profileDetails.centerId = browser.params.data.centerIdForCenterCalendarRealm.centerIdForCalendarOne;
    this.serviceUtils.deleteAllEventsAndAppliedProfiles(user, formattedFromDate, formattedToDate, true, this.profileDetails);

    this.addProfile();

    browser.get(browser.params.data.baseUrl);

    let loginPage: LoginPage = new LoginPage().confirmPageHasLoaded();
    let calendarPage: CalendarPage = loginPage.login(browser.params.data.validHqUser.username, browser.params.data.validHqUser.password);
    calendarPage.confirmPageHasLoaded();
    calendarPage.getHeaderComponent().selectCenter(browser.params.data.centerCalendarRealms.stLouis01);

    return promise.all([
      expect(calendarPage.readCurrentDate()).to.eventually.be.not.null
    ]);
  }

    private addProfile(): void {
      let stringGenerator: RandomStringGenerator = new RandomStringGenerator();
      let profileInfo = new ProfileDetails();
      profileInfo.profileName = stringGenerator.getRandomString(6);
      profileInfo.eventsCountOnSunday = 6;
      profileInfo.eventsCountOnMonday = 6;
      profileInfo.eventsCountOnTuesday = 6;
      profileInfo.eventsCountOnWednesday = 6;
      profileInfo.eventsCountOnThursday = 6;
      profileInfo.eventsCountOnFriday = 6;
      profileInfo.eventsCountOnSaturday = 6;

      let date = this.utils.getCurrentSystemDateAsString();
      let currentDate = this.utils.reFormatDate(date);
      let addMonth = this.utils.addDaysAsString(new Date(), +60);
      let futureMonth = this.utils.reFormatDate(addMonth);

      let userInfo = new User();
      userInfo.username = browser.params.data.validHqUser.username;
      userInfo.password = browser.params.data.validHqUser.password;
      profileInfo.centerId = browser.params.data.centerIdForCenterCalendarRealm.centerIdForCalendarOne;
      this.serviceUtils.applyProfileThrApi(profileInfo, currentDate, futureMonth, userInfo, true);
    }

    @when(/^I click on the 'Today' button$/)
    public clickToday(callback: CallbackStepDefinition): void {
      let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
      calendarPage.getHeaderComponent().clickTodayButton();
      callback();
    }

    @then(/^today's date is highlighted$/)
    public displayTodayDate(): Promise<any[]> {
      let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
      return promise.all([
        expect(calendarPage.readCurrentDate()).to.eventually.equal(this.utils.getCurrentSystemDateAsString(), 'Date did not match')
      ]);
    }

    @when(/^I click on the left arrow$/)
    public clickPreviousMonthButton(callback: CallbackStepDefinition): void {
      let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
      calendarPage.getHeaderComponent().clickLeftArrow();
      callback();
    }

    @then(/^the previous month calendar is displayed$/)
    public previousMonthIsDisplayed(): Promise<any[]> {
      let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
      return promise.all([
        expect(calendarPage.getHeaderComponent().readCurrentCalendarDate()).to.eventually.contains(this.utils.getMonthName(this.utils.getCurrentSystemMonth()-1),
          'Previous month is not displayed after clicking left arrow')
      ]);
    }

    @when(/^I click on the right arrow$/)
    public clickFutureMonthButton(callback: CallbackStepDefinition): void {
      let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
      calendarPage.getHeaderComponent().clickRightArrow();
      callback();
    }

    @then(/^the future month calendar is displayed$/)
    public futureMonthIsDisplayed(): Promise<any[]> {
      let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
      return promise.all([
        expect(calendarPage.getHeaderComponent().readCurrentCalendarDate()).to.eventually.contains(this.utils.getMonthName(this.utils.getCurrentSystemMonth()+1),
          'Future month is not displayed after clicking right arrow')
      ]);
    }

    @when(/^I click on the 'Month' button$/)
    public clickMonthButton(callback: CallbackStepDefinition): void {
      let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
      calendarPage.getHeaderComponent().clickMonthButton();
      callback();
    }

    @then(/^I am able to view 'Month' calendar$/)
    public viewMonthCalendar(): Promise<any[]> {
      let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
      return promise.all([
        expect(calendarPage.getClassAttributeOfCalendarView(), 'User is not able to view month calendar').to.eventually.contain('month-view')
      ]);
    }

    @when(/^user clicks on 'Week' button$/)
    public clickWeekButton(callback: CallbackStepDefinition): void {
      let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
      calendarPage.getHeaderComponent().clickWeekButton();
      let weekCalendarPage: WeekCalendarPage = new WeekCalendarPage().confirmPageHasLoaded();
      callback();
    }

    @when(/^user clicks on 'Day' button$/)
    public clickDayButton(callback: CallbackStepDefinition): void {
      let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
      calendarPage.getHeaderComponent().clickDayButton();
      let dayCalendarPage: DayCalendarPage = new DayCalendarPage().confirmPageHasLoaded();
      callback();
    }

    @then(/^user is able to view 'Week' calendar$/)
    public viewWeekCalendar(): Promise<any[]> {
      let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
      return promise.all([
        expect(calendarPage.getClassAttributeOfCalendarView(), 'User is not able to view week calendar').to.eventually.contain('Week-view')
      ]);
    }

    @then(/^user is able to view 'Day' calendar$/)
    public viewDayCalendar(): Promise<any[]> {
      let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
      return promise.all([
        expect(calendarPage.getClassAttributeOfCalendarView(), 'User is not able to view day calendar').to.eventually.contain('Day-view')
      ]);
    }

}

export = CalendarStepDefinitions;
