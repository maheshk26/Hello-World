import {binding, given, when, then, before} from 'cucumber-tsflow';
import {browser, by, element, protractor} from 'protractor';
import {expect} from '../support/asserts.config';
import {LoginPage} from '../../pages/login.page';
import {CalendarPage} from '../../pages/calendar.page';
import {promise} from 'selenium-webdriver';
import {AdministrationPage} from '../../pages/admin/administration.page';
import {AddNewProfileComponent} from '../../pages/components/add.new.profile.component';
import {RandomStringGenerator} from '../support/random_string_generator';
import {ProfileDetails} from '../../models/profile_details';
import {ApplyProfileToCalendarComponent} from '../../pages/components/apply.profile.to.calendar.component';
import {ServiceUtils} from '../support/service.utils';
import {Utils} from '../support/utils';
import {CallbackStepDefinition} from 'cucumber';
import {User} from '../../models/user';
import {EventStatus} from '../../enums/event.status';

@binding()
class AdminAddProfileStepDefinitions {

  private profileDetails: ProfileDetails = new ProfileDetails();
  private serviceUtils: ServiceUtils = new ServiceUtils();
  private utils: Utils = new Utils();
  private stringGenerator: RandomStringGenerator = new RandomStringGenerator();

  @before('@DeleteAppliedProfile')
  public clearAllAppliedProfile() :void {
    let user: User = new User();
    user.username = browser.params.data.validHqUser.username;
    user.password = browser.params.data.validHqUser.password;

    let fromDate = this.utils.getCurrentSystemDateAsString();
    let formattedFromDate = this.utils.reFormatDate(fromDate);
    let toDate = this.utils.addDaysAsString(this.utils.getCurrentSystemDate(), 90);
    let formattedToDate = this.utils.reFormatDate(toDate);
    this.profileDetails.centerId = browser.params.data.centerIdForCenterCalendarRealm.centerIdForCalendarOne;
    this.serviceUtils.deleteAllEventsAndAppliedProfiles(user, formattedFromDate, formattedToDate, true, this.profileDetails);
  }

  @given(/^COE calendar exists$/)
  public coeCalendarExists(): Promise<any[]> {
    browser.get(browser.params.data.baseUrl);
    let loginPage: LoginPage = new LoginPage().confirmPageHasLoaded();
    loginPage.login(browser.params.data.validCenterUser.username, browser.params.data.validCenterUser.password);
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    return promise.all([
      expect(calendarPage.getHeaderComponent().readCurrentCalendarDate(), 'Login was not successful').to.eventually.not.be.null
    ]);
  }

  @when(/^I navigate to an Administration section$/)
  public navigateToAdminSection(callback: CallbackStepDefinition): void {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    calendarPage.getHeaderComponent().getLeftNavComponent().clickAdministrationMenuLink();
    callback();
  }

  @when(/^I add a standard profile having set 6 events except Sunday and Saturday$/)
  public addStandardProfile(): Promise<any[]> {
    let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();
    let addNewProfileComponent : AddNewProfileComponent = adminPage.clickAddNewCewAvailabilityProfile();

    this.profileDetails = new ProfileDetails(browser.params.data.addProfileDetails);
    this.profileDetails.profileName = this.stringGenerator.getRandomString(6);
    addNewProfileComponent.enterProfileName(this.profileDetails.profileName);

    this.profileDetails.eventsCountOnSunday = 0;
    this.profileDetails.eventsCountOnMonday = 6;
    this.profileDetails.eventsCountOnTuesday = 6;
    this.profileDetails.eventsCountOnWednesday = 6;
    this.profileDetails.eventsCountOnThursday = 6;
    this.profileDetails.eventsCountOnFriday = 6;
    this.profileDetails.eventsCountOnSaturday = 0;

    addNewProfileComponent.enterSlotsForEachDay(this.profileDetails);

    return promise.all([
      addNewProfileComponent.clickAddProfileButton()
    ]);
  }

  @then(/^the created profile is added to the crew availability profiles grid$/)
  public standardProfileAddedToTheGrid(): Promise<any[]> {
    let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();

    return promise.all ([
      expect(adminPage.isProfilePresent(this.profileDetails.profileName),
        'New Profile ' + this.profileDetails.profileName + 'is not added to the grid').to.eventually.be.true,
      expect(adminPage.readAvailabilitySlotValue(this.profileDetails.profileName, 'Sun'),
        'Availability slot value for sunday is not as expected').to.eventually.equal(this.profileDetails.eventsCountOnSunday),
      expect(adminPage.readAvailabilitySlotValue(this.profileDetails.profileName, 'Mon'),
        'Availability slot value for monday is not as expected').to.eventually.equal(this.profileDetails.eventsCountOnMonday),
      expect(adminPage.readAvailabilitySlotValue(this.profileDetails.profileName, 'Tue'),
        'Availability slot value for tuesday is not as expected').to.eventually.equal(this.profileDetails.eventsCountOnTuesday),
      expect(adminPage.readAvailabilitySlotValue(this.profileDetails.profileName, 'Wed'),
        'Availability slot value for wednesday is not as expected').to.eventually.equal(this.profileDetails.eventsCountOnWednesday),
      expect(adminPage.readAvailabilitySlotValue(this.profileDetails.profileName, 'Thu'),
        'Availability slot value for thursday is not as expected').to.eventually.equal(this.profileDetails.eventsCountOnThursday),
      expect(adminPage.readAvailabilitySlotValue(this.profileDetails.profileName, 'Fri'),
        'Availability slot value for friday is not as expected').to.eventually.equal(this.profileDetails.eventsCountOnFriday),
      expect(adminPage.readAvailabilitySlotValue(this.profileDetails.profileName, 'Sat'),
        'Availability slot value for saturday is not as expected').to.eventually.equal(this.profileDetails.eventsCountOnSaturday),
    ]);
  }

  @when(/^I click actions and select Apply to Calendar$/)
  public clickApplyToCalendar(): Promise<any[]> {
    let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();

    return promise.all([
      adminPage.clickApplyProfile(this.profileDetails.profileName)
    ]);
  }

  @when(/^I click select a date range and choose the date range from the calendar$/)
  public clickSelectDateRangeAndChooseRange(): Promise<any[]> {
    let applyProfileToCalendarComponent: ApplyProfileToCalendarComponent = new ApplyProfileToCalendarComponent().confirmComponentHasLoaded();
    applyProfileToCalendarComponent.clickSelectDateRange();
    return promise.all([
      applyProfileToCalendarComponent.selectDateRangeFromCurrentDateThroughDays(10)
    ]);
  }

  @when(/^I click Apply to calendar button in Apply profile to calendar component$/)
  public clickApplyToCalendarButton(): Promise<any[]> {
    let applyProfileToComponent: ApplyProfileToCalendarComponent = new ApplyProfileToCalendarComponent().confirmComponentHasLoaded();
    return promise.all([
      applyProfileToComponent.clickApplyToCalendarButton()
    ]);
  }

  @then(/^the applied profile is added to the Applied Crew Profiles grid$/)
  public appliedProfileIsAddedToTheGrid(): Promise<any[]> {
    let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();
    return promise.all([
      expect(adminPage.isProfileApplied(this.profileDetails.profileName),
        'The profile ' + this.profileDetails.profileName + ' was not applied to the calendar').to.eventually.be.true
    ]);
  }

  @when(/^I navigate back to calendar page$/)
  public navigateToCalendarPage(callback: CallbackStepDefinition): void {
    let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();
    adminPage.getHeaderComponent().getLeftNavComponent().clickCalendarMenuLink();
    callback()
  }

  @then(/^I verify the event slots are added to the calendar$/)
  public eventSlotsAreAddedToCalendar(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let currentDate = this.utils.getCurrentSystemDate();

    let sunday = this.profileDetails.eventsCountOnSunday;
    let monday = this.profileDetails.eventsCountOnMonday;
    let tuesday = this.profileDetails.eventsCountOnTuesday;
    let wednesday = this.profileDetails.eventsCountOnWednesday;
    let thursday = this.profileDetails.eventsCountOnThursday;
    let friday = this.profileDetails.eventsCountOnFriday;
    let saturday = this.profileDetails.eventsCountOnSaturday;

    for (let i =0 ; i<7 ; i++) {
      let slot = 0;
      let date = this.utils.addDaysAsDate(currentDate, i);
      let weekDay = date.getDay();
      let weekName = this.utils.getWeekName(weekDay);
        switch (weekName){
          case 'sun' :
            slot =  sunday;
            break;
          case 'mon' :
            slot =  monday;
            break;
          case 'tue' :
            slot =  tuesday;
            break;
          case 'wed' :
            slot =  wednesday;
            break;
          case 'thu' :
            slot =  thursday;
            break;
          case 'fri' :
            slot =  friday;
            break;
          case 'sat' :
            slot =  saturday;
            break;
        }
        calendarPage.getHeaderComponent().selectSpecificYearAndMonth(this.utils.getDayInStringFormat(date));
        expect(calendarPage.readSlots(this.utils.getDayInStringFormat(date), EventStatus.AVAILABLE),
            "Applied slots are not added to the calendar " + date).to.eventually.equal(slot)
    }

    return promise.all([
      expect(calendarPage.readCurrentDate()).to.eventually.equal(this.utils.getDayInStringFormat(new Date()))
    ]);
  }

  @when(/^I add a zero profile$/)
  public addZeroProfile(): Promise<any[]> {
    let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();
    let addNewProfileComponent : AddNewProfileComponent = adminPage.clickAddNewCewAvailabilityProfile();

    this.profileDetails = new ProfileDetails(browser.params.data.addProfileDetails);
    this.profileDetails.profileName = this.stringGenerator.getRandomString(6);
    addNewProfileComponent.enterProfileName(this.profileDetails.profileName);

    this.profileDetails.eventsCountOnSunday = 0;
    this.profileDetails.eventsCountOnMonday = 0;
    this.profileDetails.eventsCountOnTuesday = 0;
    this.profileDetails.eventsCountOnWednesday = 0;
    this.profileDetails.eventsCountOnThursday = 0;
    this.profileDetails.eventsCountOnFriday = 0;
    this.profileDetails.eventsCountOnSaturday = 0;

    addNewProfileComponent.enterSlotsForEachDay(this.profileDetails);

    return promise.all([
      addNewProfileComponent.clickAddProfileButton()
    ]);
  }

  @when(/^I add a single day profile$/)
  public addSingleDayProfile(): void {
    let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();
    let addNewProfileComponent: AddNewProfileComponent = adminPage.clickAddNewCewAvailabilityProfile();

    this.profileDetails = new ProfileDetails(browser.params.data.addProfileDetails);
    this.profileDetails.profileName = this.stringGenerator.getRandomString(6);
    addNewProfileComponent.enterProfileName(this.profileDetails.profileName);

    this.profileDetails.eventsCountOnSunday = 0;
    this.profileDetails.eventsCountOnMonday = 0;
    this.profileDetails.eventsCountOnTuesday = 0;
    this.profileDetails.eventsCountOnWednesday = this.stringGenerator.getRandomNumberInRange(0,50);
    this.profileDetails.eventsCountOnThursday = 0;
    this.profileDetails.eventsCountOnFriday = 0;
    this.profileDetails.eventsCountOnSaturday = 0;
    addNewProfileComponent.enterWednesdaySlotValue(this.profileDetails.eventsCountOnWednesday);
    addNewProfileComponent.clickAddProfileButton();

  }

  @when(/^I add a profile serving 50 event slots for all the days$/)
  public addProfileServingFiftySlots(): void {
    let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();
    let addNewProfileComponent: AddNewProfileComponent = adminPage.clickAddNewCewAvailabilityProfile();

    this.profileDetails = new ProfileDetails(browser.params.data.addProfileDetails);
    this.profileDetails.profileName = this.stringGenerator.getRandomString(6);
    addNewProfileComponent.enterProfileName(this.profileDetails.profileName);

    this.profileDetails.eventsCountOnSunday = 50;
    this.profileDetails.eventsCountOnMonday = 50;
    this.profileDetails.eventsCountOnTuesday = 50;
    this.profileDetails.eventsCountOnWednesday = 50;
    this.profileDetails.eventsCountOnThursday = 50;
    this.profileDetails.eventsCountOnFriday = 50;
    this.profileDetails.eventsCountOnSaturday = 50;

    addNewProfileComponent.enterSlotsForEachDay(this.profileDetails);
    addNewProfileComponent.clickAddProfileButton();
  }

  @when(/^I add a profile serving random number of event slots for all the days$/)
  public addProfileServingRandomSlots(): void {
    let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();
    let addNewProfileComponent: AddNewProfileComponent = adminPage.clickAddNewCewAvailabilityProfile();

    this.profileDetails = new ProfileDetails(browser.params.data.addProfileDetails);
    this.profileDetails.profileName = this.stringGenerator.getRandomString(6);
    addNewProfileComponent.enterProfileName(this.profileDetails.profileName);

    this.profileDetails.eventsCountOnSunday = this.stringGenerator.getRandomNumberInRange(0,50);
    this.profileDetails.eventsCountOnMonday = this.stringGenerator.getRandomNumberInRange(0,50);
    this.profileDetails.eventsCountOnTuesday = this.stringGenerator.getRandomNumberInRange(0,50);
    this.profileDetails.eventsCountOnWednesday = this.stringGenerator.getRandomNumberInRange(0,50);
    this.profileDetails.eventsCountOnThursday = this.stringGenerator.getRandomNumberInRange(0,50);
    this.profileDetails.eventsCountOnFriday = this.stringGenerator.getRandomNumberInRange(0,50);
    this.profileDetails.eventsCountOnSaturday = this.stringGenerator.getRandomNumberInRange(0,50);

    addNewProfileComponent.enterSlotsForEachDay(this.profileDetails);
    addNewProfileComponent.clickAddProfileButton();
  }

  @when(/^I delete the applied profile$/)
  public deleteAppliedProfile(): void {
    let user: User = new User();
    user.username = browser.params.data.validHqUser.username;
    user.password = browser.params.data.validHqUser.password;
    this.serviceUtils.deleteProfileThrApi(user,this.profileDetails, false);
  }

  @when(/^I try to apply the existing profile for the same date range$/)
  public addExistingProfileForSameDateRange(): Promise<any[]> {
    let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();
    adminPage.clickEllipsisInAvailabilityProfileTable(this.profileDetails.profileName);
    let applyProfileToCalendarComponent: ApplyProfileToCalendarComponent = new ApplyProfileToCalendarComponent().confirmComponentHasLoaded();
    applyProfileToCalendarComponent.clickSelectDateRange();
    applyProfileToCalendarComponent.selectDateRangeFromCurrentDateThroughDays(10);

    return promise.all([
      applyProfileToCalendarComponent.clickApplyToCalendarButton()
    ]);
  }

  @then(/^I see error message on apply profile component "(.*)"$/)
  public seeErrorMessageOnApplyProfileComponent(expectedErrorMsg: string): Promise<any[]> {
    let applyProfileToCalendarComponent: ApplyProfileToCalendarComponent = new ApplyProfileToCalendarComponent().confirmComponentHasLoaded();
    return promise.all([
      expect(applyProfileToCalendarComponent.readErrorMessage(),'Appropriate apply profile to calendar message is not present').to.eventually.equal(expectedErrorMsg),
    ]);
  }

  @when(/^I try to add profile name extending maximum character$/)
  public addProfileNameMaxChar(): Promise<any[]> {
    let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();
    let addNewProfileComponent: AddNewProfileComponent = adminPage.clickAddNewCewAvailabilityProfile();
    this.profileDetails = new ProfileDetails(browser.params.data.addProfileDetails);
    this.profileDetails.profileName = this.stringGenerator.getRandomString(30);
    addNewProfileComponent.enterProfileName(this.profileDetails.profileName);

    return promise.all([
      expect(addNewProfileComponent.readProfileName(),
        'Incorrect profile name entered').to.eventually.equal(this.profileDetails.profileName)
    ]);
  }

  @then(/^I see the error message for profile name "(.*)"$/)
  public profileNameErrorMessage(expectedErrorMsg: string): Promise<any[]>{
    let addNewProfileComponent : AddNewProfileComponent = new AddNewProfileComponent().confirmComponentHasLoaded();
    return promise.all([
      expect(addNewProfileComponent.readProfileNameErrorMessage(),
        'The error message is not appropriate').to.eventually.equal(expectedErrorMsg)
    ]);
  }

  @when(/^I try to clear the profile name field$/)
  public clearProfileName(): Promise<any[]> {
    let addNewProfileComponent : AddNewProfileComponent = new AddNewProfileComponent().confirmComponentHasLoaded();
    addNewProfileComponent.clearProfileName();

    return promise.all([
      expect(addNewProfileComponent.readProfileName(), 'Profile name should be empty').to.eventually.equal('')
    ]);
  }

  @when(/^I try to enter slot value above 50$/)
  public enterSlotValueAboveFifty(): Promise<any[]> {
    let addNewProfileComponent : AddNewProfileComponent = new AddNewProfileComponent().confirmComponentHasLoaded();
    this.profileDetails = new ProfileDetails(browser.params.data.addProfileDetails);
    this.profileDetails.eventsCountOnSunday = 0;
    this.profileDetails.eventsCountOnMonday = 78;
    addNewProfileComponent.enterSundaySlotValue(this.profileDetails.eventsCountOnSunday);
    addNewProfileComponent.enterMondaySlotValue(this.profileDetails.eventsCountOnMonday);

    return promise.all([
      expect(addNewProfileComponent.readSundaySlotValue(),
        'Incorrect value entered for Sunday slots').to.eventually.equal(this.profileDetails.eventsCountOnSunday.toString()),
      expect(addNewProfileComponent.readMondaySlotValue(),
        'Incorrect value entered for Monday slots').to.eventually.equal(this.profileDetails.eventsCountOnMonday.toString())
    ]);
  }

  @when(/^I try to enter slot value less than zero$/)
  public enterNegativeSlotValue(): Promise<any[]> {
    let addNewProfileComponent : AddNewProfileComponent = new AddNewProfileComponent().confirmComponentHasLoaded();
    this.profileDetails = new ProfileDetails(browser.params.data.addProfileDetails);
    this.profileDetails.eventsCountOnWednesday = -8;
    addNewProfileComponent.enterWednesdaySlotValue(this.profileDetails.eventsCountOnWednesday);

    return promise.all([
      expect(addNewProfileComponent.readWednesdaySlotValue(),
        'Incorrect value entered for Wednesday slots').to.eventually.equal(this.profileDetails.eventsCountOnWednesday.toString())
    ]);
  }

  @when(/^I try to enter slot with decimal value$/)
  public enterDecimalSlotValue(): Promise<any[]> {
    let addNewProfileComponent : AddNewProfileComponent = new AddNewProfileComponent().confirmComponentHasLoaded();
    this.profileDetails = new ProfileDetails(browser.params.data.addProfileDetails);
    addNewProfileComponent.enterThursdaySlotFloatValue('.9');

    return promise.all([
      expect(addNewProfileComponent.readThursdaySlotValue(),
        'Incorrect value entered for Thursday slots').to.eventually.equal('.9')
    ]);
  }

  @when(/^I try to enter slot with alpha numeric value$/)
  public enterAlphaNumericSlotValue(): Promise<any[]> {
    let addNewProfileComponent : AddNewProfileComponent = new AddNewProfileComponent().confirmComponentHasLoaded();
    this.profileDetails = new ProfileDetails(browser.params.data.addProfileDetails);
    addNewProfileComponent.enterFridaySlotStringValue('a3');

    return promise.all([
      expect(addNewProfileComponent.readFridaySlotValue(),
        'Incorrect value entered for Frdiay slots').to.eventually.equal('a3')
    ]);
  }

  @then(/^I read appropriate error message "(.*)"$/)
  public appropriateErrorMessage(expectedErrorMessage: string): Promise<any[]> {
    let addNewProfileComponent : AddNewProfileComponent = new AddNewProfileComponent().confirmComponentHasLoaded();
    return promise.all([
      expect(addNewProfileComponent.readAppropriateErrorMessage(),'The error message is not appropriate').to.eventually.equal(expectedErrorMessage)
    ]);
  }

  @when(/^I cancel out of the add new profile$/)
  public clickCancelButton(): Promise<any[]> {
    let addNewProfileComponent : AddNewProfileComponent = new AddNewProfileComponent().confirmComponentHasLoaded();
    return promise.all([
      addNewProfileComponent.clickCancelBtn()
    ]);
  }

  @given(/^I apply profile through api$/)
  public applyProfileThrApi(): void {
    let profileInfo = new ProfileDetails();
    profileInfo.profileName = this.stringGenerator.getRandomString(6);
    profileInfo.eventsCountOnSunday = 6;
    profileInfo.eventsCountOnMonday = 6;
    profileInfo.eventsCountOnTuesday = 6;
    profileInfo.eventsCountOnWednesday = 6;
    profileInfo.eventsCountOnThursday = 6;
    profileInfo.eventsCountOnFriday = 6;
    profileInfo.eventsCountOnSaturday = 6;


    let date = this.utils.getCurrentSystemDateAsString();
    let currentDate = this.utils.reFormatDate(date);
    let addMonth = this.utils.addDaysAsString(new Date(),+60);
    let futureMonth = this.utils.reFormatDate(addMonth);

    let userInfo = new User();
    userInfo.username = browser.params.data.validCenterUser.username;
    userInfo.password = browser.params.data.validCenterUser.password;
    this.serviceUtils.applyProfileThrApi(profileInfo,currentDate,futureMonth,userInfo,false);
  }

  @when(/^I delete all the applied profile through api$/)
  public deleteAllProfileTroughApi(): void {
    let user: User = new User();
    user.username = browser.params.data.validHqUser.username;
    user.password = browser.params.data.validHqUser.password;
    this.serviceUtils.deleteAllAppliedProfileUsingApi(user);

  }

}

export = AdminAddProfileStepDefinitions;

