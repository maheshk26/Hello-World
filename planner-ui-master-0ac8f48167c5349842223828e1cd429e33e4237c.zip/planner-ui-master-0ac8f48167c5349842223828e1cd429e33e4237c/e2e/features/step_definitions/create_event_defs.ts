import {binding, given, when, then} from 'cucumber-tsflow';
import {CallbackStepDefinition} from 'cucumber';
import {CreateEventComponent} from '../../pages/components/create.event.component';
import {browser} from "protractor";
import {expect} from '../support/asserts.config';
import {RandomStringGenerator} from '../support/random_string_generator';
import {EventDetails} from '../../models/event_details';
import {CalendarPage} from '../../pages/calendar.page';
import {ServiceUtils} from '../support/service.utils';
import {promise} from 'selenium-webdriver';
import {WeekCalendarPage} from '../../pages/weekcalendar.page';
import {DayCalendarPage} from '../../pages/daycalendar.page';
import {Utils} from '../support/utils';
import {EventStatus} from '../../enums/event.status';
import {User} from '../../models/user';

@binding()
class CreateEventStepDefinitions {

  private eventDetails: EventDetails;
  private stringGenerator: RandomStringGenerator = new RandomStringGenerator();
  private serviceUtils: ServiceUtils = new ServiceUtils();
  private utils: Utils = new Utils();

  @when(/^user enters valid data in required fields$/)
  public enterValidData(): Promise<any[]> {
    let createEventComponent: CreateEventComponent = new CreateEventComponent().confirmComponentIsAvailable();
    this.eventDetails = new EventDetails(browser.params.data.createNewEventValidData);
    this.eventDetails.customerName = this.stringGenerator.getRandomString(6);
    this.eventDetails.zipCode = this.stringGenerator.getRandomNumber(5);
    this.eventDetails.orderNumber = this.stringGenerator.getRandomAlphaNumericString(30);
    this.eventDetails.opportunityNumber = this.stringGenerator.getRandomAlphaNumericString(30);
    this.eventDetails.estimateNumber = this.stringGenerator.getRandomAlphaNumericString(30);
    createEventComponent.enterCustomerName(this.eventDetails.customerName);
    createEventComponent.selectLocationType(browser.params.data.createNewEventValidData.locationType);
    createEventComponent.enterZipCode(this.eventDetails.zipCode);
    createEventComponent.selectShipmentType(browser.params.data.shipmentType);
    createEventComponent.enterOrderNumber(this.eventDetails.orderNumber);
    createEventComponent.enterTrackingNumber(this.eventDetails.opportunityNumber);
    createEventComponent.enterQuoteNumber(this.eventDetails.estimateNumber);

    return promise.all([
      expect(createEventComponent.readCustomerName(),
        'Incorrect customer name').to.eventually.equal(this.eventDetails.customerName),
      expect(createEventComponent.readZipCode(),
        'Incorrect zip code').to.eventually.equal(this.eventDetails.zipCode),
      expect(createEventComponent.readOrderNumber(),
        'Incorrect order number').to.eventually.equal(this.eventDetails.orderNumber),
      expect(createEventComponent.readTrackingNumber(),
        'Incorrect tracking number').to.eventually.equal(this.eventDetails.opportunityNumber),
      expect(createEventComponent.readQuoteNumber(),
        'Incorrect quote number').to.eventually.equal(this.eventDetails.estimateNumber),
    ]);
  }

  @when(/^when they click Add Event$/)
  public clickAddEvent(): Promise<any>{
    let createEventComponent: CreateEventComponent = new CreateEventComponent().confirmComponentIsAvailable();
    return createEventComponent.clickAddEvent();
  }

  @then(/^the event is created and booked in day view$/)
  public eventCreatedAndBookedInDayView(): Promise<any[]> {
    let customerNameDisplayed = this.eventDetails.customerName;
    let dayCalendarPage: DayCalendarPage = new DayCalendarPage().confirmPageHasLoaded();

    return promise.all([
      expect(dayCalendarPage.isEventBookedInDayView(customerNameDisplayed),
        'New event for ' + customerNameDisplayed + ' was not created').to.eventually.be.true
    ]);
  }

  @then(/^the event is created and booked in week view$/)
  public eventCreatedAndBookedInWeekView(): Promise<any[]> {
    let weekCalendarPage: WeekCalendarPage = new WeekCalendarPage().confirmPageHasLoaded();
    let date = this.utils.getCurrentSystemDateAsString();
    let customerNameDisplayed = this.eventDetails.customerName;

    return promise.all([
      expect(weekCalendarPage.isEventBookedInWeekView(date, customerNameDisplayed),
        'New event for ' + customerNameDisplayed + ' was not created').to.eventually.be.true
    ]);
  }

  @then(/^the event is created and booked in month view$/)
  public eventCreatedAndBookedForCurrentDateInMonthCalendar(): Promise<any[]> {
    let customerNameDisplayed = this.eventDetails.customerName;
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let date = this.utils.getCurrentSystemDateAsString();

    return promise.all([
      expect(calendarPage.isEventBookedInMonthView(date, customerNameDisplayed),
        'New event for ' + customerNameDisplayed + ' was not created').to.eventually.be.true
    ]);
  }

  @when(/^user enters invalid data$/)
  public enterInvalidData(): Promise<any[]> {
    let createEventComponent: CreateEventComponent = new CreateEventComponent().confirmComponentIsAvailable();
    createEventComponent.enterCustomerName(browser.params.data.createNewEventValidData.customerName);
    createEventComponent.enterZipCode(browser.params.data.createNewEventInvalidData.zipCode);
    createEventComponent.enterOrderNumber(browser.params.data.createNewEventInvalidData.orderNumber);
    createEventComponent.enterTrackingNumber(browser.params.data.createNewEventInvalidData.opportunityNumber);
    createEventComponent.enterQuoteNumber(browser.params.data.createNewEventInvalidData.estimateNumber);

    return promise.all([
      expect(createEventComponent.readCustomerName(),
        'Incorrect customer name entered').to.eventually.equal(browser.params.data.createNewEventValidData.customerName),
      expect(createEventComponent.readZipCode(),
        'Incorrect zip code entered').to.eventually.equal(browser.params.data.createNewEventInvalidData.zipCode),
      expect(createEventComponent.readOrderNumber(),
        'Incorrect order number entered').to.eventually.equal(browser.params.data.createNewEventInvalidData.orderNumber),
      expect(createEventComponent.readTrackingNumber(),
        'Incorrect tracking number entered').to.eventually.equal(browser.params.data.createNewEventInvalidData.opportunityNumber),
      expect(createEventComponent.readQuoteNumber(),
        'Incorrect quote number entered').to.eventually.equal(browser.params.data.createNewEventInvalidData.estimateNumber)
    ]);
  }

  @then(/^the appropriate error messages are displayed for each$/)
  public errorMessagesAreDisplayed(): Promise<any[]> {
    let createEventComponent: CreateEventComponent = new CreateEventComponent().confirmComponentIsAvailable();

    return promise.all([
      expect(createEventComponent.readZipCodeErrorMessage()).to.eventually.contain('Zip Code cannot be more than 5 digits long.',
        'Appropriate zip code error message is not present'),
      expect(createEventComponent.readOrderNumberErrorMessage()).to.eventually.contain('Order Number cannot be more than 32 characters long.',
        'Appropriate order number error message is not present'),
      expect(createEventComponent.readTrackingNumberErrorMessage()).to.eventually.contain('Tracking Number cannot be more than 32 characters long.',
        'Appropriate tracking number error message is not present'),
      expect(createEventComponent.readQuoteNumberErrorMessage()).to.eventually.contain('Quote Number cannot be more than 32 characters long.',
        'Appropriate quote number error message is not present')
    ]);
  }

  @then(/^the event is not created and booked$/)
  public eventNotCreateAndBooked() : Promise<any[]> {
    let createEventComponent: CreateEventComponent = new CreateEventComponent();

    return promise.all([
      expect(createEventComponent.addEventLocator.isEnabled(),
        'Add Event Locator button is not enabled').to.eventually.be.false
    ]);
  }

  @when(/^they clear the required fields$/)
  public clearRequiredfFields(callback: CallbackStepDefinition): void {
    let createEventComponent: CreateEventComponent = new CreateEventComponent().confirmComponentIsAvailable();
      createEventComponent.clearCustomerName();
      createEventComponent.clearZipCode();
      createEventComponent.clearOrderNumber();
      createEventComponent.clearTrackingNumber();
      createEventComponent.clearQuoteNumber().then(callback);
  }

  @then(/^the required fields are flagged with error message$/)
  public requiredFieldsAreFlaggedWithErrorMessages(): Promise<any[]> {
    let createEventComponent: CreateEventComponent = new CreateEventComponent().confirmComponentIsAvailable();
    return promise.all([
      expect(createEventComponent.readCustomerNameErrorMessage()).to.eventually.contain('Customer name is required.',
        'Customer Name error message is not correct'),
      expect(createEventComponent.readZipCodeErrorMessage()).to.eventually.contain('Zip Code is required.',
        'Zip Code error message is not correct'),
      expect(createEventComponent.readOrderNumberErrorMessage()).to.eventually.contain('Order Number is required.',
        'Order Number error message is not correct'),
      expect(createEventComponent.readTrackingNumberErrorMessage()).to.eventually.contain('Tracking Number is required.',
        'Tracking Number error message is not correct'),
      expect(createEventComponent.readQuoteNumberErrorMessage()).to.eventually.contain('Quote Number is required.',
        'Quote Number error message is not correct'),

    ]);
  }

  @when(/^user clicks on cancel button$/)
  public cancelCreateEvent(): Promise<any> {
    let createEventComponent: CreateEventComponent = new CreateEventComponent();
    return createEventComponent.clickCancelButton();
  }

  @when(/^user enters an invalid customer name$/)
  public invalidCustomerName(): Promise<any[]> {
    let createEventComponent: CreateEventComponent = new CreateEventComponent();
    this.eventDetails = new EventDetails(browser.params.data.createNewEventValidData);
    this.eventDetails.zipCode = this.stringGenerator.getRandomNumber(5);
    this.eventDetails.orderNumber = this.stringGenerator.getRandomAlphaNumericString(30);
    this.eventDetails.opportunityNumber = this.stringGenerator.getRandomAlphaNumericString(30);
    this.eventDetails.estimateNumber = this.stringGenerator.getRandomAlphaNumericString(30);
    createEventComponent.enterCustomerName(browser.params.data.createNewEventInvalidData.customerName);
    createEventComponent.enterZipCode(this.eventDetails.zipCode);
    createEventComponent.enterOrderNumber(this.eventDetails.orderNumber);
    createEventComponent.enterTrackingNumber(this.eventDetails.opportunityNumber);
    createEventComponent.enterQuoteNumber(this.eventDetails.estimateNumber);
    createEventComponent.selectLocationType(browser.params.data.createNewEventValidData.locationType);

    return promise.all([
      expect(createEventComponent.readCustomerName(),
        'Incorrect customer name entered').to.eventually.equal(browser.params.data.createNewEventInvalidData.customerName)
    ]);
  }

  @then(/^the appropriate customer name error message is displayed$/)
  public customerNameErrorMessage(): Promise<any> {
    let createEventComponent: CreateEventComponent = new CreateEventComponent();
    return promise.all([
      expect(createEventComponent.invalidCustomerNameError.getText()).to.eventually.contain('Customer name contains invalid characters',
        'Appropriate customer name error message is not present')
      ]);
  }

  @then(/^the error message "(.*)" is displayed$/)
  public couldNotFindAvailableSlotErrorMessage(errorMessage: string): Promise<any> {
    let createEventComponent: CreateEventComponent = new CreateEventComponent();
    return promise.all([
      expect(createEventComponent.readCreateEventErrorMessage()).to.eventually.contain(errorMessage,
        'The error message "Could not find the available event for the date" is not displayed')
    ]);
  }

  @when(/^I can click on available slots on the current date$/)
  public clickAvailableSlotsOnCurrentDate(): Promise<any[]>{
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let date = this.utils.getCurrentSystemDateAsString();
    let createEventComponent: CreateEventComponent = calendarPage.clickSlotsRow(date, EventStatus.AVAILABLE);
    let expectedDay: string = date.split('-')[2].replace(/^0+/, '');

    return promise.all([
      expect(createEventComponent.readComponentHeader(), 'Incorrect header').to.eventually.equal('New Event'),
      expect(createEventComponent.readDayFromCalendarIcon(), 'Incorrect day displayed').to.eventually.equal(expectedDay),
    ]);
  }

  @when(/^I book all available slots with api call for "(.*)"$/)
  public bookAllAvailableSlotsThrApi(date: string): Promise<any[]>{
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let date1 = this.utils.convertDateIntoSpecificFormat(date);
    calendarPage.getHeaderComponent().selectDateFromCalendar(date1);
      calendarPage.readSlots(date1, EventStatus.AVAILABLE).then(number => {
        console.log('Available slots for ' + date1 + ': ' + number);
        for(let i=0; i<number; i++){
          this.serviceUtils.bookThroughApi(date);
        }
    });
    browser.refresh();

    return promise.all([
      expect(calendarPage.readSlots(date, EventStatus.AVAILABLE)).to.eventually.not.be.null
    ]);
  }

  @when(/^user select date from create event component as "(.*)"$/)
  public selectDateFromCreateEventComponent(date: string): Promise<any[]> {
    let createEventComponent: CreateEventComponent = new CreateEventComponent();
    createEventComponent.clickInlineCalendar();
    return promise.all([
      createEventComponent.selectDateFromCreateEventComponent(date)
    ]);
  }

  @when(/^user clicks open slots for current date in week calendar$/)
  public clickOpenSlotsInWeekCalendar(callback: CallbackStepDefinition): void{
    let weekCalendarPage: WeekCalendarPage = new WeekCalendarPage().confirmPageHasLoaded();
    let date = this.utils.getCurrentSystemDateAsString();
    weekCalendarPage.clickOpenSlotsRowInWeekCalendar(date);

    callback();
}

  @when(/^user clicks open slots for the current day in Day calendar$/)
  public clickOpenSlotsInDayCalendar(callback: CallbackStepDefinition): void {
    let dayCalendarPage: DayCalendarPage = new DayCalendarPage().confirmPageHasLoaded();
    let date = this.utils.getCurrentSystemDateAsString();
    dayCalendarPage.clickOpenSlotsRowInDayCalendar(date);

    callback();
  }

  @when(/^user clicks create event button$/)
  public clickCreateEvent(callback: CallbackStepDefinition): void {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    calendarPage.getHeaderComponent().clickCreateEventButton();
    callback();
  }

  @then(/^I cannot create an event on the month calendar$/)
  public cannotCreateEventOnMonthCalendar(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();

    // verify create event button is not present
    expect(calendarPage.getHeaderComponent().isCreateEventBtnPresent(),
      'Create Event button should not be present').to.eventually.be.false;

    // verify available slots are present
    let date = this.utils.getCurrentSystemDateAsString();
    expect(calendarPage.readSlots(date, EventStatus.AVAILABLE), 'There should be available slots').to.eventually.not.equal(0);

    // click on available slot
    return promise.all([
      expect(calendarPage.isAvailableSlotClickable(date), 'Should not be able to click on Available slots').to.eventually.be.false
    ]);
  }

  @then(/^I cannot create an event on the week calendar$/)
  public cannotCreateEventOnWeekCalendar(): Promise<any[]> {
    let weekCalendarPage: WeekCalendarPage = new WeekCalendarPage().confirmPageHasLoaded();

    return promise.all([
      expect(weekCalendarPage.getHeaderComponent().isCreateEventBtnPresent(),
        'Create Event button should not be present').to.eventually.be.false
    ]);
  }

  @then(/^I cannot create an event on the day calendar$/)
  public cannotCreateEventOnDayCalendar(): Promise<any[]> {
    let dayCalendarPage: DayCalendarPage = new DayCalendarPage().confirmPageHasLoaded();

    return promise.all([
      expect(dayCalendarPage.getHeaderComponent().isCreateEventBtnPresent(),
        'Create Event button should not be present').to.eventually.be.false
    ]);
  }
}

export = CreateEventStepDefinitions;

