/** Created by TSXA2 on 5/4/2017. */
import {binding, given, when, then} from 'cucumber-tsflow';
import {browser, by, element, protractor} from 'protractor';
import {expect} from '../support/asserts.config';
import {CalendarPage} from "../../pages/calendar.page";
import {promise} from "selenium-webdriver";
import {AdministrationPage} from "../../pages/admin/administration.page";
import {AddNewProfileComponent} from "../../pages/components/add.new.profile.component";
import {RandomStringGenerator} from "../support/random_string_generator";
import {ProfileDetails} from "../../models/profile_details";
import {ApplyProfileToCalendarComponent} from "../../pages/components/apply.profile.to.calendar.component";
import {CreateEventComponent} from "../../pages/components/create.event.component";
import {ServiceUtils} from "../support/service.utils";
import {Utils} from "../support/utils";
import {EventDetails} from "../../models/event_details";
import {EventStatus} from '../../enums/event.status';
import {SlotDetails} from '../../models/slot_details';

var world = require('../support/world');

@binding()
class prerequisiteStepDefinitions {

  private eventDetails: EventDetails;
  private serviceUtils: ServiceUtils = new ServiceUtils();
  private utils: Utils = new Utils();
  private stringGenerator: RandomStringGenerator = new RandomStringGenerator();
  private slotDetails: SlotDetails = new SlotDetails();


@when(/^profile has been created$/)
  public profileHasBeenCreated():Promise < any[] > {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let adminPage: AdministrationPage = calendarPage.getHeaderComponent().getLeftNavComponent().clickAdministrationMenuLink();
    let addNewProfileComponent: AddNewProfileComponent = adminPage.clickAddNewCewAvailabilityProfile();

    world.defaultProfileDetails = new ProfileDetails();
    world.defaultProfileDetails.profileName = this.stringGenerator.getRandomString(6);
    addNewProfileComponent.enterProfileName((world.defaultProfileDetails.profileName));
    world.defaultProfileDetails.eventsCountOnSunday = 6;
    world.defaultProfileDetails.eventsCountOnMonday = 6;
    world.defaultProfileDetails.eventsCountOnTuesday = 6;
    world.defaultProfileDetails.eventsCountOnWednesday = 6;
    world.defaultProfileDetails.eventsCountOnThursday = 6;
    world.defaultProfileDetails.eventsCountOnFriday = 6;
    world.defaultProfileDetails.eventsCountOnSaturday = 6;

    addNewProfileComponent.enterSlotsForEachDay(world.defaultProfileDetails);
    addNewProfileComponent.clickAddProfileButton();
    adminPage.confirmPageHasLoaded();

    return promise.all ([
      expect(adminPage.isProfilePresent(world.defaultProfileDetails.profileName),'New Profile ' + world.defaultProfileDetails.profileName + ' was not added to the grid').to.eventually.equal(true),
      expect(adminPage.readAvailabilitySlotValue(world.defaultProfileDetails.profileName, 'Sun'),
        'Availability slot value for sunday is not as expected').to.eventually.equal(world.defaultProfileDetails.eventsCountOnSunday),
      expect(adminPage.readAvailabilitySlotValue(world.defaultProfileDetails.profileName, 'Mon'),
        'Availability slot value for monday is not as expected').to.eventually.equal(world.defaultProfileDetails.eventsCountOnMonday),
      expect(adminPage.readAvailabilitySlotValue(world.defaultProfileDetails.profileName, 'Tue'),
        'Availability slot value for tuesday is not as expected').to.eventually.equal(world.defaultProfileDetails.eventsCountOnTuesday),
      expect(adminPage.readAvailabilitySlotValue(world.defaultProfileDetails.profileName, 'Wed'),
        'Availability slot value for wednesday is not as expected').to.eventually.equal(world.defaultProfileDetails.eventsCountOnWednesday),
      expect(adminPage.readAvailabilitySlotValue(world.defaultProfileDetails.profileName, 'Thu'),
        'Availability slot value for thursday is not as expected').to.eventually.equal(world.defaultProfileDetails.eventsCountOnThursday),
      expect(adminPage.readAvailabilitySlotValue(world.defaultProfileDetails.profileName, 'Fri'),
        'Availability slot value for friday is not as expected').to.eventually.equal(world.defaultProfileDetails.eventsCountOnFriday),
      expect(adminPage.readAvailabilitySlotValue(world.defaultProfileDetails.profileName, 'Sat'),
        'Availability slot value for saturday is not as expected').to.eventually.equal(world.defaultProfileDetails.eventsCountOnSaturday),
    ]);
  }


  @when (/^profile has been applied$/)
  public profileHasbeenApplied(): Promise<any[]> {
    let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();

    adminPage.clickEllipsisInAvailabilityProfileTable(world.defaultProfileDetails.profileName);
    let applyProfileToCalendarComponent: ApplyProfileToCalendarComponent = new ApplyProfileToCalendarComponent().confirmComponentHasLoaded();
    applyProfileToCalendarComponent.clickSelectDateRange();
    applyProfileToCalendarComponent.selectDateRangeFromCurrentDateThroughDays(10);
    applyProfileToCalendarComponent.clickApplyToCalendarButton();
    return promise.all([
      expect(adminPage.isProfileApplied(world.defaultProfileDetails.profileName),
        'The created profile ' + world.defaultProfileDetails.profileName + ' was not applied to the calendar').to.eventually.equal(true)
    ]);
  }

  @when(/^event has been created$/)
  public eventHasBeenCreated():Promise <any[]> {
    let administrationPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();
    let calendarPage: CalendarPage = administrationPage.getHeaderComponent().getLeftNavComponent().clickCalendarMenuLink();
    let createEventComponent = this.createEvent(calendarPage);
    return promise.all([
        createEventComponent.clickAddEvent()
    ]);
  }

  public createEvent(calendarPage: CalendarPage) {
    calendarPage.getHeaderComponent().clickCreateEventButton();
    let createEventComponent: CreateEventComponent = new CreateEventComponent().confirmComponentIsAvailable();

    world.defaultEventDetails = new EventDetails(browser.params.data.createNewEventValidData);
    world.defaultEventDetails.customerName = this.stringGenerator.getRandomString(6);
    world.defaultEventDetails.zipCode = this.stringGenerator.getRandomNumber(5);
    world.defaultEventDetails.orderNumber = this.stringGenerator.getRandomAlphaNumericString(25);
    world.defaultEventDetails.opportunityNumber = this.stringGenerator.getRandomAlphaNumericString(25);
    world.defaultEventDetails.estimateNumber = this.stringGenerator.getRandomAlphaNumericString(25);
    createEventComponent.enterCustomerName(world.defaultEventDetails.customerName);
    createEventComponent.selectLocationType(browser.params.data.createNewEventValidData.locationType);
    createEventComponent.enterZipCode(world.defaultEventDetails.zipCode);
    createEventComponent.selectShipmentType(browser.params.data.createNewEventValidData.shipmentType);
    createEventComponent.enterOrderNumber(world.defaultEventDetails.orderNumber);
    createEventComponent.enterTrackingNumber(world.defaultEventDetails.opportunityNumber);
    createEventComponent.enterQuoteNumber(world.defaultEventDetails.estimateNumber);
    return createEventComponent;
  }

  @when(/^profile has been created and applied for St.Louis centers$/,'',90000)
  public profileHasBeenCreatedAndAppliedForStlCenters(): Promise<any[]> {
    let calendarPage = new CalendarPage().confirmPageHasLoaded();

    calendarPage.getHeaderComponent().selectCenter(browser.params.data.centerCalendarRealms.stLouis01);
    calendarPage.confirmPageHasLoaded();
    expect(calendarPage.getHeaderComponent().readCenter(),
        'Center Calendar was not available').to.eventually.contain(browser.params.data.centerCalendarRealms.stLouis01);
    this.profileHasBeenCreated();
    this.profileHasbeenApplied();
    calendarPage.getHeaderComponent().getLeftNavComponent().clickCalendarMenuLink();

    calendarPage.getHeaderComponent().selectCenter(browser.params.data.centerCalendarRealms.stLouis02);
    calendarPage.confirmPageHasLoaded();
    expect(calendarPage.getHeaderComponent().readCenter(),
      'Center Calendar was not available').to.eventually.contain(browser.params.data.centerCalendarRealms.stLouis02);
    this.profileHasBeenCreated();
    this.profileHasbeenApplied();
    calendarPage.getHeaderComponent().getLeftNavComponent().clickCalendarMenuLink();

    return promise.all([
      expect(calendarPage.getClassAttributeOfCalendarView(), 'User is not able to view month calendar').to.eventually.contain('month-view')
    ])
  }


}
export = prerequisiteStepDefinitions;

