import {binding, given, when, then, before} from 'cucumber-tsflow';
import {browser, by, element, protractor} from 'protractor';
import {expect} from '../support/asserts.config';
import {CalendarPage} from "../../pages/calendar.page";
import {promise} from "selenium-webdriver";
import {AdministrationPage} from "../../pages/admin/administration.page";
import {RandomStringGenerator} from "../support/random_string_generator";
import {ProfileDetails} from "../../models/profile_details";
import {ServiceUtils} from "../support/service.utils";
import {Utils} from "../support/utils";
import {CallbackStepDefinition} from "cucumber";
import {User} from "../../models/user";
import {EventDetails} from "../../models/event_details";
import {EventStatus} from '../../enums/event.status';
import {BookingInformation} from '../../models/booking.information';
import {BookingResponse} from "../../models/booking.response";
import {DayCalendarPage} from "../../pages/daycalendar.page";
import {SlotDetails} from '../../models/slot_details';
import {chain} from '../support/world';
var world = require('../support/world');

@binding()
class reservationsFromQuotes2GoStepDefinations{

    private profileDetails: ProfileDetails;
    private eventDetails: EventDetails;
    private serviceUtils: ServiceUtils = new ServiceUtils();
    private utils: Utils = new Utils();
    private stringGenerator: RandomStringGenerator = new RandomStringGenerator();
    private bookingResponseDetails: BookingResponse = new BookingResponse();
    private bookingInfo: BookingInformation = new BookingInformation();
     private slotDetails: SlotDetails = new SlotDetails();


  @when(/^I apply profile through api for Chicago and Los Angeles Center$/,'',100000)
  public applyProfileThrApi(callback: CallbackStepDefinition): void {

    let profileInfo = new ProfileDetails();
    profileInfo.eventsCountOnSunday = 6;
    profileInfo.eventsCountOnMonday = 6;
    profileInfo.eventsCountOnTuesday = 6;
    profileInfo.eventsCountOnWednesday = 6;
    profileInfo.eventsCountOnThursday = 6;
    profileInfo.eventsCountOnFriday = 6;
    profileInfo.eventsCountOnSaturday = 6;
    let centerCodes  = browser.params.data.applyCenter;

    chain()
      .then(() => {
        for (let i=0;i<centerCodes.length;i++){
          chain()
            .then(() =>{
              profileInfo.profileName = this.stringGenerator.getRandomString(6);
              let data = centerCodes[i];
              let centerIdVal = data.id;
              let centerRealmName = data.centerName;
              profileInfo.centerId = centerIdVal;
              this.createAndApplyProfile(profileInfo,centerRealmName)
            })
            .then(() =>{
              let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();
              adminPage.getHeaderComponent().getLeftNavComponent().clickCalendarMenuLink();
            });
        }
      })
      .then(() => {
        callback();
      });
  }

  private createAndApplyProfile(profileInfo: ProfileDetails, centerName: string):Promise <any>  {
    let userInfo = new User();

    userInfo.username = browser.params.data.validHqUser.username;
    userInfo.password = browser.params.data.validHqUser.password;

    let date = this.utils.getCurrentSystemDateAsString();
    let currentDate = this.utils.reFormatDate(date);
    let addMonth = this.utils.addDaysAsString(this.utils.getCurrentSystemDate(), 60);
    let futureMonth = this.utils.reFormatDate(addMonth);

    this.serviceUtils.applyProfileThrApi(profileInfo, currentDate, futureMonth, userInfo, true);
    let calendarPage = new CalendarPage().confirmPageHasLoaded()
    calendarPage.getHeaderComponent().selectCenter(centerName);
    let adminPage: AdministrationPage = calendarPage.getHeaderComponent().getLeftNavComponent().clickAdministrationMenuLink();

    return promise.all ([
      expect(adminPage.isProfilePresent(profileInfo.profileName),'New Profile ' + profileInfo.profileName + ' was not added to the grid').to.eventually.equal(true),
    ]);
  }

  @when(/^I reserve a booking through api reserved booking should show in those reserved centers$/ ,'',90000)
  public whenReservedBookingEventThroughApi() : Promise<any> {
    this.setUpDataForBookingInfo();
    this.bookingInfo.destinationZipCode = '90001';
     chain()
       .then(() => {

          return this.serviceUtils.reserveEventThroughApi(this.bookingInfo, 200);
        })
       .then((bookingResponseDetails) => {
          this.verifyReservedEvent(this.bookingInfo,bookingResponseDetails);
       });

    let calendarPage = new CalendarPage();

    return promise.all([
      expect(calendarPage.getClassAttributeOfCalendarView(), 'User is not able to view month calendar').to.eventually.contain('month-view')
    ]);
  }

  private setUpDataForBookingInfo() {
    this.bookingInfo.estimateNumber = this.stringGenerator.getRandomNumber(10);
    this.bookingResponseDetails.estimateNo = this.bookingInfo.estimateNumber;
    this.bookingInfo.customerName = this.stringGenerator.getRandomString(6);
    this.bookingInfo.originZipCode = '60687';
    this.bookingInfo.surveyWeightInPounds = this.stringGenerator.getRandomNumber(3);
    let date = this.utils.getCurrentSystemDateAsString();
    let formattedDate = this.utils.reFormatDate(date);
    this.bookingInfo.loadDate = formattedDate;
    let strDate = this.utils.addDaysAsString(this.utils.getCurrentSystemDate(), 2);
    let deliveryDate = this.utils.reFormatDate(strDate);
    this.bookingInfo.deliveryDate = deliveryDate;
    this.bookingInfo.orderNumber = this.stringGenerator.getRandomNumber(9);
    this.bookingInfo.opportunityNumber = this.stringGenerator.getRandomNumber(12);
    this.bookingInfo.timeToExpire = 2;
    this.bookingInfo.temporalUnit = 'DAYS';
    this.bookingInfo.flex = 'false';
  }

  private verifyReservedEvent(bookingInfo:BookingInformation, reservedResponseDetails: any): Promise<any>{
      console.log(reservedResponseDetails);
      this.bookingResponseDetails.originCenterCode = reservedResponseDetails.origin.centerCode;
      this.bookingResponseDetails.originDate = reservedResponseDetails.origin.date;
      this.bookingResponseDetails.destCenterCode = reservedResponseDetails.destination.centerCode;
      this.bookingResponseDetails.destDate = reservedResponseDetails.destination.date;

      //Origin
      let calendarPage = new CalendarPage().confirmPageHasLoaded();

      let centerCode:string = reservedResponseDetails.origin.centerCode;
      calendarPage.getHeaderComponent().selectCenter(centerCode);
      calendarPage.confirmPageHasLoaded();

      calendarPage.getHeaderComponent().selectDateFromCalendar(reservedResponseDetails.origin.date);
      let formattedDate = this.utils.convertDateIntoSpecificFormat(reservedResponseDetails.origin.date);
      let customerNameDisplayed = bookingInfo.customerName;
      expect(calendarPage.isEventReservedInMonthView(formattedDate,customerNameDisplayed),"New Event is Not created").to.eventually.be.true;
      let dayCalendarPage: DayCalendarPage = new DayCalendarPage().confirmPageHasLoaded();
      expect(dayCalendarPage.readShipmentType(customerNameDisplayed),'Shipment type is not visible').to.eventually.contain('CONTAINER');
      expect(dayCalendarPage.readZipCode(customerNameDisplayed), 'Origin zipCode is NOT displayed').to.eventually.contain(bookingInfo.originZipCode);
      expect(dayCalendarPage.readOrderNumber(customerNameDisplayed),'Order number is not visible').to.eventually.contain(bookingInfo.orderNumber);
      expect(dayCalendarPage.readTrackingNumber(customerNameDisplayed),'Tracking number is not visible').to.eventually.contain(bookingInfo.opportunityNumber);
      expect(dayCalendarPage.readQuoteNumber(customerNameDisplayed),'Quote number is not visible').to.eventually.contain(bookingInfo.estimateNumber);
      calendarPage.getHeaderComponent().clickMonthButton();
      calendarPage.confirmPageHasLoaded();
      //destination
      calendarPage.getHeaderComponent().selectCenter(reservedResponseDetails.destination.centerCode)
      calendarPage.confirmPageHasLoaded();
      calendarPage.getHeaderComponent().selectDateFromCalendar(reservedResponseDetails.destination.date);
      formattedDate = this.utils.convertDateIntoSpecificFormat(reservedResponseDetails.destination.date);
      expect(calendarPage.isEventReservedInMonthView(formattedDate,bookingInfo.customerName),"New Event is Not created").to.eventually.be.true;
      expect(dayCalendarPage.readShipmentType(customerNameDisplayed),'Shipment type is not visible').to.eventually.contain('CONTAINER');
      expect(dayCalendarPage.readZipCode(customerNameDisplayed), 'Origin zipCode is NOT displayed').to.eventually.contain(bookingInfo.destinationZipCode);
      expect(dayCalendarPage.readOrderNumber(customerNameDisplayed),'Order number is not visible').to.eventually.contain(bookingInfo.orderNumber);
      expect(dayCalendarPage.readTrackingNumber(customerNameDisplayed),'Tracking number is not visible').to.eventually.contain(bookingInfo.opportunityNumber);
      expect(dayCalendarPage.readQuoteNumber(customerNameDisplayed),'Quote number is not visible').to.eventually.contain(bookingInfo.estimateNumber);
      calendarPage.getHeaderComponent().clickMonthButton();

      return promise.all([
        expect(calendarPage.getClassAttributeOfCalendarView(), 'User is not able to view month calendar').to.eventually.contain('month-view')
      ]);
  }

  @then (/^I confirmed booking through api reserved status should change to booked for that centers$/,'',70000)
  public confirmedBookingEventThruApiReservedStatusChangeToBooked():void {
    let calendarPage = new CalendarPage();
    let dayCalendarPage: DayCalendarPage = new DayCalendarPage();
    let customerNameDisplayed = this.bookingInfo.customerName;

    chain()
      .then(() =>{
        //origin
        this.serviceUtils.bookingEventThroughApi(this.bookingResponseDetails,200);
        let centerCode:string = this.bookingResponseDetails.originCenterCode;
        calendarPage.getHeaderComponent().selectCenter(centerCode);
        calendarPage.confirmPageHasLoaded();

        calendarPage.getHeaderComponent().selectDateFromCalendar(this.bookingResponseDetails.originDate);
        let formattedDate = this.utils.convertDateIntoSpecificFormat(this.bookingResponseDetails.originDate);
        expect(calendarPage.isEventBookedInMonthView(formattedDate,customerNameDisplayed)," New Event Booked is Not created for "+centerCode).to.eventually.be.true;
        dayCalendarPage.confirmPageHasLoaded();
        expect(dayCalendarPage.readShipmentType(customerNameDisplayed),'Shipment type is not visible').to.eventually.contain('CONTAINER');
        expect(dayCalendarPage.readZipCode(customerNameDisplayed), 'Origin zipCode is NOT displayed').to.eventually.contain(this.bookingInfo.originZipCode);
        expect(dayCalendarPage.readOrderNumber(customerNameDisplayed),'Order number is not visible').to.eventually.contain(this.bookingInfo.orderNumber);
        expect(dayCalendarPage.readTrackingNumber(customerNameDisplayed),'Tracking number is not visible').to.eventually.contain(this.bookingInfo.opportunityNumber);
        expect(dayCalendarPage.readQuoteNumber(customerNameDisplayed),'Quote number is not visible').to.eventually.contain(this.bookingInfo.estimateNumber);
        calendarPage.getHeaderComponent().clickMonthButton();
        calendarPage.confirmPageHasLoaded();
      })
      .then(() => {
        //destination
        let destCenterCode = this.bookingResponseDetails.destCenterCode;
        calendarPage.getHeaderComponent().selectCenter(destCenterCode);
        calendarPage.confirmPageHasLoaded();
        calendarPage.getHeaderComponent().selectDateFromCalendar(this.bookingResponseDetails.destDate);
        let destFormattedDate = this.utils.convertDateIntoSpecificFormat(this.bookingResponseDetails.destDate);
        expect(calendarPage.isEventBookedInMonthView(destFormattedDate,this.bookingInfo.customerName),"New Event Booked is Not created for : "+destCenterCode).to.eventually.be.true;
        dayCalendarPage.confirmPageHasLoaded();
        expect(dayCalendarPage.readShipmentType(customerNameDisplayed),'Shipment type is not visible').to.eventually.contain('CONTAINER');
        expect(dayCalendarPage.readZipCode(customerNameDisplayed), 'Origin zipCode is NOT displayed').to.eventually.contain(this.bookingInfo.destinationZipCode);
        expect(dayCalendarPage.readOrderNumber(customerNameDisplayed),'Order number is not visible').to.eventually.contain(this.bookingInfo.orderNumber);
        expect(dayCalendarPage.readTrackingNumber(customerNameDisplayed),'Tracking number is not visible').to.eventually.contain(this.bookingInfo.opportunityNumber);
        expect(dayCalendarPage.readQuoteNumber(customerNameDisplayed),'Quote number is not visible').to.eventually.contain(this.bookingInfo.estimateNumber);
      });
  }

  @then(/^I reserve a booking information with a missing data and error message:([^"]*)$/)
  public reservedBookingInformationWithMissingData(expectedErrorMessage: string):Promise<any[]>{
    this.setUpDataForBookingInfo();
    this.bookingResponseDetails.estimateNo = this.bookingInfo.estimateNumber;
    let calendarPage = new CalendarPage();
    chain()
      .then(() =>{
        return this.serviceUtils.reserveEventThroughApi(this.bookingInfo,400);
      })
      .then((responseDataFromReserve) =>{
        let respInfo: any = responseDataFromReserve;
        expect(respInfo.message, 'Destination zip code can be null').to.contain(expectedErrorMessage);
      });
    return promise.all([
      expect(calendarPage.getClassAttributeOfCalendarView(), 'User is not able to view month calendar').to.eventually.contain('month-view')
    ]);
  }

  @then(/^I confirm booking through api using wrong estimate number and error message: ([^"]*)$/)
  public  confirmBookingThruApiUsingWrongEstimateNumber(expectedErrorMessage: string) :Promise<any[]>{
   let calendarPage = new CalendarPage();
   this.bookingResponseDetails.estimateNo = this.bookingResponseDetails.estimateNo+1;

   this.serviceUtils.bookingEventThroughApi(this.bookingResponseDetails,400).then((responseFromBooking) =>{
     let responseInfo :any = responseFromBooking;
     expect(responseInfo.message, 'No reservations found').to.contain(expectedErrorMessage);
   })

    return promise.all([
      expect(calendarPage.getClassAttributeOfCalendarView(), 'User is not able to view month calendar').to.eventually.contain('month-view')
    ]);

  }

 @then(/^I verify the estimate returned from api did not make booking$/)
    public checkEstimatePriceInCenter() : Promise<any[]> {
    this.setUpDataForBookingInfo();
    this.bookingInfo.destinationZipCode = '90001';
    let calendarPage = new CalendarPage().confirmPageHasLoaded();

   this.serviceUtils.priceAndAvailablityCheckThurApi(this.bookingInfo).then((responseDetails)=>{
     console.log(responseDetails);
     let bookingResponseDetails:any = responseDetails;
     let centerCode: string = bookingResponseDetails.origin.centerCode;
     calendarPage.getHeaderComponent().selectCenter(centerCode);
     calendarPage.confirmPageHasLoaded();
     calendarPage.getHeaderComponent().selectDateFromCalendar(bookingResponseDetails.origin.date);
     let formattedDate = this.utils.convertDateIntoSpecificFormat(bookingResponseDetails.origin.date);
     let customerNameDisplayed = this.bookingInfo.customerName;
     expect(calendarPage.isEventBookedInMonthView(formattedDate,customerNameDisplayed),"New Event is created").to.eventually.be.false;

     centerCode = bookingResponseDetails.destination.centerCode;
     calendarPage.getHeaderComponent().selectCenter(centerCode);
     calendarPage.confirmPageHasLoaded();
     calendarPage.getHeaderComponent().selectDateFromCalendar(bookingResponseDetails.destination.date);
     formattedDate = this.utils.convertDateIntoSpecificFormat(bookingResponseDetails.destination.date);
     expect(calendarPage.isEventBookedInMonthView(formattedDate,customerNameDisplayed), " New Event is created").to.eventually.be.false;
   });
   return promise.all([
     expect(calendarPage.getClassAttributeOfCalendarView(), 'User is not able to view month calendar').to.eventually.contain('month-view')
   ]);
}


}

export = reservationsFromQuotes2GoStepDefinations;
