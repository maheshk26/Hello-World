import {binding, given, when, then} from 'cucumber-tsflow';
import {CallbackStepDefinition} from 'cucumber';
import {browser} from 'protractor';
import {expect} from '../support/asserts.config';
import {User} from '../../models/user';
import {CalendarPage} from '../../pages/calendar.page';
import {CreateEventComponent} from '../../pages/components/create.event.component';
import {LoginPage} from '../../pages/login.page';
import {DeleteUpdateEventComponent} from '../../pages/components/delete.update.event.component';
import {ServiceUtils} from '../support/service.utils';
import {EventDetails} from '../../models/event_details';
import {RandomStringGenerator} from '../support/random_string_generator';
import CreateEventStepDefinitions = require('./create_event_defs');
import {promise} from 'selenium-webdriver';
import {WeekCalendarPage} from '../../pages/weekcalendar.page';
import {DayCalendarPage} from '../../pages/daycalendar.page';
import {Utils} from '../support/utils';
import {ProfileDetails} from '../../models/profile_details';
import {EventStatus} from '../../enums/event.status';

@binding()
class DeleteUpdateEventStepDefinitions {

  private eventDetails: EventDetails;
  private originalDetails: EventDetails;
  private stringGenerator: RandomStringGenerator = new RandomStringGenerator();
  private serviceUtils: ServiceUtils = new ServiceUtils();
  private utils: Utils = new Utils();
  private newDate: string;

  @given(/^a user exists for Crew Service Calendar application$/)
  public newUserExistsInSystem(): Promise<any[]> {
    // first delete all existing events and applied profiles
    let user: User = new User();
    user.username = browser.params.data.validHqUser.username;
    user.password = browser.params.data.validHqUser.password;
    let profileInfo = new ProfileDetails();
    profileInfo.centerId = browser.params.data.centerIdForCenterCalendarRealm.centerIdForCalendarOne;
    let fromDate = this.utils.getCurrentSystemDateAsString();
    let formattedFromDate = this.utils.reFormatDate(fromDate);
    let toDate = this.utils.addDaysAsString(this.utils.getCurrentSystemDate(), 90);
    let formattedToDate = this.utils.reFormatDate(toDate);
    this.serviceUtils.deleteAllEventsAndAppliedProfiles(user, formattedFromDate, formattedToDate, true, profileInfo);

    // then apply new profile

    profileInfo.profileName = this.stringGenerator.getRandomString(6);
    profileInfo.eventsCountOnSunday = 6;
    profileInfo.eventsCountOnMonday = 6;
    profileInfo.eventsCountOnTuesday = 6;
    profileInfo.eventsCountOnWednesday = 6;
    profileInfo.eventsCountOnThursday = 6;
    profileInfo.eventsCountOnFriday = 6;
    profileInfo.eventsCountOnSaturday = 6;

    let futureDate = this.utils.addDaysAsString(new Date(),+10);
    let futureDateFormatted = this.utils.reFormatDate(futureDate);
    this.serviceUtils.applyProfileThrApi(profileInfo, formattedFromDate, futureDateFormatted, user, true);

    browser.get(browser.params.data.baseUrl);
    let loginPage: LoginPage = new LoginPage().confirmPageHasLoaded();
    loginPage.login(browser.params.data.validHqUser.username, browser.params.data.validHqUser.password);
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    calendarPage.getHeaderComponent().selectCenter(browser.params.data.centerCalendarRealms.stLouis01);
    return promise.all([
      expect(calendarPage.getHeaderComponent().readCurrentCalendarDate(), 'Login was not successful').to.eventually.not.be.null
    ]);
  }

  @when(/^an event is booked for today$/)
  public eventIsBookedForToday(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();

    let date = this.utils.getCurrentSystemDateAsString();
    let formattedDate = this.utils.reFormatDate(date);
    this.eventDetails = new EventDetails(browser.params.data.createNewEventValidData);
    this.eventDetails.customerName = this.stringGenerator.getRandomString(6);
    this.eventDetails.zipCode = this.stringGenerator.getRandomNumber(5);
    this.eventDetails.orderNumber = this.stringGenerator.getRandomAlphaNumericString(30);
    this.eventDetails.opportunityNumber = this.stringGenerator.getRandomAlphaNumericString(30);
    this.eventDetails.estimateNumber = this.stringGenerator.getRandomAlphaNumericString(30);

    this.serviceUtils.bookSlotThroughApi(formattedDate,this.eventDetails, browser.params.data.centerIdForCenterCalendarRealm.centerIdForCalendarOne);

    browser.refresh();
    calendarPage.confirmPageHasLoaded();

    return promise.all([
      expect(calendarPage.isEventBookedInMonthView(date, this.eventDetails.customerName),
        'Event for ' + this.eventDetails.customerName + ' customer was not booked').to.eventually.be.true
    ]);
  }

  @when(/^the user clicks on a booked slot in the month calendar$/)
  public clickBookedSlotInMonthCalendar(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let date = this.utils.getCurrentSystemDateAsString();
    calendarPage.getHeaderComponent().selectDateFromCalendar(date);

    let dayCalendarPage: DayCalendarPage = calendarPage.clickSlotsRow(date, EventStatus.BOOKED);

    return promise.all([
      expect(dayCalendarPage.getHeaderComponent().readCurrentCalendarDate(),
        'Unable to click booked slot').to.eventually.not.be.null
    ]);
  }

  @when(/^the user views and clicks a booked slot in the day view calendar$/)
  public viewAndClickBookedSlotInDayCalendar(): Promise<any[]> {
    let dayCalendarPage: DayCalendarPage = new DayCalendarPage().confirmPageHasLoaded();
    let customerName = this.eventDetails.customerName;

    return promise.all([
      expect(dayCalendarPage.clickBookedSlotsRowInDayCalendar(customerName),
        'Unable to click on booked slot in day view').to.eventually.be.true
    ]);
  }

  @when(/^they click delete event$/)
  public clickDeleteEvent(): Promise<any[]> {
    let deleteUpdateEventComponent: DeleteUpdateEventComponent = new DeleteUpdateEventComponent().confirmDeleteUpdateComponentIsAvailable();
    deleteUpdateEventComponent.clickDeleteEventButton();

    return promise.all([
      deleteUpdateEventComponent.clickConfirmDeleteButton()
    ]);
  }

  @then(/^the event is deleted from the calendar$/)
  public eventIsDeletedFromCalendar(): Promise<any[]> {
    let customerNameDisplayed = this.eventDetails.customerName;
    let dayCalendarPage: DayCalendarPage = new DayCalendarPage().confirmPageHasLoaded();
    return promise.all([
      expect(dayCalendarPage.isEventBookedInDayView(customerNameDisplayed),
        'Event was not deleted successfully').to.eventually.be.false
    ]);
  }

  @when(/^they click cancel button$/)
  public clickCancelButton(): Promise<any>{
    let deleteUpdateEventComponent: DeleteUpdateEventComponent = new DeleteUpdateEventComponent().confirmDeleteUpdateComponentIsAvailable();
    deleteUpdateEventComponent.clickDeleteEventButton();
    return promise.all([
      deleteUpdateEventComponent.clickCancelEventButton()
    ]);
  }

  @then(/^the event is not deleted$/)
  public eventNotDeleted(): Promise<any[]> {
    let customerNameDisplayed = this.eventDetails.customerName;
    let dayCalendarPage: DayCalendarPage = new DayCalendarPage().confirmPageHasLoaded();

    return promise.all([
      expect(dayCalendarPage.isEventBookedInDayView(customerNameDisplayed),
        'Event is not present').to.eventually.be.true
    ]);
  }

  @when(/^they edit the information$/)
  public editTheInformation(): Promise<any[]>{
    let createEventComponent: CreateEventComponent = new CreateEventComponent().confirmComponentIsAvailable();

    this.originalDetails = new EventDetails(this.eventDetails);
    this.eventDetails = new EventDetails(browser.params.data.createNewEventValidData);
    this.eventDetails.customerName = this.stringGenerator.getRandomString(10);
    this.eventDetails.zipCode = this.stringGenerator.getRandomNumber(5);
    this.eventDetails.orderNumber = this.stringGenerator.getRandomAlphaNumericString(10);
    this.eventDetails.opportunityNumber = this.stringGenerator.getRandomAlphaNumericString(10);
    this.eventDetails.estimateNumber = this.stringGenerator.getRandomAlphaNumericString(10);

    createEventComponent.enterCustomerName(this.eventDetails.customerName);
    createEventComponent.enterZipCode(this.eventDetails.zipCode);
    createEventComponent.enterOrderNumber(this.eventDetails.orderNumber);
    createEventComponent.enterTrackingNumber(this.eventDetails.opportunityNumber);
    createEventComponent.enterQuoteNumber(this.eventDetails.estimateNumber );

    return promise.all([
      expect(createEventComponent.readCustomerName(),
        'Incorrect customer name entered').to.eventually.equal(this.eventDetails.customerName),
      expect(createEventComponent.readZipCode(),
        'Incorrect zip code entered').to.eventually.equal(this.eventDetails.zipCode),
      expect(createEventComponent.readOrderNumber(),
        'Incorrect order number entered').to.eventually.equal(this.eventDetails.orderNumber),
      expect(createEventComponent.readTrackingNumber(),
        'Incorrect tracking number entered').to.eventually.equal(this.eventDetails.opportunityNumber),
      expect(createEventComponent.readQuoteNumber(),
        'Incorrect quote number entered').to.eventually.equal(this.eventDetails.estimateNumber)
    ]);
  }

  @then(/^they click update event button$/)
  public clickUpdateEventButton(): Promise<any> {
    let deleteUpdateEventComponent: DeleteUpdateEventComponent = new DeleteUpdateEventComponent().confirmDeleteUpdateComponentIsAvailable();
    expect(deleteUpdateEventComponent.isUpdateEventButtonEnabled(),'Update Event button is not enabled').to.eventually.be.true;
    return promise.all([
      deleteUpdateEventComponent.clickUpdateEventButton()
    ]);
  }

  @then(/^the event is updated$/)
  public eventIsUpdated(): Promise<any[]> {
    let dayCalendarPage: DayCalendarPage = new DayCalendarPage().confirmPageHasLoaded();
    let customerNameDisplayed = this.eventDetails.customerName;

    return promise.all([
      expect(dayCalendarPage.isEventBookedInDayView(customerNameDisplayed),
        'Event for customer ' + customerNameDisplayed + ' is not present in day view').to.eventually.be.true,
      expect(dayCalendarPage.readZipCode(customerNameDisplayed),
        'Updated zip code is not correct').to.eventually.contain(this.eventDetails.zipCode),
      expect(dayCalendarPage.readOrderNumber(customerNameDisplayed),
        'Updated order number is not correct').to.eventually.contain(this.eventDetails.orderNumber),
      expect(dayCalendarPage.readTrackingNumber(customerNameDisplayed),
        'Updated tracking number is not correct').to.eventually.contain(this.eventDetails.opportunityNumber),
      expect(dayCalendarPage.readQuoteNumber(customerNameDisplayed),
        'Updated quote number is not correct').to.eventually.contain(this.eventDetails.estimateNumber)
    ]);
  }

  @when(/^they cancel the update$/)
  public cancelUpdate(): Promise<any> {
    let deleteUpdateEventComponent: DeleteUpdateEventComponent = new DeleteUpdateEventComponent().confirmDeleteUpdateComponentIsAvailable();
    return promise.all([
      deleteUpdateEventComponent.clickCancelEventButton()
    ]);
  }

  @when(/^they edit the information with invalid data$/)
  public editInformationWithInvalidData(): Promise<any[]> {
    let createEventComponent: CreateEventStepDefinitions = new CreateEventStepDefinitions();
    return promise.all([
      createEventComponent.enterInvalidData()
    ]);
  }

  @then(/^the update event button is not enabled$/)
  public updateEventButtonIsNotEnabled(): Promise<any>{
    let deleteUpdateEventComponent: DeleteUpdateEventComponent = new DeleteUpdateEventComponent().confirmDeleteUpdateComponentIsAvailable();
    return promise.all([
      expect(deleteUpdateEventComponent.isUpdateEventButtonEnabled(), 'Update Event button is enabled').to.eventually.be.false
    ]);
  }

  @when(/^user friendly error messages are displayed$/)
  public userFriendlyErrorMessagesAreDisplayed(): Promise<any[]> {
    let createEventComponent: CreateEventComponent = new CreateEventComponent();
    return promise.all([
      expect(createEventComponent.readZipCodeErrorMessage()).to.eventually.contain('Zip Code cannot be more than 5 digits long.',
      'Appropriate Zip Code error Message is not displayed'),
      expect(createEventComponent.readOrderNumberErrorMessage()).to.eventually.contain('Order Number cannot be more than 32 characters long.',
      'Appropriate Order Number error Message is not displayed'),
      expect(createEventComponent.readTrackingNumberErrorMessage()).to.eventually.contain('Tracking Number cannot be more than 32 characters long.',
      'Appropriate Tracking Number error Message is not displayed'),
      expect(createEventComponent.readQuoteNumberErrorMessage()).to.eventually.contain('Quote Number cannot be more than 32 characters long.',
      'Appropriate Quote Number error Message is not displayed'),
    ]);
  }

  @then(/^the event is not updated$/)
  public eventIsNotUpdated(): Promise<any[]> {
    let dayCalendarPage: DayCalendarPage = new DayCalendarPage().confirmPageHasLoaded();
    let customerNameDisplayed = this.originalDetails.customerName;

    return promise.all([
      expect(dayCalendarPage.isEventBookedInDayView(this.eventDetails.customerName),
        'Updated event customer name should not be present').to.eventually.be.false,
      expect(dayCalendarPage.isEventBookedInDayView(customerNameDisplayed),
        'Original event customer name should be present').to.eventually.be.true,
      expect(dayCalendarPage.readZipCode(customerNameDisplayed),
        'Original zip code is not correct').to.eventually.contain(this.originalDetails.zipCode),
      expect(dayCalendarPage.readOrderNumber(customerNameDisplayed),
        'Original order number is not correct').to.eventually.contain(this.originalDetails.orderNumber),
      expect(dayCalendarPage.readTrackingNumber(customerNameDisplayed),
        'Original tracking number is not correct').to.eventually.contain(this.originalDetails.opportunityNumber),
      expect(dayCalendarPage.readQuoteNumber(customerNameDisplayed),
        'Original quote number is not correct').to.eventually.contain(this.originalDetails.estimateNumber)
    ]);

  }

  @when(/^they move the event from current date to specific date$/)
  public moveEventFromCurrentDateToSpecificDate(): Promise<any[]> {
    let createEventComponent: CreateEventComponent = new CreateEventComponent().confirmComponentIsAvailable();
    createEventComponent.clickInlineCalendar();
    this.newDate = this.utils.addDaysAsString(new Date(), 2);

    return promise.all([
      createEventComponent.selectDateFromCreateEventComponent(this.newDate)
    ]);
  }

  @then(/^the event is moved and updated$/)
  public eventMovedAndUpdated(): Promise<any[]> {
    let dayCalendarPage: DayCalendarPage = new DayCalendarPage().confirmPageHasLoaded();
    let customerNameDisplayed = this.eventDetails.customerName;
    expect(dayCalendarPage.isEventBookedInDayView(customerNameDisplayed), 'Event is still found in current date').to.eventually.be.false;

    let calendarPage: CalendarPage = dayCalendarPage.getHeaderComponent().clickMonthButton();
    calendarPage.getHeaderComponent().selectDateFromCalendar(this.newDate);

    return promise.all([
      expect(calendarPage.isEventBookedInMonthView(this.newDate, customerNameDisplayed),
        'Event was not moved successfully to new date: ' + this.newDate).to.eventually.be.true,
    ]);
  }

  @when(/^I book all available slots for specific date$/)
  public bookAllSlotsForSpecificDate(): Promise<any[]> {
    let dayCalendarPage: DayCalendarPage = new DayCalendarPage().confirmPageHasLoaded();
    let calendarPage: CalendarPage = dayCalendarPage.getHeaderComponent().clickMonthButton();
    let strDate = this.utils.addDaysAsString(new Date(),+3);
    let formattedDate = this.utils.reFormatDate(strDate);
    let eventDetails: EventDetails = new EventDetails(browser.params.data.createNewEventValidData);
    calendarPage.getHeaderComponent().selectDateFromCalendar(strDate);
    let availableSlots = 0;
    let centerId: string = browser.params.data.centerIdForCenterCalendarRealm.centerIdForCalendarOne;

    return calendarPage.readSlots(strDate, EventStatus.AVAILABLE).then(number => {
      availableSlots = number;
      for(let i=0; i<number; i++){
        eventDetails.customerName = this.stringGenerator.getRandomString(10);
        eventDetails.estimateNumber = this.stringGenerator.getRandomAlphaNumericString(10);
        this.serviceUtils.bookSlotThroughApi(formattedDate, eventDetails, centerId);
      }

      browser.refresh();
      calendarPage.confirmPageHasLoaded();

      return promise.all([
        expect(calendarPage.readSlots(strDate, EventStatus.BOOKED), 'Incorrect number of booked slots').to.eventually.equal(availableSlots)
      ]);
    });
  }

  @when(/^the user attempts to move the event from current date to specific date having no available slots$/)
  public moveEventFromCurrentDateToSpecificDateWithNoAvailableSlots(): Promise<any[]> {
    let createEventComponent: CreateEventComponent = new CreateEventComponent().confirmComponentIsAvailable();
    createEventComponent.clickInlineCalendar();
    let strDate = this.utils.addDaysAsString(new Date(),+3);
    return promise.all([
      createEventComponent.selectDateFromCreateEventComponent(strDate)
    ]);
  }

  @when(/^the user views and clicks a booked slot in the week view calendar$/)
  public viewAndClickBookedSlotInWeekViewCalendar(callback: CallbackStepDefinition): void {
    let weekCalendarPage: WeekCalendarPage = new WeekCalendarPage().confirmPageHasLoaded();
    let customerName = this.eventDetails.customerName;
    let date= this.utils.getCurrentSystemDateAsString();
    weekCalendarPage.clickBookedSlotInWeek(date,customerName);
    callback();
  }

  @when(/^I delete all the events for current date$/)
  public deleteAllEventsForCurrentDate():void {
    let user: User = new User();
    user.username = browser.params.data.validHqUser.username;
    user.password = browser.params.data.validHqUser.password;

    let date= this.utils.getCurrentSystemDateAsString();
    let formattedDate = this.utils.reFormatDate(date);
    this.serviceUtils.deleteSlotsThroughApi(user,formattedDate,formattedDate);
    browser.refresh();
  }

  @then(/^the event is deleted from the Week Calendar$/)
  public eventIsDeletedFromWeekCalendar(): Promise<any[]> {
    let date = this.utils.getCurrentSystemDateAsString();
    let customerNameDisplayed = this.eventDetails.customerName;
    let weekCalendarPage: WeekCalendarPage = new WeekCalendarPage().confirmPageHasLoaded();
    return promise.all([
      expect(weekCalendarPage.isEventBookedInWeekView(date, customerNameDisplayed),
        'Event was not deleted successfully from week calendar page').to.eventually.be.false
    ]);
  }

  @then(/^the event is updated in week calendar page$/)
  public eventIsUpdatedInWeekCalendarPage(): Promise<any[]> {
    let weekCalendarPage: WeekCalendarPage = new WeekCalendarPage().confirmPageHasLoaded();
    let date = this.utils.getCurrentSystemDateAsString();
    let customerNameDisplayed = this.eventDetails.customerName;
    return promise.all([
      expect(weekCalendarPage.isEventBookedInWeekView(date, customerNameDisplayed),
        'Event was not updated successfully in week calendar page').to.eventually.be.true
    ])
  }

  @then(/^I am only able to view the event$/)
  public onlyAbleToViewTheEvent(): Promise<any[]> {
    let dayCalendar: DayCalendarPage = new DayCalendarPage().confirmPageHasLoaded();
    let date = this.utils.getCurrentSystemDateAsString();

    return promise.all([
      expect(dayCalendar.isBookedSlotClickable(this.eventDetails.customerName),
        'Booked slot should not be clickable').to.eventually.be.false
    ]);
  }

}
export = DeleteUpdateEventStepDefinitions;
