import {binding, given, when, then} from 'cucumber-tsflow';
import {CallbackStepDefinition} from 'cucumber';
import {browser} from 'protractor';
import {expect} from '../support/asserts.config';
import {LoginPage} from '../../pages/login.page';
import {CalendarPage} from "../../pages/calendar.page";
import {promise} from "selenium-webdriver";
@binding()
class LoginStepDefinitions {

    @given(/^I go to the Crew Service Calendar application$/)
    public goToCrewCalendarApplication(callback: CallbackStepDefinition): void {
        browser.get(browser.params.data.baseUrl);
        callback();
    }

    @when(/^I view the Login Page$/)
    public viewLoginPage(callback: CallbackStepDefinition): void {
        callback();
    }

    @then(/^I should see the page title "([^"]*)"$/)
    public shouldSeePageTitle(expectedPageTitle: string): Promise<any[]> {
      return promise.all([
        expect(browser.getTitle()).to.eventually.equal(expectedPageTitle)
      ]);
    }

    @when(/^I try to login with valid credentials$/)
    public loginWithValidCredentials(callback: CallbackStepDefinition): void {
      let loginPage: LoginPage = new LoginPage().confirmPageHasLoaded();
      loginPage.login(browser.params.data.validCenterUser.username, browser.params.data.validCenterUser.password);
      callback();
    }

    @then(/^the login is successful$/)
    public loginIsSuccessful(): Promise<any[]> {
      let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
      return promise.all([
        expect(calendarPage.getHeaderComponent().readCurrentCalendarDate(), 'Login was not successful').to.eventually.not.be.null
      ]);
    }

    @when(/^I try to login with invalid credentials$/)
    public loginWithInvalidCredentials(callback: CallbackStepDefinition): void {
      let loginPage: LoginPage = new LoginPage().confirmPageHasLoaded();
      loginPage.login(browser.params.data.invalidUser.username, browser.params.data.invalidUser.password);
      callback();
    }

    @then(/^the login is not successful$/)
    public loginIsNotSuccessful(): Promise<any[]> {
      let loginPage: LoginPage = new LoginPage().confirmPageHasLoaded();
      return promise.all([
        expect(loginPage.loginErrorMsgLocator.isPresent(), 'Login error message was not present').to.eventually.be.true
      ]);
    }

    @when(/^I try to login with the wrong username$/)
    public tryToLoginWithWrongUserName(callback: CallbackStepDefinition): void {
      let loginPage: LoginPage = new LoginPage().confirmPageHasLoaded();
      loginPage.login('foobar123!!', browser.params.data.validCenterUser.password);
      callback();
    }

    @when(/^I try to login with the wrong password$/)
    public tryToLoginWithWrongPassword(callback: CallbackStepDefinition): void {
      let loginPage: LoginPage = new LoginPage().confirmPageHasLoaded();
      loginPage.login(browser.params.data.validCenterUser.username, 'foobar123!!!');
      callback();
    }

    @then(/^I see the error message "([^"]*)" on the login page$/)
    public errorMessageIsCorrect(expectedErrorMessage: string): Promise<any[]> {
      let loginPage: LoginPage = new LoginPage().confirmPageHasLoaded();
      return promise.all([
        expect(loginPage.readLoginErrorMessage(),
          'Unexpected error message after entering invalid credentials').to.eventually.equal(expectedErrorMessage)
      ]);
    }

    @when(/^I enter username only$/)
    public enterUserNameOnly(callback: CallbackStepDefinition): void {
      let loginPage: LoginPage = new LoginPage().confirmPageHasLoaded();
      loginPage.enterUsername(browser.params.data.validCenterUser.username);

      callback();
    }

    @when(/^I enter password only$/)
    public enterPasswordOnly(callback: CallbackStepDefinition): void {
      let loginPage: LoginPage = new LoginPage().confirmPageHasLoaded();
      loginPage.enterPassword(browser.params.data.validCenterUser.password);

      callback();
    }

    @then(/^the Login button is not enabled$/)
    public loginButtonIsNotEnabled(): Promise<any> {
      let loginPage: LoginPage = new LoginPage().confirmPageHasLoaded();
      return promise.all([
        expect(loginPage.loginButton.isEnabled(), 'Login button should not be enabled').to.eventually.be.false
      ]);
    }

    @when(/^I enter username and password$/)
    public enterUsernameAndPassword(callback: CallbackStepDefinition): void {
      let loginPage: LoginPage = new LoginPage().confirmPageHasLoaded();
      loginPage.enterUsername(browser.params.data.validCenterUser.username);
      loginPage.enterPassword(browser.params.data.validCenterUser.password);

      callback();
    }

    @then(/^the Login button is enabled$/)
    public loginButtonIsEnabled(): Promise<any> {
      let loginPage: LoginPage = new LoginPage().confirmPageHasLoaded();
      return promise.all([
        expect(loginPage.loginButton.isEnabled(), 'Login button is not enabled').to.eventually.be.true
      ]);
    }
}
export = LoginStepDefinitions;
