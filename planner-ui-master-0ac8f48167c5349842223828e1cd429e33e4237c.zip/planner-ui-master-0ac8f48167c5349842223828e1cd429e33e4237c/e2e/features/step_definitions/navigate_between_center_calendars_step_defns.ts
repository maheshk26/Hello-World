import {binding, given, when, then, before} from 'cucumber-tsflow';
import {browser, by, element, protractor} from 'protractor';
import {expect} from '../support/asserts.config';
import {LoginPage} from '../../pages/login.page';
import {CalendarPage} from '../../pages/calendar.page';
import {promise} from 'selenium-webdriver';
import {AdministrationPage} from '../../pages/admin/administration.page';
import {RandomStringGenerator} from '../support/random_string_generator';
import {ProfileDetails} from '../../models/profile_details';
import {ServiceUtils} from '../support/service.utils';
import {Utils} from '../support/utils';
import {User} from '../../models/user';
import {EventDetails} from '../../models/event_details';
import {WeekCalendarPage} from '../../pages/weekcalendar.page';
import {DayCalendarPage} from '../../pages/daycalendar.page';
import {chain} from '../support/world';
import {CallbackStepDefinition} from 'cucumber';
import {AddNewProfileComponent} from '../../pages/components/add.new.profile.component';
import {ApplyProfileToCalendarComponent} from '../../pages/components/apply.profile.to.calendar.component';
import {EventStatus} from "../../enums/event.status";
var world = require('../support/world');

function createAndApplyProfileThrApi(profileInfo: ProfileDetails) {
  let date = this.utils.getCurrentSystemDateAsString();
  let currentDate = this.utils.reFormatDate(date);
  let addMonth = this.utils.addDays(new Date(), +60);
  let futureMonth = this.utils.reFormatDate(addMonth);

  let userInfo = new User();
  userInfo.username = browser.params.data.validHqUser.username;
  userInfo.password = browser.params.data.validHqUser.password;
  this.serviceUtils.applyProfileThrApi(profileInfo, currentDate, futureMonth, userInfo, true);
}

@binding()
class navigateBetweenCenterCalendraStepDefinitions {


  private eventDetails: EventDetails;
  private serviceUtils: ServiceUtils = new ServiceUtils();
  private utils: Utils = new Utils();
  private stringGenerator: RandomStringGenerator = new RandomStringGenerator();
  private expectedDateAfterRefresh: string;
  private centerOne: string = browser.params.data.centerCalendarRealms.stLouis01;
  private centerTwo: string = browser.params.data.centerCalendarRealms.stLouis02;
  private market: string = browser.params.data.centerCalendarRealms.market;

  @before('@DeleteAppliedProfileForAllCenters')
  public deleteAppliedProfiles(): void {
    let userInfo = new User();
    let profileDetails = new ProfileDetails();
    let calendarPage = new CalendarPage();
    userInfo.username = browser.params.data.validHqUser.username;
    userInfo.password = browser.params.data.validHqUser.password;

    let fromDate = this.utils.getCurrentSystemDateAsString();
    let formattedFromDate = this.utils.reFormatDate(fromDate);
    let toDate = this.utils.addDaysAsString(this.utils.getCurrentSystemDate(), 90);
    let formattedToDate = this.utils.reFormatDate(toDate);
    let centerCodes = browser.params.data.deleteCenters;


    chain()
      .then(() =>{
        for (let i=0;i<centerCodes.length;i++) {
          chain()
            .then(() => {
              let data = centerCodes[i];
              let centerVal = data.id;
              profileDetails.centerId = centerVal;
            })
            .then(() => {
              this.serviceUtils.deleteSlotsThroughApi(userInfo,formattedFromDate, formattedToDate,true,profileDetails);
            })
            .then(() => {
              this.serviceUtils.deleteAllAppliedProfileUsingApi(userInfo, true, profileDetails);
            });
        }
      })
  }

  @given(/^I apply profile for center01 through api$/)
  public createAndApplyProfileThrApiForCenterOne(): void{
    let profileInfo = new ProfileDetails();
    profileInfo.profileName = this.stringGenerator.getRandomString(6);
    profileInfo.eventsCountOnSunday = 6;
    profileInfo.eventsCountOnMonday = 6;
    profileInfo.eventsCountOnTuesday = 6;
    profileInfo.eventsCountOnWednesday = 6;
    profileInfo.eventsCountOnThursday = 6;
    profileInfo.eventsCountOnFriday = 6;
    profileInfo.eventsCountOnSaturday = 6;
    profileInfo.centerId = browser.params.data.centerIdForCenterCalendarRealm.centerIdForCalendarOne;

    createAndApplyProfileThrApi.call(this, profileInfo);
  }

  @given(/^I apply profile for center02 through api$/)
  public createAndApplyProfileThrApiForCenterTwo() {
    let profileInfo = new ProfileDetails();
    profileInfo.profileName = this.stringGenerator.getRandomString(6);
    profileInfo.eventsCountOnSunday = 6;
    profileInfo.eventsCountOnMonday = 6;
    profileInfo.eventsCountOnTuesday = 6;
    profileInfo.eventsCountOnWednesday = 6;
    profileInfo.eventsCountOnThursday = 6;
    profileInfo.eventsCountOnFriday = 6;
    profileInfo.eventsCountOnSaturday = 6;
    profileInfo.centerId = browser.params.data.centerIdForCenterCalendarRealm.centerIdForCalendarTwo;

    createAndApplyProfileThrApi.call(this, profileInfo);
  }

  @given(/^UG coordinator logs into application$/)
  public unigroupCoordinatorLogsIntoApplication():  Promise <any[]> {
    browser.get(browser.params.data.baseUrl);
    let loginPage: LoginPage = new LoginPage().confirmPageHasLoaded();
    loginPage.login(browser.params.data.validHqUser.username, browser.params.data.validHqUser.password);
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    return promise.all([
      expect(calendarPage.getHeaderComponent().readCurrentCalendarDate(), 'Login was not successful').to.eventually.not.be.null
    ]);
  }

  @when (/^I navigate to center one calendars$/)
  public navigateToCenterOneCalendar(): Promise<any[]> {

    let calendarPage = new CalendarPage().confirmPageHasLoaded();
    calendarPage.getHeaderComponent().selectCenter(browser.params.data.centerCalendarRealms.stLouis01);
    calendarPage.confirmPageHasLoaded();

    return promise.all([
      expect(calendarPage.getHeaderComponent().readCenter(),
        'Center Calendar was not available').to.eventually.contain(browser.params.data.centerCalendarRealms.stLouis01)
    ]);
  }

  @when(/^I navigate to center two calendars$/)
  public navigateToCenterTwoCalendar(): Promise<any[] > {
    let calendarPage = new CalendarPage().confirmPageHasLoaded();

    calendarPage.getHeaderComponent().selectCenter(browser.params.data.centerCalendarRealms.stLouis02);
    calendarPage.confirmPageHasLoaded();

    return promise.all([
      expect(calendarPage.getHeaderComponent().readCenter(),
        'Center Calendar was not available').to.eventually.contain(browser.params.data.centerCalendarRealms.stLouis02)
    ]);
  }

  @then (/^I verify profile and data should not be shown$/)
  public verifyProfileAndDataShouldNotBeShown(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let adminPage: AdministrationPage = calendarPage.getHeaderComponent().getLeftNavComponent().clickAdministrationMenuLink();
    let date = this.utils.getCurrentSystemDateAsString();
    let originalProfileName: string = world.defaultProfileDetails.profileName;

    return promise.all([
      expect(adminPage.isProfileApplied(originalProfileName),
        originalProfileName + ' profile should not be applied').to.eventually.be.false,
      expect(adminPage.isProfilePresent(originalProfileName),
        originalProfileName + ' profile should not be present').to.eventually.be.false
    ]);

  }

  @then(/^I verify booked event in center two calendar and data should not be shown$/)
  public verifyBookedEventInCenterCalendar(): Promise<any[]> {
    let administrationPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();
    let calendarPage: CalendarPage = administrationPage.getHeaderComponent().getLeftNavComponent().clickCalendarMenuLink();

    let customerNameDisplayed = world.defaultEventDetails.eventDetails.customerName;
    let date = this.utils.getCurrentSystemDateAsString();

    return promise.all([
      expect(calendarPage.isEventBookedInMonthView(date, customerNameDisplayed),
        'New Event is Not created').to.eventually.be.true
    ]);
  }

  @given(/^I navigate to the week view for next week$/)
  public navigateToWeekViewForNextWeek(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let weekCalendarPage: WeekCalendarPage = calendarPage.getHeaderComponent().clickWeekButton();

    return weekCalendarPage.getHeaderComponent().readCurrentCalendarDate().then(currentWeek => {
      weekCalendarPage.getHeaderComponent().clickRightArrow();

      return weekCalendarPage.getHeaderComponent().readCurrentCalendarDate().then(nextWeek => {
        this.expectedDateAfterRefresh = nextWeek;

        return promise.all([
          expect(weekCalendarPage.getHeaderComponent().readCurrentCalendarDate(), 'Still on same week').to.eventually.not.equal(currentWeek)
        ]);
      });
    });
  }

  @given(/^I navigate to the day view for tomorrow$/)
  public navigateToDayViewForTomorrow(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let dayCalendarPage: DayCalendarPage = calendarPage.getHeaderComponent().clickDayButton();

    return dayCalendarPage.getHeaderComponent().readCurrentCalendarDate().then(currentDay => {
      dayCalendarPage.getHeaderComponent().clickRightArrow();

      return dayCalendarPage.getHeaderComponent().readCurrentCalendarDate().then(tomorrow => {
        this.expectedDateAfterRefresh = tomorrow;

        return promise.all([
          expect(dayCalendarPage.getHeaderComponent().readCurrentCalendarDate(), 'Still on same day').to.eventually.not.equal(currentDay)
        ]);
      })
    });
  }

  @when(/^I refresh the calendar page$/)
  public refreshCalendar(): Promise<any[]> {
    let calendarPage = new CalendarPage().confirmPageHasLoaded();
    browser.refresh();
    return promise.all([
      expect(calendarPage.getHeaderComponent().readCenter(),'Center Calendar was not available').to.eventually.not.be.null
    ]);
  }

  @then(/^I should still be on the calendar for center two$/)
  public verifyOnCenterTwoCalendar(): Promise<any[]> {
    let calendarPage = new CalendarPage().confirmPageHasLoaded();

    return promise.all([
      expect(calendarPage.getHeaderComponent().readCenter(),
        'Not on correct calendar after refreshing page').to.eventually.contain(browser.params.data.centerCalendarRealms.stLouis02)
    ]);
  }

  @then(/^I should still be on the week view calendar for center two$/)
  public verifyWeekViewForCenterTwo(): Promise<any[]> {
    let weekCalendarPage: WeekCalendarPage = new WeekCalendarPage().confirmPageHasLoaded();

    return promise.all([
      expect(weekCalendarPage.getHeaderComponent().readCenter(),
        'Not on correct calendar after refreshing page').to.eventually.contain(browser.params.data.centerCalendarRealms.stLouis02),
      expect(weekCalendarPage.getHeaderComponent().readCurrentCalendarDate(),
        'Not on correct week after refreshing page').to.eventually.equal(this.expectedDateAfterRefresh)
    ]);
  }

  @then(/^I should still be on the day view calendar for center two$/)
  public verifyDayViewForCenterTwo(): Promise<any[]> {
    let dayCalendarPage: DayCalendarPage = new DayCalendarPage().confirmPageHasLoaded();

    return promise.all([
      expect(dayCalendarPage.getHeaderComponent().readCenter(),
        'Not on correct calendar after refreshing page').to.eventually.contain(browser.params.data.centerCalendarRealms.stLouis02),
      expect(dayCalendarPage.getHeaderComponent().readCurrentCalendarDate(),
        'Not on correct day after refreshing page').to.eventually.equal(this.expectedDateAfterRefresh)
    ]);
  }

  @when(/^I navigate to the calendar for center "(.*)"$/)
  public navigateToCentersCalendar(centerName: string): Promise<any[]> {
    let calendarPage = new CalendarPage().confirmPageHasLoaded();
    calendarPage.getHeaderComponent().selectCenter(centerName);
    calendarPage.confirmPageHasLoaded();

    return promise.all([
      expect(calendarPage.getHeaderComponent().readCenter(),
        'Center Calendar was not available').to.eventually.contain(centerName)
    ]);
  }

  @when(/^I view the month calendar$/)
  public viewMonthCalendar(): Promise<any[]> {
    let calendarPage = new CalendarPage().confirmPageHasLoaded();

    return promise.all([
      expect(calendarPage.getHeaderComponent().readCurrentCalendarDate(), 'Not on month calendar').to.eventually.not.be.null
    ])
  }

  @when(/^I view the week calendar$/)
  public viewWeekCalendar(): Promise<any[]> {
    let calendarPage = new CalendarPage().confirmPageHasLoaded();
    let weekCalendarPage: WeekCalendarPage = calendarPage.getHeaderComponent().clickWeekButton();

    return promise.all([
      expect(weekCalendarPage.getHeaderComponent().readCurrentCalendarDate(), 'Not on week calendar').to.eventually.not.be.null
    ])
  }

  @when(/^I view the day calendar$/)
  public viewDayCalendar(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let dayCalendarPage: DayCalendarPage = calendarPage.getHeaderComponent().clickDayButton();

    return promise.all([
      expect(dayCalendarPage.getHeaderComponent().readCurrentCalendarDate(), 'Not on day calendar').to.eventually.not.be.null
    ])
  }

  @then(/^the center selector is present$/)
  public centerSelectorIsPresent(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();

    return promise.all([
      expect(calendarPage.getHeaderComponent().isCenterSelectorPresent(),
        'Center selector should be present').to.eventually.be.true
    ])
  }

  @then(/^I can navigate to and from center two's calendar calendar$/)
  public navigateToAndFromCenterTwoCalendar(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    calendarPage.getHeaderComponent().selectCenter(this.centerTwo);

    expect(calendarPage.getHeaderComponent().readCenter(),
      'Expected to be on ' + this.centerTwo + '\'s calendar').to.eventually.contain(this.centerTwo);

    calendarPage.getHeaderComponent().selectCenter(this.centerOne);

    return promise.all([
      expect(calendarPage.getHeaderComponent().readCenter(),
        'Expected to be on ' + this.centerOne + '\'s calendar').to.eventually.contain(this.centerOne)
    ]);
  }

  @when(/^I view my market's calendar$/)
  public viewMarketsCalendar(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    calendarPage.getHeaderComponent().selectCenter(this.market);
    return promise.all([
      expect(calendarPage.getHeaderComponent().readCenter(),
        'Did not switch to market calendar').to.eventually.equal(this.market)
    ]);
  }

  @when(/^I switch to the Administration section$/)
  public switchToAdminSection(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let adminPage: AdministrationPage = calendarPage.getHeaderComponent().getLeftNavComponent().clickAdministrationMenuLink();
    return promise.all([
      expect(adminPage.isErrorMessagePresent(), 'Error message is not present').to.eventually.be.true
    ]);
  }

  @then(/^I see the message "(.*)" on the Admin page$/)
  public seeMessageOnAdminPage(expectedErrorMsg: string): Promise<any[]> {
    let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();

    return promise.all([
      expect(adminPage.isErrorMessagePresent(), 'Error message is not present').to.eventually.be.true,
      expect(adminPage.readErrorMessage(), 'Incorrect error message').to.eventually.equal(expectedErrorMsg)
    ]);
  }

  @when(/^I view another center's calendar$/)
  public viewAnotherCentersCalendar(): Promise<any[]> {
    let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();
    adminPage.getHeaderComponent().selectCenter(this.centerTwo);
    return promise.all([
      expect(adminPage.isErrorMessagePresent(), 'Error message is not present').to.eventually.be.true
    ]);
  }

  @when(/^I view the default calendar$/)
  public viewDefaultCalendar(callback: CallbackStepDefinition): void {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    callback();
  }

  @then(/^I see my center's calendar$/)
  public seeMyCentersCalendar(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();

    return promise.all([
      expect(calendarPage.getHeaderComponent().readCenter(), 'Not on my center\'s calendar').to.eventually.contain(this.centerOne)
    ]);
  }

  @then(/^I can only see my market, my center, and the other center in my market in the center selector$/)
  public verifyProperCenterSelectionOptions(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();

    return promise.all([
      expect(calendarPage.getHeaderComponent().readNumberOfCentersInSelector(),
        'Incorrect number of center/market options in drop-down').to.eventually.equal(3),
      expect(calendarPage.getHeaderComponent().isLocationPresentInCenterSelector(this.market),
        this.market + ' not present in center selector').to.eventually.be.true,
      expect(calendarPage.getHeaderComponent().isLocationPresentInCenterSelector(this.centerOne),
        this.centerOne + ' not present in center selector').to.eventually.be.true,
      expect(calendarPage.getHeaderComponent().isLocationPresentInCenterSelector(this.centerTwo),
        this.centerTwo + ' not present in center selector').to.eventually.be.true,
    ]);
  }

  @when(/^I apply a profile to my calendar$/)
  public applyProfileToMyCalendar(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    calendarPage.getHeaderComponent().selectCenter(this.centerOne);
    let adminPage: AdministrationPage = calendarPage.getHeaderComponent().getLeftNavComponent().clickAdministrationMenuLink();

    // Add profile
    let addNewProfileComponent: AddNewProfileComponent = adminPage.clickAddNewCewAvailabilityProfile();
    let profileDetails = browser.params.data.singleSlotProfile;
    profileDetails.profileName = this.stringGenerator.getRandomString(6);
    addNewProfileComponent.enterProfileName(profileDetails.profileName);
    addNewProfileComponent.enterSlotsForEachDay(profileDetails);
    addNewProfileComponent.clickAddProfileButton();
    expect(adminPage.isProfilePresent(profileDetails.profileName),'New Profile ' + profileDetails.profileName + ' was not added to the grid').to.eventually.equal(true);

    // Apply profile
    adminPage.clickEllipsisInAvailabilityProfileTable(profileDetails.profileName);
    let applyProfileToCalendarComponent: ApplyProfileToCalendarComponent = new ApplyProfileToCalendarComponent().confirmComponentHasLoaded();
    applyProfileToCalendarComponent.clickSelectDateRange();
    applyProfileToCalendarComponent.selectDateRangeFromCurrentDateThroughDays(1);
    applyProfileToCalendarComponent.clickApplyToCalendarButton();
    return promise.all([
      expect(adminPage.isProfileApplied(profileDetails.profileName),
        'The created profile ' + profileDetails.profileName + ' was not applied to the calendar').to.eventually.equal(true)
    ]);
  }

  @then(/I see it on my calendar and the market calendar but not on the other center's calendar/)
  public seeAppliedProfileOnMyCalendarButNotOnOtherCentersCalendar(): Promise<any[]> {
    let date = this.utils.getCurrentSystemDateAsString();
    let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();
    let calendarPage: CalendarPage = adminPage.getHeaderComponent().getLeftNavComponent().clickCalendarMenuLink();

    // Verify slot shows up on center 1 calendar
    calendarPage.getHeaderComponent().selectCenter(this.centerOne);
    expect(calendarPage.readSlots(date, EventStatus.AVAILABLE), 'Should be 1 available day on center 1 calendar for ' + date).to.eventually.equal(1);

    // Verify slot shows up on market view calendar
    calendarPage.getHeaderComponent().selectCenter(this.market);
    expect(calendarPage.readSlots(date, EventStatus.AVAILABLE), 'Should be 0 available day on center 2 calendar for ' + date).to.eventually.equal(1);

    // Verify slot does not show up on center 2 calendar
    calendarPage.getHeaderComponent().selectCenter(this.centerTwo);
    return promise.all([
      expect(calendarPage.readSlots(date, EventStatus.AVAILABLE), 'Should be 1 available day on market calendar for ' + date).to.eventually.equal(0)
    ]);
  }

  @when(/^there is a profile applied to the other center's calendar$/)
  public profileAppliedToOtherCentersCalendar(callback: CallbackStepDefinition): void {
    let profileDetails: ProfileDetails = browser.params.data.singleSlotProfile;
    profileDetails.profileName = this.stringGenerator.getRandomString(6);

    let user = new User();
    user.username = browser.params.data.centerCalendarRealms.stLouis02;
    user.password = browser.params.data.validCenterUser.password;
    profileDetails.centerId = browser.params.data.centerIdForCenterCalendarRealm.centerIdForCalendarTwo;

    let date = this.utils.getCurrentSystemDateAsString();
    let currentDate = this.utils.reFormatDate(date);
    let addDay = this.utils.addDaysAsString(new Date(), 1);
    let futureDate = this.utils.reFormatDate(addDay);
    this.serviceUtils.applyProfileThrApi(profileDetails, currentDate, futureDate, user, true);

    callback();
  }

  @then(/^I can see both applied profiles on the market calendar$/)
  public seeAppliedProfilesOnMarketCalendar(): Promise<any[]> {
    let date = this.utils.getCurrentSystemDateAsString();
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();

    // Verify slot shows up on center 1 calendar
    calendarPage.getHeaderComponent().selectCenter(this.centerOne);
    expect(calendarPage.readSlots(date, EventStatus.AVAILABLE), 'Should be 1 available day on center 1 calendar for ' + date).to.eventually.equal(1);

    // Verify slot does not show up on center 2 calendar
    calendarPage.getHeaderComponent().selectCenter(this.centerTwo);
    expect(calendarPage.readSlots(date, EventStatus.AVAILABLE), 'Should be 1 available day on center 2 calendar for ' + date).to.eventually.equal(1);

    // Verify slot shows up on market view calendar
    calendarPage.getHeaderComponent().selectCenter(this.market);
    return promise.all([
      expect(calendarPage.readSlots(date, EventStatus.AVAILABLE), 'Should be 2 available day on market calendar for ' + date).to.eventually.equal(2)
    ]);
  }
}

export = navigateBetweenCenterCalendraStepDefinitions;
