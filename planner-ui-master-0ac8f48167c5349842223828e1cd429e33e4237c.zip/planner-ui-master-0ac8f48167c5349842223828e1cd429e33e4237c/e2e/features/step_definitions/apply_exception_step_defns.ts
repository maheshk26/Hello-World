import {binding, given, when, then} from 'cucumber-tsflow';
import {browser, by, element, protractor} from 'protractor';
import {expect} from '../support/asserts.config';
import {CalendarPage} from '../../pages/calendar.page';
import {promise} from 'selenium-webdriver';
import {AdministrationPage} from '../../pages/admin/administration.page';
import {RandomStringGenerator} from '../support/random_string_generator';
import {ProfileDetails} from '../../models/profile_details';
import {ApplyProfileToCalendarComponent} from '../../pages/components/apply.profile.to.calendar.component';
import {ServiceUtils} from '../support/service.utils';
import {Utils} from '../support/utils';
import {CallbackStepDefinition} from 'cucumber';
import {ApplyExceptionComponent} from '../../pages/components/apply.exception.component';
import AdminAddProfileStepDefinitions = require('./admin_add_profile_step_defns');
import {User} from '../../models/user';
import {EventDetails} from '../../models/event_details';
import {EventStatus} from '../../enums/event.status';

@binding()
class ApplyExceptionStepDefinitions {

  private profileDetails: ProfileDetails;
  private serviceUtils: ServiceUtils = new ServiceUtils();
  private utils: Utils = new Utils();
  private stringGenerator: RandomStringGenerator = new RandomStringGenerator();
  private currentDate: string;
  private futureMonth: string;

  @given(/^no events exist for past days$/)
  public deleteEventsForPastDays(callback: CallbackStepDefinition): void {
    // delete existing events for past days
    let user: User = new User();
    user.username = browser.params.data.validUser.username;
    user.password = browser.params.data.validUser.password;
    let toDate = this.utils.getCurrentSystemDateAsString();
    let formattedToDate = this.utils.reFormatDate(toDate);
    let fromDate = this.utils.subtractDaysAsString(this.utils.getCurrentSystemDate(), 90);
    let formattedFromDate = this.utils.reFormatDate(fromDate);
    this.serviceUtils.deleteAllEventsAndAppliedProfiles(user, formattedFromDate, formattedToDate);
    callback();
  }

  @given(/^the applied profile exists in the applied crew profiles table$/)
  public appliedProfileExists(): Promise<any[]>{
    this.profileDetails = new ProfileDetails();
    this.profileDetails.profileName = this.stringGenerator.getRandomString(6);
    this.profileDetails.eventsCountOnSunday = 6;
    this.profileDetails.eventsCountOnMonday = 6;
    this.profileDetails.eventsCountOnTuesday = 6;
    this.profileDetails.eventsCountOnWednesday = 6;
    this.profileDetails.eventsCountOnThursday = 6;
    this.profileDetails.eventsCountOnFriday = 6;
    this.profileDetails.eventsCountOnSaturday = 6;

    let userInfo = new User();
    userInfo.username = browser.params.data.validCenterUser.username;
    userInfo.password = browser.params.data.validCenterUser.password;
    this.profileDetails.centerId = browser.params.data.centerIdForCenterCalendarRealm.centerIdForCalendarOne;

    let date = this.utils.getCurrentSystemDateAsString();
    this.currentDate = this.utils.reFormatDate(date);
    let addMonth = this.utils.addDaysAsString(new Date(),+30);
    this.futureMonth = this.utils.reFormatDate(addMonth);
    this.serviceUtils.applyProfileThrApi(this.profileDetails, this.currentDate, this.futureMonth, userInfo, true);

    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let adminPage: AdministrationPage = calendarPage.getHeaderComponent().getLeftNavComponent().clickAdministrationMenuLink();

    return promise.all([
      expect(adminPage.isProfileApplied(this.profileDetails.profileName),
        'Profile ' + this.profileDetails.profileName + ' was not applied').to.eventually.be.true,
      expect(adminPage.readNumberOfTimesProfileIsApplied(this.profileDetails.profileName),
        'Profile ' + this.profileDetails.profileName + ' was applied an incorrect number of times').to.eventually.equal(1)
    ]);
  }

  @when(/^I click ellipses and click apply exception$/)
  public clickEllipsesAndClickApplyException(): void {
    let adminPage : AdministrationPage = new AdministrationPage().confirmPageHasLoaded();
    adminPage.clickEllipsisApplyException(this.profileDetails.profileName).confirmComponentHasLoaded();
  }

  @when(/^I click on specific date and enter new availability value to apply exception$/)
  public clickSpecificDateInCalendar(): Promise<any[]> {
    let exceptionComponent : ApplyExceptionComponent = new ApplyExceptionComponent().confirmComponentHasLoaded();
    exceptionComponent.clickSelectDateLabel();
    let date = this.utils.getCurrentSystemDateAsString();
    exceptionComponent.selectSpecificDateFromCalendar(date);
    this.profileDetails.exceptionSlotValue = this.stringGenerator.getRandomNumberInRange(0,50);
    exceptionComponent.enterNewAvailability(this.profileDetails.exceptionSlotValue);

    return promise.all([
      exceptionComponent.clickApplyExceptionButton()
    ]);
  }

  @when(/^I click on specific date and apply an exception with new availability of (\d+)$/)
  public applyExceptionValueOf(exceptionValue: number): Promise<any[]> {
    let exceptionComponent : ApplyExceptionComponent = new ApplyExceptionComponent().confirmComponentHasLoaded();
    exceptionComponent.clickSelectDateLabel();
    let date = this.utils.getCurrentSystemDateAsString();
    exceptionComponent.selectSpecificDateFromCalendar(date);
    this.profileDetails.exceptionSlotValue = exceptionValue;
    exceptionComponent.enterNewAvailability(this.profileDetails.exceptionSlotValue);

    return promise.all([
      exceptionComponent.clickApplyExceptionButton()
    ]);
  }

  @then(/^the applied exception is added to the applied exceptions grid$/)
  public  appliedExceptionIsAddedToGrid(): Promise<any[]> {
    let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();
    return promise.all([
      expect(adminPage.readMostRecentExceptionAvailability(),
        'New availability value has not been entered').to.eventually.equal(this.profileDetails.exceptionSlotValue.toString())
    ]);
  }

  @then(/^the new availability event slot is applied to the calendar$/)
  public verifyExceptionInCalendarPage(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let date = this.utils.getCurrentSystemDateAsString();
    calendarPage.getHeaderComponent().selectDateFromCalendar(date);

    if ('string' === typeof this.profileDetails.exceptionSlotValue) {
      this.profileDetails.exceptionSlotValue = parseInt(this.profileDetails.exceptionSlotValue);
    }

    browser.wait(() => {
      return calendarPage.readSlots(date, EventStatus.AVAILABLE).then((availableSlots) => {
        return availableSlots === this.profileDetails.exceptionSlotValue;
      });
    }, 30000, 'Exception slots not applied');

    return promise.all([
      expect(calendarPage.readSlots(date, EventStatus.AVAILABLE),
        'Applied slots are not added to the calendar for ' + date).to.eventually.equal(this.profileDetails.exceptionSlotValue)
    ]);
  }

  @when(/^I try to apply exception below the number of booked slots for the same applied profile$/)
  public applyExpBelowBookedSlotNumber(): void {
    let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();
    let exceptionComponent : ApplyExceptionComponent =
      adminPage.clickEllipsisApplyException(this.profileDetails.profileName).confirmComponentHasLoaded();
    exceptionComponent.clickSelectDateLabel();

    let date = this.utils.getCurrentSystemDateAsString();
    exceptionComponent.selectSpecificDateFromCalendar(date);
    this.profileDetails.exceptionSlotValue = this.stringGenerator.getRandomNumberInRange(0,50);

    exceptionComponent.enterNewAvailability(1);
    exceptionComponent.clickApplyExceptionButton();
  }

  @then(/^the booked events are not deleted from the calendar page$/)
  public verifyBookedEventsAfterException(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let date = this.utils.getCurrentSystemDateAsString();
    return promise.all([
      expect(calendarPage.readSlots(date, EventStatus.BOOKED),
        'Unexpected number of booked events for date: ' + date).to.eventually.equal(2)
    ]);
  }

  @when(/^I reapply the profile$/)
  public reapplyProfile(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let adminPage: AdministrationPage = calendarPage.getHeaderComponent().getLeftNavComponent().clickAdministrationMenuLink();
    adminPage.clickApplyProfile(this.profileDetails.profileName);
    let applyProfileComponent: ApplyProfileToCalendarComponent = new ApplyProfileToCalendarComponent().confirmComponentHasLoaded();
    applyProfileComponent.clickSelectDateRange();
    applyProfileComponent.selectDateRangeFromCurrentDateThroughDays(10);
    applyProfileComponent.clickApplyToCalendarButton();

    return promise.all([
      expect(adminPage.readNewAppliedProfileName(),
        'Did not find applied profile in list').to.eventually.equal(this.profileDetails.profileName)
    ]);
  }

  @then(/^the total slots does not exceed the profile availability$/)
  public totalSlotsDoesNotExceedProfileAvailability(): Promise<any[]> {
    let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();
    let calendarPage: CalendarPage = adminPage.getHeaderComponent().getLeftNavComponent().clickCalendarMenuLink();
    let date = this.utils.getCurrentSystemDateAsString();
    return promise.all([
      expect(calendarPage.readSlots(date, EventStatus.BOOKED), 'Incorrect number of booked slots').to.eventually.equal(2),
      expect(calendarPage.readSlots(date, EventStatus.AVAILABLE), 'Incorrect number of available slots').to.eventually.equal(4)
    ]);
  }

  @when(/^I click on specific date and enter new availability value negative$/)
  public enterNegativeException(): Promise<any[]> {
    let exceptionComponent : ApplyExceptionComponent = new ApplyExceptionComponent().confirmComponentHasLoaded();
    exceptionComponent.clickSelectDateLabel();

    let date = this.utils.getCurrentSystemDateAsString();
    exceptionComponent.selectSpecificDateFromCalendar(date);

    return promise.all([
      exceptionComponent.enterNewAvailability(-8)
    ]);
  }

  @when(/^I clear and enter new availability value greater than fifty$/)
  public enterAvailabilityAboveFifty(): Promise<any[]> {
    let exceptionComponent : ApplyExceptionComponent = new ApplyExceptionComponent().confirmComponentHasLoaded();
    exceptionComponent.clearExceptionValue();

    return promise.all([
      exceptionComponent.enterNewAvailability(this.stringGenerator.getRandomNumberInRange(51,99))
    ]);
  }

  @when(/^I clear and enter new availability a decimal value$/)
  public enterAvailabilityDecimalValue(): Promise<any[]> {
    let exceptionComponent : ApplyExceptionComponent = new ApplyExceptionComponent().confirmComponentHasLoaded();
    exceptionComponent.clearExceptionValue();

    return promise.all([
      exceptionComponent.enterAvailabilityStringValue('.7')
    ]);
  }

  @when(/^I clear and enter alpha numeric value$/)
  public enterAvailabilityAlphaNumeric(): Promise<any[]> {
    let exceptionComponent : ApplyExceptionComponent = new ApplyExceptionComponent().confirmComponentHasLoaded();
    exceptionComponent.clearExceptionValue();

    return promise.all([
      exceptionComponent.enterAvailabilityStringValue('8r')
    ]);
  }

  @when(/^I clear the exception value$/)
  public clearException(): Promise<any[]> {
    let exceptionComponent : ApplyExceptionComponent = new ApplyExceptionComponent().confirmComponentHasLoaded();

    return promise.all([
      exceptionComponent.clearExceptionValue()
    ]);
  }

  @then(/^I see error message "(.*)"$/)
  public errorMessages(expectedErrorMessage: string): Promise<any[]> {
    let exceptionComponent : ApplyExceptionComponent = new ApplyExceptionComponent().confirmComponentHasLoaded();
    return promise.all([
      expect(exceptionComponent.readAppropriateErrorMessage(),
        'The error message is not appropriate').to.eventually.equal(expectedErrorMessage)
    ]);
  }

  @when(/^I click cancel button to Cancel the Exception$/)
  public clickCancelException(callback:CallbackStepDefinition): void {
    let cancelButtonLocator : any = element(by.xpath('//div[@ng-reflect-ng-switch=\'exception\']/button[text()=\'Cancel\']'));
    cancelButtonLocator.click();
    callback();
  }

  @when(/^I navigate to admin and click ellipses to delete profile$/)
  public clickDeleteProfile(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let adminPage: AdministrationPage = calendarPage.getHeaderComponent().getLeftNavComponent().clickAdministrationMenuLink();
    adminPage.clickEllipsisDeleteProfile(this.profileDetails.profileName);
    return promise.all([
      adminPage.confirmDeleteComponent()
    ]);
  }

  @then(/^the applied profile and exceptions are deleted from the grid$/)
  public appliedProfileAndExceptionDeleted(): Promise<any[]> {
    let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();

    return promise.all([
      expect(adminPage.isProfileApplied(this.profileDetails.profileName),
        'Profile ' + this.profileDetails.profileName + ' should no longer be applied').to.eventually.be.false,
      expect(adminPage.readAppliedExceptionsCount(),
        'There should not be any applied exceptions').to.eventually.equal(0)
    ]);
  }

  @when(/^the applied profile exists for past day with 3 slots$/)
  public appliedProfileForPastDay(): Promise<any[]> {
    this.profileDetails = new ProfileDetails();
    this.profileDetails.profileName = this.stringGenerator.getRandomString(6);
    this.profileDetails.eventsCountOnSunday = 3;
    this.profileDetails.eventsCountOnMonday = 3;
    this.profileDetails.eventsCountOnTuesday = 3;
    this.profileDetails.eventsCountOnWednesday = 3;
    this.profileDetails.eventsCountOnThursday = 3;
    this.profileDetails.eventsCountOnFriday = 3;
    this.profileDetails.eventsCountOnSaturday = 3;

    let userInfo = new User();
    userInfo.username = browser.params.data.validHqUser.username;
    userInfo.password = browser.params.data.validHqUser.password;

    let date = this.utils.getCurrentSystemDateAsString();
    date = this.utils.addDaysAsString(date,-1);
    let pastDate = this.utils.reFormatDate(date);
    this.profileDetails.centerId = browser.params.data.centerIdForCenterCalendarRealm.centerIdForCalendarOne;
    this.serviceUtils.applyProfileThrApi(this.profileDetails,pastDate,pastDate,userInfo,true);

    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let adminPage: AdministrationPage = calendarPage.getHeaderComponent().getLeftNavComponent().clickAdministrationMenuLink();

    return promise.all([
      expect(adminPage.isProfileApplied(this.profileDetails.profileName),
        'Profile ' + this.profileDetails.profileName + ' was not applied').to.eventually.be.true,
      expect(adminPage.readNumberOfTimesProfileIsApplied(this.profileDetails.profileName),
        'Profile ' + this.profileDetails.profileName + ' was applied an incorrect number of times').to.eventually.equal(1)
    ]);
  }

  @when(/^I book an event on the past date in calendar page$/)
  public bookEventsForPastDate(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let date = this.utils.getCurrentSystemDateAsString();
    date = this.utils.addDaysAsString(date,-1);
    let formattedDate = this.utils.reFormatDate(date);

    let eventDetails: EventDetails = new EventDetails(browser.params.data.createNewEventValidData);
    eventDetails.customerName = this.stringGenerator.getRandomString(6);
    eventDetails.zipCode = this.stringGenerator.getRandomNumber(5);
    eventDetails.orderNumber = this.stringGenerator.getRandomAlphaNumericString(30);
    eventDetails.opportunityNumber = this.stringGenerator.getRandomAlphaNumericString(30);
    eventDetails.estimateNumber = this.stringGenerator.getRandomAlphaNumericString(30);

    let slots: number = 0;
    calendarPage.readSlots(date, EventStatus.AVAILABLE).then(number => {
      slots = number;
      this.serviceUtils.bookSlotThroughApi(formattedDate, eventDetails, browser.params.data.centerIdForCenterCalendarRealm.centerIdForCalendarOne);
    });
    browser.refresh();

    return promise.all([
      expect(calendarPage.readSlots(formattedDate, EventStatus.BOOKED), 'Incorrect number of booked slots').to.eventually.equal(slots)
    ]);
  }

  @when(/^the available events and booked events are not deleted in the calendar page for past days$/)
  public verifyBookedAndAvailableForPastDay(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let date = this.utils.getCurrentSystemDateAsString();
    date = this.utils.addDaysAsString(date,-1);
    calendarPage.getHeaderComponent().selectSpecificYearAndMonth(date);

    return promise.all([
      expect(calendarPage.readSlots(date, EventStatus.BOOKED),
        "Unexpected number of booked events for date: " + date).to.eventually.be.greaterThan(0),
      expect(calendarPage.readSlots(date, EventStatus.AVAILABLE),
        "Unexpected number of available slots for date: " + date).to.eventually.be.greaterThan(1)
    ]);
  }

  @when(/^the applied profile exists for future month in applied crew profiles table$/)
  public applyFutureMonthProfile(): Promise<any[]> {
    let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();
    adminPage.clickEllipsisInAvailabilityProfileTable(this.profileDetails.profileName);

    let applyProfileToCalendarComponent: ApplyProfileToCalendarComponent = new ApplyProfileToCalendarComponent().confirmComponentHasLoaded();
    applyProfileToCalendarComponent.clickSelectDateRange();
    applyProfileToCalendarComponent.selectFutureDateRangeFromCalendar();
    applyProfileToCalendarComponent.clickApplyToCalendarButton();

    return promise.all([
      expect(adminPage.readNumberOfTimesProfileIsApplied(this.profileDetails.profileName),
        'Profile ' + this.profileDetails.profileName + ' should be applied twice').to.eventually.equal(2)
    ]);
  }

  @when(/^I delete future month applied profile$/)
  public deleteFutureMonthAppliedProfile(): Promise<any[]> {
    let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();
    adminPage.clickEllipsisDeleteProfileNumber(this.profileDetails.profileName, '2');

    return promise.all([
      adminPage.confirmDeleteComponent()
    ]);
  }

  @then(/^the future month profile is deleted from the grid$/)
  public futureMonthAppliedProfileIsDeleted() {
    let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();
    return promise.all([
      expect(adminPage.readNumberOfTimesProfileIsApplied(this.profileDetails.profileName),
        "The future month applied profile was not deleted").to.eventually.equal(1)
    ]);
  }

  @then(/^the available events for the current month should not be deleted from calendar$/)
  public verifyAvailabilityInCalendar(): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let date = this.utils.getCurrentSystemDateAsString();
    calendarPage.getHeaderComponent().selectDateFromCalendar(date);

    return promise.all([
      expect(calendarPage.readSlots(date, EventStatus.AVAILABLE),
        'Unexpected number of available events for current month').to.eventually.equal(6)
    ]);
  }

  @when(/^I apply another exception for the same date with new availability of (\d+)$/)
  public applyAnotherExceptionForSameDate(exceptionValue: number): Promise<any[]> {
    let calendarPage: CalendarPage = new CalendarPage().confirmPageHasLoaded();
    let adminPage : AdministrationPage = calendarPage.getHeaderComponent().getLeftNavComponent().clickAdministrationMenuLink();
    let exceptionComponent : ApplyExceptionComponent = adminPage.clickEllipsisApplyException(this.profileDetails.profileName).confirmComponentHasLoaded();

    exceptionComponent.clickSelectDateLabel();
    let date = this.utils.getCurrentSystemDateAsString();
    exceptionComponent.selectSpecificDateFromCalendar(date);
    this.profileDetails.exceptionSlotValue = exceptionValue;
    exceptionComponent.enterNewAvailability(this.profileDetails.exceptionSlotValue);

    return promise.all([
      exceptionComponent.clickApplyExceptionButton()
    ]);
  }

  @then(/^the original exception is replaced by the new exception$/)
  public originalExceptionReplacedByNewException(): Promise<any[]> {
    let adminPage: AdministrationPage = new AdministrationPage().confirmPageHasLoaded();

    return promise.all([
      expect(adminPage.readAppliedExceptionsCount(), 'Incorrect number of exceptions').to.eventually.equal(1),
      expect(adminPage.readMostRecentExceptionAvailability(),
        'Incorrect exception value displayed').to.eventually.equal(this.profileDetails.exceptionSlotValue.toString())
    ]);
  }
}

export = ApplyExceptionStepDefinitions;
