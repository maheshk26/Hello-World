import { PlannerUiPage } from './app.po';

describe('planner-ui App', function() {
  let page: PlannerUiPage;

  beforeEach(() => {
    page = new PlannerUiPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
