export class EventStatus {
  static AVAILABLE: string = 'available';
  static RESERVED: string = 'reserved';
  static BOOKED: string = 'booked';
}