export class BookingResponse {
    originCenterCode: string;
    originDate: string;
    destCenterCode: string;
    destDate: string;
    estimateNo: string

    public constructor(info?: BookingResponse) {
        if (info !== undefined) {
            this.originCenterCode = info.originCenterCode;
            this.originDate = info.originDate;
            this.destCenterCode = info.destCenterCode;
            this.destDate = info.destDate;
            this.estimateNo = info.estimateNo;
        } else {
            this.originCenterCode = '';
            this.originDate = '';
            this.destCenterCode = '';
            this.destDate = '';
            this.estimateNo = '';
        }
    }
}
