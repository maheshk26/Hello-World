export class User {
    username: string;
    password: string;

    constructor(user?: User) {
        if (user !== undefined) {
            this.username = user.username;
            this.password = user.password;
        } else {
            this.username = '';
            this.password = '';
        }
    }

}
