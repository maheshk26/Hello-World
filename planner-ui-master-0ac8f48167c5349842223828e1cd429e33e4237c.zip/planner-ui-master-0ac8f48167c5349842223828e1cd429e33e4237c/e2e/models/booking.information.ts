export class BookingInformation {
    zipCode: string;
    customerName: string;
    orderNumber: string;
    opportunityNumber: string;
    estimateNumber: string;
    locationType: string;
    destinationZipCode:string;
    surveyWeightInPounds: string;
    loadDate: string;
    deliveryDate: string;
    earlyLoadDate: string;
    earlyDeliveryDate: string;
    qtgQuoteNumber: string;
    originZipCode: string;
    timeToExpire: number;
    temporalUnit: string;
    flex: string;
    lateLoadDate: string;
    lateDeliveryDate: string;


    constructor(info?: BookingInformation) {
        if (info !== undefined) {
            this.zipCode = info.zipCode;
            this.customerName = info.customerName;
            this.orderNumber = info.orderNumber;
            this.opportunityNumber = info.opportunityNumber;
            this.estimateNumber = info.estimateNumber;
            this.locationType = info.locationType;
            this.destinationZipCode = info.destinationZipCode;
            this.surveyWeightInPounds = info.surveyWeightInPounds;
            this.loadDate = info.loadDate;
            this.deliveryDate = info.deliveryDate;
            this.estimateNumber = info.estimateNumber;
            this.earlyLoadDate = info.earlyLoadDate;
            this.earlyDeliveryDate = info.earlyDeliveryDate;
            this.qtgQuoteNumber = info.qtgQuoteNumber;
            this.originZipCode = info.originZipCode;
            this.timeToExpire = info.timeToExpire;
            this.temporalUnit = info.temporalUnit;
            this.flex = info.flex;
            this.lateLoadDate = info.lateLoadDate;
            this.lateDeliveryDate = info.lateDeliveryDate;
        } else {
            this.zipCode = '';
            this.customerName = '';
            this.orderNumber = '';
            this.opportunityNumber = '';
            this.estimateNumber = '';
            this.locationType = '';
            this.destinationZipCode = '';
            this.surveyWeightInPounds = '';
            this.loadDate = '';
            this.deliveryDate = '';
            this.estimateNumber = '';
            this.earlyLoadDate = '';
            this.earlyDeliveryDate = '';
            this.qtgQuoteNumber = '';
            this.originZipCode = '';
            this.timeToExpire = 0;
            this.temporalUnit = '';
            this.flex = 'false';
            this.lateLoadDate = '';
            this.lateDeliveryDate = '' ;
        }
    }

}
