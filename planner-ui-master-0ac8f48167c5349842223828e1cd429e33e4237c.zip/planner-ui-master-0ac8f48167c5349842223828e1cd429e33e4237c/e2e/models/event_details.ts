export class EventDetails {
    customerName: string;
    locationType: string;
    zipCode: string;
    shipmentType: string;
    orderNumber: string;
    opportunityNumber: string;
    estimateNumber: string;
    flex: string;


    constructor(eventDetails?: EventDetails) {
        if (eventDetails !== undefined) {
            this.customerName = eventDetails.customerName;
            this.locationType = eventDetails.locationType;
            this.zipCode = eventDetails.zipCode;
            this.shipmentType = eventDetails.shipmentType;
            this.orderNumber = eventDetails.orderNumber;
            this.opportunityNumber = eventDetails.opportunityNumber;
            this.estimateNumber = eventDetails.estimateNumber;
            this.flex = eventDetails.flex;
            } else {
            this.customerName = '';
            this.locationType = '';
            this.zipCode = '';
            this.orderNumber = '';
            this.opportunityNumber = '';
            this.estimateNumber = '';
            this.flex = 'false';
        }
    }

}
