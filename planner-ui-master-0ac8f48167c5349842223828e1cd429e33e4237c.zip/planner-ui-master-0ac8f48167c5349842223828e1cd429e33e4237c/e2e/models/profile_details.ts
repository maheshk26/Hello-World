export class ProfileDetails {
    profileName: string;
  eventsCountOnSunday: number;
  eventsCountOnMonday: number;
  eventsCountOnTuesday: number;
  eventsCountOnWednesday: number;
  eventsCountOnThursday: number;
  eventsCountOnFriday: number;
  eventsCountOnSaturday: number;
  exceptionSlotValue: number;
  centerId: string;

    constructor(profileDetails?: ProfileDetails) {
        if (profileDetails !== undefined) {
            this.profileName = profileDetails.profileName;
            this.eventsCountOnSunday = profileDetails.eventsCountOnSunday;
            this.eventsCountOnMonday = profileDetails.eventsCountOnMonday;
            this.eventsCountOnTuesday = profileDetails.eventsCountOnTuesday;
            this.eventsCountOnWednesday = profileDetails.eventsCountOnWednesday;
            this.eventsCountOnThursday = profileDetails.eventsCountOnThursday;
            this.eventsCountOnFriday = profileDetails.eventsCountOnFriday;
            this.eventsCountOnSaturday = profileDetails.eventsCountOnSaturday;
            this.exceptionSlotValue = profileDetails.exceptionSlotValue;
            this.centerId = profileDetails.centerId;
            } else {
            this.profileName = '';
            this.eventsCountOnSunday = 0;
            this.eventsCountOnMonday = 0;
            this.eventsCountOnTuesday = 0;
            this.eventsCountOnWednesday = 0;
            this.eventsCountOnThursday = 0;
            this.eventsCountOnFriday = 0;
            this.eventsCountOnSaturday = 0;
            this.exceptionSlotValue = 0;
            this.centerId = '';
        }
    }

}
