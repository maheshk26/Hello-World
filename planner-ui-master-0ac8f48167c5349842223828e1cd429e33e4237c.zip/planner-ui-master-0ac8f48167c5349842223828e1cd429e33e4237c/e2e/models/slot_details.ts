export class SlotDetails {
    available: number;
    reserved: number;
    booked: number;

    constructor(slotDetails?: SlotDetails) {
        if (slotDetails !== undefined) {
            this.available = slotDetails.available;
            this.reserved = slotDetails.reserved;
            this.booked = slotDetails.booked;
        } else {
            this.available = 0;
            this.reserved = 0;
            this.booked = 0;
        }
    }

}
