import {browser, by, element, protractor, ElementArrayFinder} from 'protractor';
import {CreateEventComponent} from './components/create.event.component';
import {Utils} from '../features/support/utils';
import {DayCalendarPage} from './daycalendar.page';
import {HeaderComponent} from './components/header.component';
import {EventStatus} from "../enums/event.status";

export class CalendarPage {
  private utils: Utils;
  private dataDateXpathPrefix: string;

  constructor() {
    this.utils = new Utils();
    this.dataDateXpathPrefix = '//div[@class=\'fc-content-skeleton\']//td[@data-date=\'';
  }

  public confirmPageHasLoaded(): CalendarPage {
    const pageLocator: any = element(by.xpath('//app-calendar//div[contains(@class, \'calendar-frame\')]'));
    browser.wait(protractor.ExpectedConditions.elementToBeClickable(pageLocator), 2000, 'The Calendar page did not load');
    return this;
  }

  public getHeaderComponent(): HeaderComponent {
    return new HeaderComponent().confirmComponentIsAvailable();
  }

  public getClassAttributeOfCalendarView() : Promise<any>{
    const allCalendarViewContainerLocator: any = element(by.xpath('//div[@class=\'fc-view-container\']/div[1]'));
    return allCalendarViewContainerLocator.getAttribute('class');
  }

  public readCurrentDate(): Promise<any> {
    const currentDateLocator: any = element(by.xpath('//div[contains(@class,\'fc-bg\')]//td[contains(@class,\'fc-today\')]'));
    this.utils.scrollIntoView(currentDateLocator);
    return currentDateLocator.getAttribute("data-date");
   }

  // calendarDate format must be yyyy-MM-dd ()
  public clickSlotsRow(calendarDate: string, eventStatus: EventStatus): any {
    let columnNumber: number = null;
    this.determineColumnNumberForFirstRowSlots(calendarDate).then((result) => {
      columnNumber = result;
      this.readTextInSlotRow(calendarDate, 1, columnNumber).then(rowText => {
        if (rowText.indexOf(eventStatus.toString()) >= 0) {
          this.clickSlotInRow(calendarDate, 1, columnNumber);
        } else {
          this.determineColumnNumberForSecondOrThirdRowSlots(calendarDate, columnNumber, 2).then(columnNumberForSecondRow => {
            this.readTextInSlotRow(calendarDate, 2, columnNumberForSecondRow).then(rowText => {
              if (rowText.indexOf(eventStatus.toString()) >= 0) {
                this.clickSlotInRow(calendarDate, 2, columnNumberForSecondRow);
              } else {
                this.determineColumnNumberForSecondOrThirdRowSlots(calendarDate, columnNumber, 3).then(columnNumberForThirdRow => {
                  this.readTextInSlotRow(calendarDate, 3, columnNumberForThirdRow).then(rowText => {
                    if (rowText.indexOf(eventStatus.toString()) >= 0) {
                      this.clickSlotInRow(calendarDate, 3, columnNumberForThirdRow);
                    } else {
                      console.log('third row was not ' + eventStatus.toString() + '  slot either');
                    }
                  });
                });
              }
            });
          });
        }
      });
    });

    if (EventStatus.AVAILABLE === eventStatus) {
      return new CreateEventComponent().confirmComponentIsAvailable();
    } else {
      return new DayCalendarPage().confirmPageHasLoaded();
    }
  }

  public isAvailableSlotClickable(calendarDate: string): Promise<boolean> {
    let columnNumber: number = null;
    this.determineColumnNumberForFirstRowSlots(calendarDate).then((result) => {
      columnNumber = result;
      this.readTextInSlotRow(calendarDate, 1, columnNumber).then(rowText => {
        if (rowText.indexOf('available') >= 0) {
          this.clickSlotInRow(calendarDate, 1, columnNumber);
        } else {
          this.determineColumnNumberForSecondOrThirdRowSlots(calendarDate, columnNumber, 2).then(columnNumberForSecondRow => {
            this.readTextInSlotRow(calendarDate, 2, columnNumberForSecondRow).then(rowText => {
              if (rowText.indexOf('available') >= 0) {
                this.clickSlotInRow(calendarDate, 2, columnNumberForSecondRow);
              } else {
                this.determineColumnNumberForSecondOrThirdRowSlots(calendarDate, columnNumber, 3).then(columnNumberForThirdRow => {
                  this.readTextInSlotRow(calendarDate, 3, columnNumberForThirdRow).then(rowText => {
                    if (rowText.indexOf('available') >= 0) {
                      this.clickSlotInRow(calendarDate, 3, columnNumberForThirdRow);
                    } else {
                      console.log('third row was not available slot either');
                    }
                  });
                });
              }
            });
          });
        }
      });
    });

    let createEventComponent: CreateEventComponent = new CreateEventComponent();
    return createEventComponent.isComponentVisible();
  }

  public readSlots(calendarDate: string, eventStatus: EventStatus): Promise<number> {
    let columnNumber: number = null;
    let deferred = protractor.promise.defer();

    this.determineColumnNumberForFirstRowSlots(calendarDate).then((result) => {
      columnNumber = result;
      this.readTextInSlotRow(calendarDate, 1, columnNumber).then(rowText => {
        if (rowText.indexOf(eventStatus.toString()) >= 0) {
          deferred.fulfill(this.getNumberFromSlotText(rowText));
        } else {
          this.determineColumnNumberForSecondOrThirdRowSlots(calendarDate, columnNumber, 2).then(columnNumberForSecondRow => {
            this.readTextInSlotRow(calendarDate, 2, columnNumberForSecondRow).then(rowText => {
              if (rowText.indexOf(eventStatus.toString()) >= 0) {
                deferred.fulfill(this.getNumberFromSlotText(rowText));
              } else {
                this.determineColumnNumberForSecondOrThirdRowSlots(calendarDate, columnNumber, 3).then(columnNumberForThirdRow => {
                  this.readTextInSlotRow(calendarDate, 3, columnNumberForThirdRow).then(rowText => {
                      if (rowText.indexOf(eventStatus.toString()) >= 0) {
                        deferred.fulfill(this.getNumberFromSlotText(rowText));
                      } else {
                        console.log('third row was not ' + eventStatus.toString() + ' slot either');
                        deferred.fulfill(0);
                      }
                    },
                    err => {
                      console.log('error reading text in third slot row');
                      deferred.fulfill(0);
                    });
                });
              }
            },
            err => {
              console.log('error reading text in second slot row');
              deferred.fulfill(0);
            });
          });
        }
      },
      err => {
        deferred.fulfill(0);
      });
    });

    return deferred.promise;
  }

  private readTextInSlotRow(calendarDate: string, rowNumber: number, columnNumber: number): Promise<string> {
    let calendarDayLocator: any = element(by.xpath(this.dataDateXpathPrefix
      + calendarDate + '\']/../../../tbody/tr[' + rowNumber + ']/td[' + columnNumber + ']//span'));

    return calendarDayLocator.getText();
  }

  private clickSlotInRow(calendarDate: string, rowNumber: number, columnNumber: number): Promise<any> {
    let calendarDayLocator: any = element(by.xpath(this.dataDateXpathPrefix
      + calendarDate + '\']/../../../tbody/tr[' + rowNumber + ']/td[' + columnNumber + ']//span'));

    browser.wait(protractor.ExpectedConditions.elementToBeClickable(calendarDayLocator),
      1000, 'Unable to find row ' + rowNumber + 'on ' + calendarDate);

    return calendarDayLocator.click();
  }

  private determineColumnNumberForFirstRowSlots(calendarDate: string): Promise<number> {
    let calendarRowLocator: ElementArrayFinder = element.all(by.xpath(this.dataDateXpathPrefix + calendarDate + '\']/../td'));
    let columnNumber: number = null;
    let count: number = 0;
    return calendarRowLocator.each(td => {
      td.getAttribute('data-date').then(date => {
        count++;
        if (calendarDate === date) {
          columnNumber = count;
        }
      });
    }).then(() => {
      let deferred = protractor.promise.defer();
      deferred.fulfill(columnNumber);
      return deferred.promise;
    });
  }


  private determineColumnNumberForSecondOrThirdRowSlots(calendarDate: string, columnNumber: number, rowNumber: number): Promise<number> {
    let rowColumnNumber: number = 0;
    let previousRowLocator: any = element.all(by.xpath(this.dataDateXpathPrefix
      + calendarDate + '\']/../../../tbody/tr[' + (rowNumber - 1) + ']/td'));

    let count = 0;
    return previousRowLocator.each(td => {
      td.getAttribute('rowspan').then(attrValue => {
        count++;
        if((attrValue == null || attrValue == 0) && count <= columnNumber ) {
          rowColumnNumber++;
        } else if (attrValue != null && attrValue != 0 && count === columnNumber) {
          rowColumnNumber = null;
        }
      });
    }).then(() => {
      let deferred = protractor.promise.defer();
      deferred.fulfill(rowColumnNumber);
      return deferred.promise;
    });
  }

  private getNumberFromSlotText(text: string): number {
    let numberAsString = text.split(' ')[0];
    return parseInt(numberAsString);
  }


  public isEventBookedInMonthView(calendarDate: string , customerName:string): Promise<boolean> {
    let deferred = protractor.promise.defer();
    this.readSlots(calendarDate, EventStatus.BOOKED).then((numberOfBookedSlots) => {
      if(numberOfBookedSlots > 0){
        let dayCalendarPage: DayCalendarPage = this.clickSlotsRow(calendarDate, EventStatus.BOOKED);
        dayCalendarPage.isEventBookedInDayView(customerName).then((nameFound) => {
          return deferred.fulfill(nameFound);
        })
      } else {
        return deferred.fulfill(false);
      }
    });
    return deferred.promise;
  }

  public isEventReservedInMonthView(calendarDate: string , customerName:string): Promise<boolean> {
    let deferred = protractor.promise.defer();

    this.readSlots(calendarDate, EventStatus.RESERVED).then((numberOfBookedSlots) => {
      if(numberOfBookedSlots > 0){
        let dayCalendarPage: DayCalendarPage = this.clickSlotsRow(calendarDate, EventStatus.RESERVED);
        dayCalendarPage.isEventReservedInDayView(customerName).then((nameFound) => {
          return deferred.fulfill(nameFound);
        })
      } else {
        return deferred.fulfill(false);
      }
    });
    return deferred.promise;
  }

  public isFlexIconPresent(): Promise<boolean> {
    const flexLocator: any = element(by.xpath('//*[@class = \'LKflexDateIcon pull-right\']//span/i[@class = \'fa fa-arrow-left\']'));
    return flexLocator.isPresent();
  }

}


