import {browser, by, element, protractor} from 'protractor';
import {Utils} from '../features/support/utils';
import {CalendarPage} from './calendar.page';

export class LoginPage {

    public loginButton: any;
    public userName: any;
    public password: any;
    public loginErrorMsgLocator: any;
    public pageHeaderLocator: any;
    private utils: Utils;

    constructor() {
        this.utils = new Utils();
        this.pageHeaderLocator = element(by.xpath('//img[contains(@class,\'logo\')]'));
        this.userName = element(by.id('username'));
        this.password = element(by.id('password'));
        this.loginButton = element(by.buttonText('Login'));
        this.loginErrorMsgLocator = element(by.xpath('//app-login//p[contains(@class,\'alert\')]'));
    }

    public confirmPageHasLoaded(): LoginPage {
      browser.wait(protractor.ExpectedConditions.elementToBeClickable(this.userName), 5000, 'The Login page did not load');
      return this;
    }

    public login(userName, password): CalendarPage {
        this.enterUsername(userName);
        this.enterPassword(password);
        this.clickLoginBtn();

        return new CalendarPage();
    };

    public enterUsername(userName: string): Promise<any[]> {
        this.utils.scrollIntoView(this.userName);
        return this.userName.clear().sendKeys(userName);
    }

    public enterPassword(password: string): Promise<any[]> {
        this.utils.scrollIntoView(this.password);
        return this.password.clear().sendKeys(password);
    }

    public clickLoginBtn(): Promise<any[]> {
        this.utils.scrollIntoView(this.loginButton);
        return this.loginButton.click();
    }

    public readLoginErrorMessage(): Promise<any[]> {
        this.utils.scrollIntoView(this.loginErrorMsgLocator);
        return this.loginErrorMsgLocator.getText();
    }
}
