import {browser, by, element, protractor, ElementArrayFinder} from 'protractor';
import {CreateEventComponent} from './components/create.event.component';
import {HeaderComponent} from './components/header.component';

export class WeekCalendarPage {
  private customerNameLocator: any;
  private dateDateXpathPrefixInWeekCalendar: any;

  constructor() {
    this.customerNameLocator = element(by.id('customerName'));
    this.dateDateXpathPrefixInWeekCalendar = '//div[@class=\'fc-bg\']//td[@data-date=\'';
  }

  public confirmPageHasLoaded(): WeekCalendarPage {
    let weekPageLocator: any = element(by.xpath('//app-calendar//div[contains(@class, \'fc-basicWeek-view\')]'));
    browser.wait(protractor.ExpectedConditions.elementToBeClickable(weekPageLocator), 2000, 'The Week Calendar page did not load');
    return this;
  }

  public getHeaderComponent(): HeaderComponent {
    return new HeaderComponent().confirmComponentIsAvailable();
  }

  private getColumnNumberInWeekCalendar(calendarDate: string): Promise<number> {
    let calendarRowLocator: ElementArrayFinder = element.all(by.xpath(this.dateDateXpathPrefixInWeekCalendar + calendarDate + '\']/../td'));
    let columnNumber: number = null;
    let count: number = 0;
    return calendarRowLocator.each(td => {
      td.getAttribute('data-date').then(date => {
        count++;
        if (calendarDate === date) {
          columnNumber = count;
        }
      });
    }).then(() => {
      let deferred = protractor.promise.defer();
      deferred.fulfill(columnNumber);
      return deferred.promise;
    });
  }

  public clickOpenSlotsRowInWeekCalendar(calendarDate: string): CreateEventComponent {
    this.getColumnNumberInWeekCalendar(calendarDate).then((result) => {
      let columnNumber: number = null;
      columnNumber = result;
      let calendarRowLocator: ElementArrayFinder = element.all(by.xpath('//div[@class=\'fc-content-skeleton\']//tr/td[' + columnNumber + ']/a/div/span'));
      let count: number = 0;
      calendarRowLocator.each(span => {
        this.customerNameLocator.isDisplayed().then(function (isDisplayed) {
          if (!isDisplayed) {
            span.getText().then(slot => {
              count++;
              if (slot.indexOf('Open slot') >= 0) {
                span.click();
              }
              if (count === 6 && !isDisplayed) {
                console.log("Open slots are not available");
              }
            });
          }
        });
      });
    });
    return new CreateEventComponent().confirmComponentIsAvailable();
  }

  public clickBookedSlotsRowInWeekCalendar(calendarDate: string, customerName: string) {
    this.getColumnNumberInWeekCalendar(calendarDate).then((result) => {
      let columnNumber: number = null;
      let deferred = protractor.promise.defer();
      columnNumber = result;
      let calendarRowLocator: ElementArrayFinder = element.all(by.xpath('//div[@class=\'fc-content-skeleton\']//tr/td[' + columnNumber + ']/a/div/span[text()= \'+Customer Name\']'));
      let count: number = 0;
      calendarRowLocator.each(span => {
        this.customerNameLocator.isDisplayed().then(function (isDisplayed) {
          if (!isDisplayed) {
            span.getText().then(slot => {
              count++;
              if (slot.indexOf(customerName) >= 0) {
                span.click();
              }
              if (count === 12 && !isDisplayed) {
                console.log("Booked slots are not available");
              }
            });
          }
        });
      });
    });
  }

  public clickBookedSlotInWeek(calendarDate: string, customerName: string) {
    let calendarRowLocator: any = element(by.xpath('//div[@class=\'fc-content-skeleton\']//tr/td/a/div/span[text()= \'' + customerName + '\']'));
    let readCustomerFromScreen = calendarRowLocator.getText().then(function(value){
       if(customerName === value){
        calendarRowLocator.click();
      }
    });
  }

  public isEventBookedInWeekView(calendarDate: string, customerName: string): Promise<boolean> {
    let columnNumber: number = null;
    let deferred = protractor.promise.defer();
    let blnFound: boolean = false;
      let calendarRowLocator :  any = element(by.xpath('//div[@class=\'fc-content-skeleton\']//tr/td/a/div/span[text()= \''+customerName+'\']'));
      let count: number = 0;
      calendarRowLocator.isPresent().then(function(result) {
        if(result) {
          calendarRowLocator.getText().then(function (isDisplayed) {
            if (isDisplayed === customerName) {
              blnFound = true;
              return deferred.fulfill(blnFound);
            }
            if (!blnFound) {
              console.log("New Event is not created");
              return deferred.fulfill(false);
            }
          });
        }
        else {
          return deferred.fulfill(false);
        }
      });
    return deferred.promise;
  }
}
