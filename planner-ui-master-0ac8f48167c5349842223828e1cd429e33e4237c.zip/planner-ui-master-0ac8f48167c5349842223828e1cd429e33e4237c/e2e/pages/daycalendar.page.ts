import {browser, by, element, protractor, ElementArrayFinder} from 'protractor';
import {CreateEventComponent} from './components/create.event.component';
import {HeaderComponent} from './components/header.component';
import {DeleteUpdateEventComponent} from "./components/delete.update.event.component";


export class DayCalendarPage {

  private customerNameLocator: any;
  private scrollBar: any;

  constructor() {
    this.customerNameLocator = element(by.id('customerName'));
    this.scrollBar = element(by.xpath('//div[@class=\'fc-scroller fc-day-grid-container\']'));
  }

  public confirmPageHasLoaded(): DayCalendarPage {
    let dayPageLocator: any = element(by.xpath('//app-calendar//div[contains(@class, \'fc-basicDay-view\')]'));
    browser.wait(protractor.ExpectedConditions.elementToBeClickable(dayPageLocator), 2000, 'The Day Calendar page did not load');
    return this;
  }

  public getHeaderComponent(): HeaderComponent {
    return new HeaderComponent().confirmComponentIsAvailable();
  }

  public clickOpenSlotsRowInDayCalendar(calendarDate: string): CreateEventComponent {
    let calendarRowLocator: ElementArrayFinder = element.all(by.xpath('//div[@class=\'fc-content-skeleton\']//tr/td/a/div/span'));
    let count: number = 0;
    calendarRowLocator.each(span => {
      this.customerNameLocator.isDisplayed().then(function(isDisplayed){
        if(!isDisplayed){
          span.getText().then(slot => {
            count++;
            if (slot.indexOf('Open slot') >= 0) {
              span.click();
            }
          });
        }
      });
    });
    return new CreateEventComponent().confirmComponentIsAvailable();
  }

  public isBookedSlotClickable(customerName: string): Promise<boolean> {
    let calendarRowLocator: ElementArrayFinder = element.all(by.xpath('//div[@class=\'fc-content-skeleton\']//tr/td/a//div[contains(@class,\'panel-heading-booked\')]'));
    let count: number = 0;
    let foundIt: boolean = false;

    calendarRowLocator.each(span => {
      this.customerNameLocator.isDisplayed().then(function(isDisplayed) {
        if(!isDisplayed) {
          span.getText().then(slot => {
            count++;
            if(slot.indexOf(customerName)>=0){
              span.click();
            }
          });
        }
      });
    });

    let updateEventComponent: DeleteUpdateEventComponent = new DeleteUpdateEventComponent();
    return updateEventComponent.isComponentVisible();
  }

  public isEventBookedInDayView(customerName: string): Promise<boolean> {
    let calendarRowLocator: ElementArrayFinder = element.all(by.xpath('//div[@class=\'fc-content-skeleton\']//tr/td/a//div[contains(@class,\'panel-heading-booked\')]'));
    let count: number = 0;
    let blnFound: boolean = false;
    let deferred = protractor.promise.defer();
    calendarRowLocator.count().then(size => {
      if (size === 0) {
        return deferred.fulfill(false);
      }
      calendarRowLocator.each(span => {
        span.getText().then(slot => {
          count++;
          if (slot.indexOf(customerName) >= 0) {
            blnFound = true;
            return deferred.fulfill(blnFound);
          }
          if(!blnFound && count==size){
            return deferred.fulfill(false);
          }
        });
      });
    });
    return deferred.promise;
  }

  public clickBookedSlotsRowInDayCalendar(customerName:string): Promise<boolean> {
    let calendarRowLocator: ElementArrayFinder = element.all(by.xpath('//div[@class=\'fc-content-skeleton\']//tr/td/a//div[contains(@class,\'panel-heading-booked\')]'));
    let deferred = protractor.promise.defer();
    let count: number = 0;
    let foundIt: boolean = false;

    calendarRowLocator.each(span => {
      this.customerNameLocator.isDisplayed().then(function(isDisplayed) {
        if(!isDisplayed) {
          span.getText().then(slot => {
            count++;
            if(slot.indexOf(customerName)>=0){
              span.click();
              foundIt = true;
              return deferred.fulfill(foundIt);
            }
          });
        }
      });
    });

    return deferred.promise;
  }

  public isEventReservedInDayView(customerName:string): Promise<boolean> {
    let calendarRowLocator: ElementArrayFinder = element.all(by.xpath('//div[@class=\'fc-content-skeleton\']//tr/td/a//div[contains(@class,\'panel-heading-reserved\')]'));
    let count: number = 0;
    let blnFound: boolean = false;
    let deferred = protractor.promise.defer();
    calendarRowLocator.count().then(size => {
      if (size === 0) {
        return deferred.fulfill(false);
      }
      calendarRowLocator.each(span => {
        span.getText().then(slot => {
          count++;
          if (slot.indexOf(customerName) >= 0) {
            blnFound = true;
            return deferred.fulfill(blnFound);
          }
          if(!blnFound && count==size){
            return deferred.fulfill(false);
          }
        });
      });
    });
    return deferred.promise;
  }

  public readLocationType(customerName: string):Promise<any>{
    let locationTypeLocator: any= element(by.xpath('//div[contains(.,\'' + customerName +'\')]/..//p[contains(.,\'Location Type:\')]'));
    return locationTypeLocator.getText();
  }

  public readZipCode(customerName: string):Promise<string>{
    let zipCodeLocator: any= element(by.xpath('//div[contains(.,\'' + customerName +'\')]/..//p[contains(.,\'ZIP Code:\')]'));
    return zipCodeLocator.getText();
  }

  public readShipmentType(customerName: string):Promise<string>{
    let shipmentTypeLocator: any= element(by.xpath('//div[contains(.,\'' + customerName +'\')]/..//p[contains(.,\'Shipment Type:\')]'));
    return shipmentTypeLocator.getText();
  }

  public readOrderNumber(customerName: string):Promise<string>{
    let orderNumberLocator: any= element(by.xpath('//div[contains(.,\'' + customerName +'\')]/..//p[contains(.,\'Order Number:\')]'));
    return orderNumberLocator.getText();
  }

  public readTrackingNumber(customerName: string):Promise<string>{
    let trackingNumberLocator: any= element(by.xpath('//div[contains(.,\'' + customerName +'\')]/..//p[contains(.,\'Tracking Number:\')]'));
    return trackingNumberLocator.getText();
  }

  public readQuoteNumber(customerName: string):Promise<string>{
    let quoteNumberLocator: any= element(by.xpath('//div[contains(.,\'' + customerName +'\')]/..//p[contains(.,\'Quote Number:\')]'));
    return quoteNumberLocator.getText();
  }

  public readFlexDate(customerName: string):any {
    let flexDateLocator: any = element(by.xpath('//div[contains(.,\'' + customerName +'\')]/..//div[contains(@class,\'LKflexDateIcon\')]/../p/../..//div[3]/p'));
    return flexDateLocator;
  }

}

