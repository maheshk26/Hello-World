import {browser, by, element, protractor} from 'protractor';
import {AddNewProfileComponent} from '../components/add.new.profile.component';
import {Utils} from '../../features/support/utils';
import {ApplyExceptionComponent} from '../components/apply.exception.component';
import {HeaderComponent} from '../components/header.component';

export class AdministrationPage {

  private adminTitleLocator: any;
  private addNewCrewAvailabilityProfileButtonLocator: any;
  private appliedCrewProfilesLocator: any;
  private errorMsgLocator: any;
  private utils: Utils;

  constructor() {
    this.utils = new Utils();
    this.adminTitleLocator = element(by.xpath('//h3[@class=\'adminTitle\']'));
    this.addNewCrewAvailabilityProfileButtonLocator = element(by.buttonText('+ Add New Crew Availability Profile'));
    this.appliedCrewProfilesLocator = element(by.xpath('//legend[text()=\'Crew Availability Profiles\']/following-sibling::div/table/tbody/tr[last()]'));
    this.errorMsgLocator = element(by.xpath('//app-admin//p[@class=\'market-view\']'));
  }

  public getHeaderComponent(): HeaderComponent {
    return new HeaderComponent().confirmComponentIsAvailable();
  }

  public confirmPageHasLoaded(): AdministrationPage {
    let expectedConditions = protractor.ExpectedConditions;
    let adminPageHeaderLocator = element(by.xpath('//app-admin//div[contains(@class,\'calendar-frame\')]/div/div/h3'));
    let adminHeaderIsVisibleCondition = expectedConditions.visibilityOf(adminPageHeaderLocator);
    let errorMsgIsVisibleCondition = expectedConditions.visibilityOf(this.errorMsgLocator);

    browser.wait(expectedConditions.or(adminHeaderIsVisibleCondition, errorMsgIsVisibleCondition), 8000, 'The Administration page did not load');
    return this;
  }

  public clickAddNewCewAvailabilityProfile():AddNewProfileComponent {
    browser.wait(protractor.ExpectedConditions.elementToBeClickable(this.addNewCrewAvailabilityProfileButtonLocator), 1000,
      'Add New Crew Availability Profile button is not clickable');
    this.utils.scrollIntoView(this.addNewCrewAvailabilityProfileButtonLocator);
    this.addNewCrewAvailabilityProfileButtonLocator.click();
    return new AddNewProfileComponent().confirmComponentHasLoaded();
  }

  public readNewCreatedProfileName():Promise<string>{
    let profileNameLocator: any = element((by.xpath('//legend[text()=\'Crew Availability Profiles\']/following-sibling::div/table/tbody/tr[last()]/td[2]')));
    this.utils.scrollIntoView(profileNameLocator);
    return profileNameLocator.getText();
  }

  public isProfilePresent(profileName: string): Promise<boolean> {
    let profileNameLocator: any =
      element(by.xpath('//legend[text()=\'Crew Availability Profiles\']/following-sibling::div//td[2 and contains(., \'' + profileName + '\')]'));
    return profileNameLocator.isPresent();
  }

  public readAvailabilitySlotValue(profileName: string, day: string): Promise<any> {
    let slotLocator: any =
      element(by.xpath('//legend[text()=\'Crew Availability Profiles\']/following-sibling::div//td[contains(.,\'' + profileName + '\')]/../td[3]'));
    let dayNumber = 0 ;
    let deferred = protractor.promise.defer();

    slotLocator.getText().then((result) => {
      switch (day.toUpperCase()) {
        case 'SUN' :
        dayNumber = 0;
          break;
        case 'MON' :
          dayNumber = 1;
          break;
        case 'TUE' :
          dayNumber = 2;
          break;
        case 'WED' :
          dayNumber = 3;
          break;
        case 'THU' :
          dayNumber = 4;
          break;
        case 'FRI' :
          dayNumber = 5;
          break;
        case 'SAT' :
          dayNumber = 6;
          break;
      }
      let slots : string[] = result.toString().split("|");
      let availableSlots : string[] = slots[dayNumber].split(":");
      deferred.fulfill(parseInt(availableSlots[1]));
    },
    err => {
      deferred.fulfill(-1);
    });
    return deferred.promise;
  }


  public clickEllipsisInAvailabilityProfileTable(profileName: string):Promise<void> {
    let clickActionsForNewAddedProfile = element(by.xpath('//legend[text()=\'Crew Availability Profiles\']/following-sibling::div/table/tbody/tr/td[contains(.,\''+profileName+'\')]/../td[4]/a/i'));
    this.utils.scrollIntoView(clickActionsForNewAddedProfile);
    clickActionsForNewAddedProfile.click();
    let clickApplyToCalendar = element(by.xpath('//div[@class=\'actions-list\']/a'));
    return clickApplyToCalendar.click();
  }

  public clickApplyProfile(profileName: string): Promise<void> {
    let clickActionsForNewAddedProfile =
      element(by.xpath('//legend[text()=\'Crew Availability Profiles\']/following-sibling::div//td[contains(., \'' + profileName + '\')]/../td[4]//i'));
    this.utils.scrollIntoView(clickActionsForNewAddedProfile);
    clickActionsForNewAddedProfile.click();
    let clickApplyToCalendar = element(by.xpath('//div[@class=\'actions-list\']/a'));
    return clickApplyToCalendar.click();
  }

  public readNewAppliedProfileName() {
    let profileNameLocator: any = element(by.xpath('//legend[text()=\'Applied Crew Profiles\']/following-sibling::div/table/tbody/tr[last()]/td[2]'));
    return profileNameLocator.getText();
  }

  public isProfileApplied(profileName: string): Promise<boolean> {
    let profileNameLocator: any =
      element(by.xpath('//legend[text()=\'Applied Crew Profiles\']/following-sibling::div//td[2 and contains(., \'' + profileName + '\')]'));
    return profileNameLocator.isPresent();
  }

  public readNumberOfTimesProfileIsApplied(profileName: string): Promise<number> {
    let profileNameLocator: any =
      element.all(by.xpath('//legend[text()=\'Applied Crew Profiles\']/following-sibling::div//td[2 and contains(., \'' + profileName + '\')]'));
    return profileNameLocator.count();
  }

  public clickEllipsisApplyException(profileName: string): ApplyExceptionComponent {
    let clickActionsAppliedProfile =
      element(by.xpath('//legend[text()=\'Applied Crew Profiles\']/following-sibling::div//td[text()=\'' + profileName + '\']/../td[5]/a/i'));

    this.utils.scrollIntoView(clickActionsAppliedProfile);
    clickActionsAppliedProfile.click();

    let clickApplyToCalendar =
      element(by.xpath('//div[@class=\'actions-menu\']//a[contains(., \'Apply\') and contains(., \'Exception\')]'));
    clickApplyToCalendar.click();

    return new ApplyExceptionComponent().confirmComponentHasLoaded();
  }

  public readMostRecentExceptionAvailability() : Promise<any>{
    let availabilityLocator = element(by.xpath('//legend[text()=\'Applied Exceptions\']/following-sibling::div/table/tbody/tr[last()]/td[3]'));
    return availabilityLocator.getText();
  }

  public readExceptionDate() : Promise<any>{
    let dateLocator = element(by.xpath('//legend[text()=\'Applied Exceptions\']/following-sibling::div/table/tbody/tr[last()]/td[2]'));
    return dateLocator.getText();
  }

  public clickEllipsisDeleteProfile(profileName: string) {
    let clickActionsAppliedProfile = element(by.xpath('//legend[text()=\'Applied Crew Profiles\']/following-sibling::div//tr[contains(.,\'' + profileName + '\')]/td[5]/a/i'));
    this.utils.scrollIntoView(clickActionsAppliedProfile);
    clickActionsAppliedProfile.click();

    let clickDeleteProfile = element(by.xpath('//div[@class=\'actions-menu\']/div[2]/a'));
    clickDeleteProfile.click();
  }

  public clickEllipsisDeleteProfileNumber(profileName: string, number: string) {
    let clickActionsAppliedProfile =
      element(by.xpath('//legend[text()=\'Applied Crew Profiles\']/following-sibling::div//tr[contains(.,\'' + profileName + '\')][' + number + ']/td[5]/a/i'));
    this.utils.scrollIntoView(clickActionsAppliedProfile);
    clickActionsAppliedProfile.click();

    let clickDeleteProfile = element(by.xpath('//div[@class=\'actions-menu\']/div[2]/a'));
    clickDeleteProfile.click();
  }

  public verifyAppliedProfileAndExceptions(profileName: string): Promise<boolean>{
    let profileNameLocator: any = element(by.xpath('//legend[text()=\'Applied Crew Profiles\']/following-sibling::div/table/tbody/tr[last()]/td[2]'));
    let deferred = protractor.promise.defer();

    profileNameLocator.isPresent().then(function(result) {
      if(result){
        profileNameLocator.getText().then(function(name){
          if (name===profileName){
            deferred.fulfill(true);
          }else{
            deferred.fulfill(false);
          }
        });
      }else {
        deferred.fulfill(false);
      }
    });
    return deferred.promise;
  }

  public confirmDeleteComponent(): Promise<void> {
    let pageHeader = element(by.xpath('//div[@class=\'modal-header\']//h3[text()=\'Delete applied Crew profile\']'));
    browser.wait(protractor.ExpectedConditions.visibilityOf(pageHeader), 3000, 'The delete applied crew profile component did not load');
    return element(by.buttonText('Delete')).click();
  }

  public readAppliedExceptionsCount(): Promise<number> {
    let appliedExceptionsTable: any = element.all(by.xpath('//legend[text()=\'Applied Exceptions\']/..//table/tbody/tr'));
    return appliedExceptionsTable.count();
  }

  public isErrorMessagePresent(): Promise<boolean> {
    return this.errorMsgLocator.isPresent();
  }

  public readErrorMessage(): Promise<string> {
    return this.errorMsgLocator.getText();
  }
}
