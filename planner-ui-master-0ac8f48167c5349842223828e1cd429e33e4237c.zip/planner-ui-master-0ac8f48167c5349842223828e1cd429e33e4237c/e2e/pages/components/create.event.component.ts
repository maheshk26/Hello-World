import {browser, by, element, protractor} from 'protractor';
import {ServiceUtils} from "../../features/support/service.utils";
import {Utils} from "../../features/support/utils";
import {SelectWrapper} from "../../features/support/select_wrapper";

export class CreateEventComponent {

  private serviceUtils: ServiceUtils = new ServiceUtils();
  public utils: Utils = new Utils();

  private componentLocator: any;
  private customerNameLocator: any;
  private originLocationTypeLocator: any;
  private zipCodeLocator: any;
  private shipmentTypeLocator: any;
  private headerLocator: any;
  private orderNumberLocator: any;
  private destLocationTypeLocator: any;
  private trackingNumberLocator: any;
  private quoteNumberLocator: any;
  public addEventLocator: any;
  private cancelButtonLocator: any;
  private customerNameErrorLocator: any;
  private zipCodeErrorLocator: any;
  private orderNumberErrorLocator: any;
  private trackingNumberErrorLocator: any;
  private quoteNumberErrorLocator: any;
  private createEventErrorMessage: any;
  public invalidCustomerNameError: any;
  private componentCalendarLocator:any;
  private previousMonthArrowLocator:any;
  private futureMonthArrowLocator:any;
  private monthButtonLocator: any;
  private previousYearArrowLocator:any;
  private futureYearArrowLocator:any;
  private YearButtonLocator: any;

  constructor() {
    this.componentLocator = element(by.xpath('//div[contains(@class,\'modal-content\')]'));
    this.customerNameLocator = element(by.id('customerName'));
    this.originLocationTypeLocator = element(by.xpath('//input[@name=\'locationType\' and @value=\'ORIGIN\']/../span'));
    this.destLocationTypeLocator = element(by.xpath('//input[@name=\'locationType\' and @value=\'DESTINATION\']/../span'));
    this.zipCodeLocator = element(by.id('zipCode'));
    this.shipmentTypeLocator = new SelectWrapper(by.id('shipmentType'));
    this.orderNumberLocator = element(by.id('orderNumber'));
    this.trackingNumberLocator = element(by.id('opportunityNumber'));
    this.quoteNumberLocator = element(by.id('estimateNumber'));
    this.addEventLocator = element(by.buttonText('Add Event'));
    this.cancelButtonLocator = element(by.buttonText('Cancel'));
    this.customerNameErrorLocator = element(by.xpath('//input[@id=\'customerName\']/../div[contains(@class,\'alert-danger\')]'));
    this.zipCodeErrorLocator = element(by.xpath('//input[@id=\'zipCode\']/../div[contains(@class,\'alert-danger\')]'));
    this.orderNumberErrorLocator = element(by.xpath('//input[@id=\'orderNumber\']/../div[contains(@class,\'alert-danger\')]'));
    this.trackingNumberErrorLocator = element(by.xpath('//input[@id=\'opportunityNumber\']/../div[contains(@class,\'alert-danger\')]'));
    this.quoteNumberErrorLocator = element(by.xpath('//input[@id=\'estimateNumber\']/../div[contains(@class,\'alert-danger\')]'));
    this.createEventErrorMessage = element(by.xpath('//div[@class=\'row\']/./div[contains(@class,\'alert-danger\')]'));
    this.invalidCustomerNameError = element(by.xpath('//div[@class=\'row\']/div[contains(@class,\'alert-danger\')]'));
    this.headerLocator = element(by.xpath('//div[@class=\'modal-header\']//h3'));
    this.componentCalendarLocator = element(by.xpath('//div[@class=\'icon cal_data\']'));
    this.previousMonthArrowLocator = element(by.xpath('//button[@aria-label=\'Previous Month\']'));
    this.futureMonthArrowLocator = element(by.xpath('//button[@aria-label=\'Next Month\']'));
    this.monthButtonLocator = element(by.xpath('//div[@class=\'headermonthtxt\']/button[@class=\'headerlabelbtn monthlabel\']'));
    this.previousYearArrowLocator = element(by.xpath('//button[@aria-label=\'Previous Year\']'));
    this.futureYearArrowLocator = element(by.xpath('//button[@aria-label=\'Next Year\']'));
    this.YearButtonLocator = element(by.xpath('//div[@class=\'headeryeartxt\']/button[@class=\'headerlabelbtn yearlabel\']'));
  }

  public confirmComponentIsAvailable(): CreateEventComponent {
    browser.wait(protractor.ExpectedConditions.visibilityOf(this.componentLocator), 2000, 'The Create Event component did not load');
    return this;
  }

  public isComponentVisible(): Promise<boolean> {
    return this.componentLocator.isDisplayed();
  }

  public enterCustomerName(customerName: string): Promise<any[]> {
    return this.customerNameLocator.clear().sendKeys(customerName);
  }

  public readCustomerName():Promise<string> {
    return this.customerNameLocator.getAttribute('value');
  }
  public readCustomerNameErrorMessage(): Promise<any> {
    return this.customerNameErrorLocator.getText();
  }

  public clearCustomerName(): Promise<void> {
    let _self = this;
    return this.readCustomerName().then(function(text){
      for (let i = 0; i < text.length; i++) {
        _self.customerNameLocator.sendKeys(protractor.Key.BACK_SPACE);
      }
    });
  }

  public enterZipCode(zipCode: string): Promise<any[]> {
    return this.zipCodeLocator.clear().sendKeys(zipCode);
  }

  public readZipCode(): Promise<string> {
    return this.zipCodeLocator.getAttribute('value');
  }

  public clearZipCode(): Promise<void> {
    let _self = this;
    return this.readZipCode().then(function(text){
      for (let i = 0; i < text.length; i++) {
        _self.zipCodeLocator.sendKeys(protractor.Key.BACK_SPACE);
      }
    });
  }

  public readZipCodeErrorMessage(): Promise<any> {
    return this.zipCodeErrorLocator.getText();
  }

  public selectShipmentType(shipmentType: string): Promise<any[]> {
    return this.shipmentTypeLocator.getSelectedOptionValue(shipmentType);
  }

  public enterOrderNumber(orderNumber: string): Promise<any[]> {
    return this.orderNumberLocator.clear().sendKeys(orderNumber);
  }

  public readOrderNumber(): Promise<string> {
    return this.orderNumberLocator.getAttribute('value');
  }

  public readOrderNumberErrorMessage(): Promise<any> {
    return this.orderNumberErrorLocator.getText();
  }

  public clearOrderNumber(): Promise<void> {
    let _self = this;
    return this.readOrderNumber().then(function(text){
      for (let i = 0; i < text.length; i++) {
        _self.orderNumberLocator.sendKeys(protractor.Key.BACK_SPACE);
      }
    });
  }

  public enterTrackingNumber(trackingNumber: string): Promise<any[]> {
    return this.trackingNumberLocator.clear().sendKeys(trackingNumber);
  }

  public readTrackingNumber(): Promise<string> {
    return this.trackingNumberLocator.getAttribute('value');
  }

  public readTrackingNumberErrorMessage(): Promise<any> {
    return this.trackingNumberErrorLocator.getText();
  }

  public clearTrackingNumber(): Promise<void> {
    let _self = this;
    return this.readTrackingNumber().then(function(text){
      for (let i = 0; i < text.length; i++) {
        _self.trackingNumberLocator.sendKeys(protractor.Key.BACK_SPACE);
      }
    });
  }

  public enterQuoteNumber(quoteNumber: string): Promise<any[]> {
    return this.quoteNumberLocator.clear().sendKeys(quoteNumber);
  }

  public readQuoteNumber(): Promise<string> {
    return this.quoteNumberLocator.getAttribute('value');
  }

  public readQuoteNumberErrorMessage(): Promise<any> {
    return this.quoteNumberErrorLocator.getText();
  }

  public clearQuoteNumber(): Promise<void> {
    let _self = this;
    return this.readQuoteNumber().then(function(text){
      for (let i = 0; i < text.length; i++) {
        _self.quoteNumberLocator.sendKeys(protractor.Key.BACK_SPACE);
      }
    });
  }

  public clickAddEvent(): Promise<any> {
    return this.addEventLocator.click();
  }

  public createEventExists(): Promise<any> {
    return this.customerNameLocator.isDisplayed();
  }

  public selectLocationType(locationType:string): Promise<any> {
    if(locationType === "Origin") {
      return this.originLocationTypeLocator.click();
    }
    else {
      return this.destLocationTypeLocator.click();
    }
  }

  public clickCancelButton(): Promise<any> {
    return this.cancelButtonLocator.click();
  }

  public readComponentHeader(): Promise<string> {
    return this.headerLocator.getText();
  }

  public readDayFromCalendarIcon(): Promise<string> {
    let dayInIconLocator: any = element(by.xpath('//div[@class=\'icon cal_data\']/span'));
    return dayInIconLocator.getText();
  }

  public readCreateEventErrorMessage(): Promise<any> {
    return this.createEventErrorMessage.getText();
  }

  public selectSpecificYear(selectYear: number) : any {
    var that = this;
    var currentYear = this.YearButtonLocator.getText();
    currentYear.then(function (text) {
      let year = Number(text);
      do {
        if (year > selectYear) {
          that.previousYearArrowLocator.click();
          that.selectSpecificYear(selectYear);
        } else if (year < selectYear) {
          that.futureYearArrowLocator.click();
          that.selectSpecificYear(selectYear);
        } else {
          break;
        }
      }while(year == selectYear)
    });
  }

  public specificMonth(selectMonth: number, selectDay:number) : any {
    var that = this;
    var currentMonth = this.monthButtonLocator.getText();
    currentMonth.then(function (text) {
      let month = that.utils.getMonthNumber(text);
      do {
        if (month > selectMonth) {
         that.previousMonthArrowLocator.click();
          that.specificMonth(selectMonth,selectDay);
        } else if (month < selectMonth) {
          that.futureMonthArrowLocator.click();
          that.specificMonth(selectMonth,selectDay);
        } else {
          let randomDate: any;
          randomDate = element(by.xpath('//table[@class=\'caltable\']/tbody/tr/td/div[contains(@class,\'currmonth\')]/span[text()=\''+ selectDay + '\']'));
          randomDate.getText().then(function (value) {
            randomDate.click();
          });
          break;
        }
      }while(month == selectMonth)
    });
  }

  public selectDateFromCreateEventComponent(selectDate: string): any {
      let formattedDate = this.utils.stringToDate(selectDate,"yyyy-mm-dd","-");
      let selectDay = formattedDate.getDate();
      let selectMonth = formattedDate.getMonth()+1;
      let selectYear = formattedDate.getFullYear();

      this.selectSpecificYear(selectYear);
      this.specificMonth(selectMonth,selectDay);
  }

  public clickInlineCalendar(): Promise<void> {
    return this.componentCalendarLocator.click();
  }

}



