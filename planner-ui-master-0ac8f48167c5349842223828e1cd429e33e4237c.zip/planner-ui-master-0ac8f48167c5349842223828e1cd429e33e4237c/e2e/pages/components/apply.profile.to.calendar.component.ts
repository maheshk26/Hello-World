import {browser, by, element, protractor} from 'protractor';
import {Utils} from "../../features/support/utils";

export class ApplyProfileToCalendarComponent {

  private selectDateRangeLocator: any;
  private calendarLocator: any;
  private leftCalendarLocator: any;
  private rightCalendarLocator: any;

  private utils: any;

  constructor() {
    this.utils = new Utils();
    this.selectDateRangeLocator = element(by.xpath('//div/span[contains(@class,\'form-control uneditable-input daterange\')]'));
    this.calendarLocator = element(by.xpath('//div[contains(@class,\'show-calendar\')]'));
    this.leftCalendarLocator = element(by.xpath('//div[@class=\'calendar left\']/div[2]/table/tbody')); //change
    this.rightCalendarLocator = element(by.xpath('//div[@class=\'calendar right\']/div[2]/table/tbody')); //change
  }

  public confirmComponentHasLoaded(): ApplyProfileToCalendarComponent {
    let componentHeader = element(by.xpath('//div[contains(@class,\'modal-header\')]/h3[text()=\'Apply profile to calendar\']'));
     browser.wait(protractor.ExpectedConditions.elementToBeClickable(componentHeader), 3000, 'Apply profile to calendar component is not loaded');
     return this;
  }

  public clickSelectDateRange(): Promise<any> {
    return this.selectDateRangeLocator.click();
  }

  public selectDateRangeFromCurrentDateThroughDays(numberOfDays: number): Promise<void> {
    let calendarComponent = element(by.xpath('//div[contains(@class,\'show-calendar\')]'));
    browser.wait(protractor.ExpectedConditions.elementToBeClickable(calendarComponent),2000,'The calendar component is not visible');
    let currentDateLocator = element(by.xpath('//div[@class=\'calendar left\']//table/tbody/tr//td[contains(@class,\'today\')]'));
    currentDateLocator.click();

    let strDate = this.utils.addDaysAsString(new Date(), numberOfDays);
    let formattedDate = this.utils.reFormatDate(strDate);
    let selectDay = formattedDate.split("-");
    let selectDate = selectDay[0];
    let selectMonth = selectDay[1];

    let endDateLocator = element(by.xpath('//th[contains(text(),\''+selectMonth+'\')]/parent::tr/parent::thead/parent::table/tbody//td[text()=\''+selectDate+'\'][@class=\'available\' or @class=\'weekend available\']'));
    endDateLocator.click();
    let applyButtonLocator = element(by.buttonText('Apply'));
    return applyButtonLocator.click();
  }

  public selectFutureDateRangeFromCalendar(): Promise<void> {
    let calendarComponent = element(by.xpath('//div[contains(@class,\'show-calendar\')]'));
    browser.wait(protractor.ExpectedConditions.elementToBeClickable(calendarComponent),2000,'The calendar component is not visible');

    let rightArrowLocator = element(by.xpath('//div[@class=\'calendar right\']//table/thead/tr/th[@class=\'next available\']'));
    rightArrowLocator.click();
    let startDateLocator = element(by.xpath('//div[@class=\'calendar right\']//tbody/tr/td[text()=\'1\'][@class=\'available\' or @class=\'weekend available\']')).click();
    let endDateLocator = element(by.xpath('//div[@class=\'calendar right\']//tbody/tr/td[text()=\'7\'][@class=\'available\' or @class=\'weekend available\']')).click();
    let applyButtonLocator = element(by.buttonText('Apply'));
    return applyButtonLocator.click();
  }

  public clickApplyToCalendarButton(): Promise<any> {
    let ApplyToCalendarLocator = element(by.buttonText('Apply to calendar'));
    return ApplyToCalendarLocator.click();
  }

  public readErrorMessage(): Promise<any[]> {
    let errorMessageLocator: any = element(by.xpath('//div[contains(@class,\'alert alert-danger\')]'));
    return errorMessageLocator.isPresent().then((isPresent) => {
      if (isPresent) {
        return errorMessageLocator.getText();
      } else {
        let deferred = protractor.promise.defer();
        deferred.fulfill('');
        return deferred.promise;
      }
    });
  }

}
