import {by, element, protractor, browser} from 'protractor';
import {expect} from '../../features/support/asserts.config';
import {Utils} from '../../features/support/utils';
import {AdministrationPage} from '../admin/administration.page';
import {CalendarPage} from '../calendar.page';


export class LeftNavComponent {

  private utils: Utils = new Utils();

  constructor() {}

  public confirmComponentIsAvailable(): LeftNavComponent {
    let componentLocator: any = element(by.xpath('//div[contains(@class,\'nav-frame\') and contains(@style, \'display: block\')]'));
    this.utils.scrollIntoView(componentLocator);
    expect(componentLocator.isDisplayed(), 'Left Nav component is not displayed').to.eventually.be.true;
    return this;
  }

  public clickAdministrationMenuLink() : AdministrationPage {
    const administrationMenuLink: any = element(by.xpath('//li[@class=\'menuLink\']/a/span[text()=\'Administration\']'));
    administrationMenuLink.click();
    return new AdministrationPage().confirmPageHasLoaded();
  }

  public clickCalendarMenuLink() : CalendarPage{
    const calendarMenuLink: any = element(by.xpath('//li[@class=\'menuLink\']/a/span[text()=\'Calendar\']'));

    browser.wait(protractor.ExpectedConditions.elementToBeClickable(calendarMenuLink),
      1000, 'Calendar menu link never became clickable');
    this.utils.scrollIntoView(calendarMenuLink);
    calendarMenuLink.click();

    return new CalendarPage().confirmPageHasLoaded();
  }
}