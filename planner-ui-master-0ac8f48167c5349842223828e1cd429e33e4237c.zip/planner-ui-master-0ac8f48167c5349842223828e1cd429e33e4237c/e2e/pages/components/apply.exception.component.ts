import {browser, by, element, protractor} from 'protractor';

export class ApplyExceptionComponent {

  private newAvailabilityLocator:any;

  constructor() {
    this.newAvailabilityLocator = element(by.xpath('//input[contains(@class,\'eventCount\')]'));
  }

  public confirmComponentHasLoaded(): ApplyExceptionComponent {
    let profileHeaderLocator = element(by.xpath('//div[@class=\'modal-header\']//h3[text()=\'Apply Exception\']'));
    browser.wait(protractor.ExpectedConditions.elementToBeClickable(profileHeaderLocator),3000,'Apply Exception Component has not loaded');
    return this;
  }

  public clickSelectDateLabel(): Promise<any>{
    let selectDateLocator = element(by.xpath('//div/form/div/div[2]/div/span[contains(@class,\'daterange\')]'));
    return selectDateLocator.click();
  }

  public selectSpecificDateFromCalendar(selectDate: string): Promise<void> {
    let calendarComponent = element(by.xpath('//div[contains(@class,\'show-calendar\')]'));
    browser.wait(protractor.ExpectedConditions.elementToBeClickable(calendarComponent),2000,'The calendar component is not visible');

    let formattedDate = new Date(selectDate);
    let date = formattedDate.getDate()+1;
    let dateLocator =
      element(by.xpath('//div[contains(@class,\'calendar left\')]/div[@class=\'calendar-table\']/table/tbody/tr//td[contains(@class,\'available\') and text()=\''+date+'\']'));
    return dateLocator.click();
  }

  public enterNewAvailability(eventSlot : number): Promise<any>{
    return this.newAvailabilityLocator.sendKeys(eventSlot);
  }

  public clickApplyExceptionButton(): Promise<any> {
    let applyExceptionButtonLocator = element(by.buttonText('Apply Exception'));
    return applyExceptionButtonLocator.click();
  }

  public readExceptionValue():Promise<string> {
    return this.newAvailabilityLocator.getAttribute('value');
  }

  public clearExceptionValue(): Promise<void> {
    let _self = this;
    return this.readExceptionValue().then(function(text){
      for (let i = 0; i < text.length; i++) {
        _self.newAvailabilityLocator.sendKeys(protractor.Key.BACK_SPACE);
      }
    });
  }

  public readAppropriateErrorMessage():Promise<string> {
    let ErrorMessageLocator: any = element(by.xpath('//div[contains(@class,\'row\')]/div[contains(@class,\'alert alert-danger\')]'));
    return ErrorMessageLocator.isPresent().then((isPresent) => {
      if (isPresent) {
        return ErrorMessageLocator.getText();
      } else {
        let deferred = protractor.promise.defer();
        deferred.fulfill('');
        return deferred.promise;
      }
    });
  }

  public enterAvailabilityStringValue(number: string):Promise<any> {
    return this.newAvailabilityLocator.sendKeys(number);
  }

}
