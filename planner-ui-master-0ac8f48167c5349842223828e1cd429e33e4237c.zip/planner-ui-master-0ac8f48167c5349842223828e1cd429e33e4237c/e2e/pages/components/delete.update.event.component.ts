import {browser, by, element, protractor} from 'protractor';


export class DeleteUpdateEventComponent {
  private deleteEventLocator: any;
  private cancelEventLocator: any;
  private updateEventLocator: any;

  constructor() {
    this.deleteEventLocator = element(by.buttonText('Delete Event'));
    this.cancelEventLocator = element((by.buttonText('Cancel')));
    this.updateEventLocator = element((by.buttonText('Update Event')));
  }

  public confirmDeleteUpdateComponentIsAvailable(): DeleteUpdateEventComponent {
    let pageHeaderLocator: any = element(by.xpath('//div[contains(@class,\'modal-content\')]'));
    browser.wait(protractor.ExpectedConditions.visibilityOf(pageHeaderLocator), 3000, 'The delete update event component did not load');
    return this;
  }

  public isComponentVisible(): Promise<boolean> {
    return this.updateEventLocator.isPresent();
  }

  public clickDeleteEventButton(): Promise<any[]> {
    return this.deleteEventLocator.click();
  }

  public clickConfirmDeleteButton(): Promise<any[]> {
    let confirmDeleteButtonLocator: any = element(by.partialButtonText('Are you sure'));
    return confirmDeleteButtonLocator.click();
  }

  public clickCancelEventButton(): Promise<any[]> {
    return this.cancelEventLocator.click();
  }

  public clickUpdateEventButton(): Promise<any[]> {
    return this.updateEventLocator.click();
  }

  public isUpdateEventButtonEnabled(): Promise<any[]> {
    return this.updateEventLocator.isEnabled();
  }
}
