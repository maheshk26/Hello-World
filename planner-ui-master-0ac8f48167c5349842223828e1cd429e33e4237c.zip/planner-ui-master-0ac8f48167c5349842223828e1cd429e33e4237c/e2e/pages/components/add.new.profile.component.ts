import {browser, by, element, protractor} from 'protractor';
import {ProfileDetails} from "../../models/profile_details";

export class AddNewProfileComponent {

  private profileNameLocator: any;
  private sunLocator: any;
  private monLocator: any;
  private tueLocator: any;
  private wedLocator: any;
  private thuLocator: any;
  private friLocator: any;
  private satLocator: any;
  private addProfileButtonLocator: any;

  constructor(){
    this.profileNameLocator = element(by.id('profileName'));
    this.sunLocator = element(by.xpath('//input[@id=\'sunday\']'));
    this.monLocator = element(by.xpath('//input[@id=\'monday\']'));
    this.tueLocator = element(by.xpath('//input[@id=\'tuesday\']'));
    this.wedLocator = element(by.xpath('//input[@id=\'wednesday\']'));
    this.thuLocator = element(by.xpath('//input[@id=\'thursday\']'));
    this.friLocator = element(by.xpath('//input[@id=\'friday\']'));
    this.satLocator = element(by.xpath('//input[@id=\'saturday\']'));
    this.addProfileButtonLocator = element(by.buttonText('Add Profile'));

  }

  public confirmComponentHasLoaded(): AddNewProfileComponent {
    let profileHeaderLocator = element(by.xpath('//div[@class=\'modal-header\']//h3[text()=\'Add New Crew Availability Profile\']'));
    browser.wait(protractor.ExpectedConditions.elementToBeClickable(profileHeaderLocator),3000,'Add New Crew Availability Profile component has not loaded');
    return this;
  }

  public enterProfileName(profileName: string): Promise<any> {
    return this.profileNameLocator.clear().sendKeys(profileName);
  }

  public readProfileName(): Promise<string> {
    return this.profileNameLocator.getAttribute('value');
  }

  public readProfileNameErrorMessage(): Promise<string>{
    let profileNameErrorMessageLocator: any = element(by.xpath('//input[@id=\'profileName\']/../div[contains(@class,\'alert alert-danger\')]'));
      return profileNameErrorMessageLocator.isPresent().then((isPresent) => {
        if (isPresent) {
          return profileNameErrorMessageLocator.getText();
        } else {
          let deferred = protractor.promise.defer();
          deferred.fulfill('');
          return deferred.promise;
        }
      });
  }

  public readAppropriateErrorMessage(): Promise<string> {
    let ErrorMessageLocator: any = element(by.xpath('//div[contains(@class,\'row\')]/div[contains(@class,\'alert alert-danger\')]'));
      return ErrorMessageLocator.isPresent().then((isPresent) => {
        if (isPresent) {
          return ErrorMessageLocator.getText();
        } else {
          let deferred = protractor.promise.defer();
          deferred.fulfill('');
          return deferred.promise;
        }
      });
  }

  public clearProfileName(): Promise<void> {
    let _self = this;
    return this.readProfileName().then(function(text){
      for (let i = 0; i < text.length; i++) {
        _self.profileNameLocator.sendKeys(protractor.Key.BACK_SPACE);
      }
    });
  }

  public enterSundaySlotValue(number: number): Promise<any> {
    return this.sunLocator.clear().sendKeys(number);
  }

  public readSundaySlotValue(): Promise<string> {
    return this.sunLocator.getAttribute('value');
  }

  public enterMondaySlotValue(number: number): Promise<any> {
    return this.monLocator.clear().sendKeys(number);
  }

  public readMondaySlotValue(): Promise<string> {
    return this.monLocator.getAttribute('value');
  }

  public enterTuesdaySlotValue(number: number): Promise<any> {
    return this.tueLocator.clear().sendKeys(number);
  }

  public readTuesdaySlotValue(): Promise<string> {
    return this.tueLocator.getAttribute('value');
  }

  public enterWednesdaySlotValue(number: number): Promise<any> {
    return this.wedLocator.clear().sendKeys(number);
  }

  public readWednesdaySlotValue(): Promise<string> {
    return this.wedLocator.getAttribute('value');
  }

  public enterThursdaySlotValue(number: number): Promise<any> {
    return this.thuLocator.clear().sendKeys(number);
  }

  public readThursdaySlotValue(): Promise<string> {
    return this.thuLocator.getAttribute('value');
  }

  public enterFridaySlotValue(number: number): Promise<any> {
    return this.friLocator.clear().sendKeys(number);
  }

  public readFridaySlotValue(): Promise<string> {
    return this.friLocator.getAttribute('value');
  }

  public enterSaturdayValue(number: number): Promise<any> {
    return this.satLocator.clear().sendKeys(number);
  }

  public readSaturdaySlotValue(): Promise<string> {
    return this.satLocator.getAttribute('value');
  }

  public clickAddProfileButton(): Promise<any> {
    return this.addProfileButtonLocator.click();
  }

  public enterThursdaySlotFloatValue(number: string): Promise<any> {
    return this.thuLocator.clear().sendKeys(number);
  }

  public enterFridaySlotStringValue(number: string): Promise<any> {
    return this.friLocator.clear().sendKeys(number);
  }

  public enterSlotsForEachDay(details: ProfileDetails){
    this.enterSundaySlotValue(details.eventsCountOnSunday);
    this.enterMondaySlotValue(details.eventsCountOnMonday);
    this.enterTuesdaySlotValue(details.eventsCountOnTuesday);
    this.enterWednesdaySlotValue(details.eventsCountOnWednesday);
    this.enterThursdaySlotValue(details.eventsCountOnThursday);
    this.enterFridaySlotValue(details.eventsCountOnFriday);
    this.enterSaturdayValue(details.eventsCountOnSaturday);
  }

  public clickCancelBtn(): Promise<void> {
    let cancelBtnLocator: any =
      element(by.xpath('//h3[text()=\'Add New Crew Availability Profile\']/../../..//button[text()=\'Cancel\']'));
    return cancelBtnLocator.click();
  }
}
