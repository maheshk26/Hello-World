import {element, by, browser, protractor} from 'protractor';
import {Utils} from '../../features/support/utils';
import {expect} from '../../features/support/asserts.config';
import {LeftNavComponent} from './left.nav.component';
import {CreateEventComponent} from './create.event.component';
import {CalendarPage} from '../calendar.page';
import {WeekCalendarPage} from '../weekcalendar.page';
import {DayCalendarPage} from '../daycalendar.page';

export class HeaderComponent {

  private utils: Utils = new Utils();
  private centerCalendarDropDownArrowLocator:any;

  private createEventBtnLocator: any;

  constructor() {
    this.centerCalendarDropDownArrowLocator = element(by.xpath('//button[contains (@class, \'ui-corner-all ui-button-icon-only\')]'));
    this.createEventBtnLocator = element(by.xpath('//div[contains(@class,\'createEventButton\')]'));
  }

  public confirmComponentIsAvailable(): HeaderComponent {
    let componentLocator: any = element(by.xpath('//div[@class=\'header\']//img[@alt=\'Crew Service Calendar\']'));
    this.utils.scrollIntoView(componentLocator);
    expect(componentLocator.isDisplayed(), 'Header component is not displayed').to.eventually.be.true;
    return this;
  }

  public getLeftNavComponent(): LeftNavComponent {
    let expandedLeftNavLocator: any = element(by.xpath('//div[contains(@class,\'nav-frame\') and contains(@style, \'display: block\')]'));

    expandedLeftNavLocator.isPresent().then((isPresent) => {
      if (!isPresent) {
        this.clickMenuToggle().then(function() {
          browser.wait(protractor.ExpectedConditions.visibilityOf(expandedLeftNavLocator),
            1000, 'Left Nav menu could not be expanded');
        });
      }
    });

    return new LeftNavComponent().confirmComponentIsAvailable();
  }

  public clickMenuToggle(): Promise<any[]> {
    let leftNavExpanderBtnLocator: any =
      element(by.xpath('//div[@class=\'pull-left\']/span[@class=\'hamburgerNav\']/i[contains(@class,\'fa-bars\')]'));
    this.utils.scrollIntoView(leftNavExpanderBtnLocator);
    return leftNavExpanderBtnLocator.click();
  }

  public isCenterSelectorPresent(): Promise<boolean> {
    return this.centerCalendarDropDownArrowLocator.isPresent();
  }

  public selectCenter(center: String): Promise<any> {
    const selectDropDownFromCenterCalendarPrefix: string = '//*[contains(@class, \'ui-autocomplete ui-widget\')]//li//div[contains(.,\'';
    let selectDropDownFromCenterCalendarLocator = element(by.xpath(selectDropDownFromCenterCalendarPrefix + center + '\')]'));

    return this.centerCalendarDropDownArrowLocator.click().then(() => {
      return selectDropDownFromCenterCalendarLocator.click();
    });
  }

  public readCenter(): Promise<string> {
    let calendarNameLocator: any = element(by.xpath('//p-autocomplete//input[@placeholder=\'Select a location\']'));
    return calendarNameLocator.getAttribute('value');
  }

  public readNumberOfCentersInSelector(): Promise<number> {
    let locationLocator: any =
      element.all(by.xpath('//*[contains(@class, \'ui-autocomplete ui-widget\')]//li//div[contains(@class, \'list-item\')]'));
    return this.centerCalendarDropDownArrowLocator.click().then(() => {
      return locationLocator.count();
    });
  }

  public isLocationPresentInCenterSelector(locationName: string): Promise<string> {
    let locationLocator: any =
      element(by.xpath('//*[contains(@class, \'ui-autocomplete ui-widget\')]//li//div[contains(@class, \'list-item\') and contains(., \''
        + locationName + '\')]'));

    return this.centerCalendarDropDownArrowLocator.click().then(() => {
      return locationLocator.isPresent();
    });
  }

  public readCurrentCalendarDate(): Promise<string> {
    let monthHeaderLocator: any = element(by.xpath('//div[contains(@class,\'fc-left\')]/h2'));
    return monthHeaderLocator.getText();
  }

  public clickMonthButton(): CalendarPage {
    let monthBtnLocator: any = element(by.buttonText('month'));
    monthBtnLocator.click();
    return new CalendarPage().confirmPageHasLoaded();
  }

  public clickWeekButton(): WeekCalendarPage {
    let weekBtnLocator: any = element(by.buttonText('week'));
    weekBtnLocator.click();
    return new WeekCalendarPage().confirmPageHasLoaded();
  }

  public clickDayButton(): DayCalendarPage {
    let dayBtnLocator: any = element(by.buttonText('day'));
    dayBtnLocator.click();
    return new DayCalendarPage().confirmPageHasLoaded();
  }

  public clickLeftArrow(): Promise<any> {
    let leftArrowLocator: any = element(by.xpath('//button[contains(@class,\'fc-prev-button\')]'));
    return leftArrowLocator.click();
  }

  public clickTodayButton(): Promise<any> {
    let todayBtnLocator: any = element(by.buttonText('today'));
    return todayBtnLocator.click();
  }

  public clickRightArrow(): Promise<any> {
    let rightArrowLocator: any = element(by.xpath('//button[contains(@class,\'fc-next-button\')]'));
    return rightArrowLocator.click();
  }

  public isCreateEventBtnPresent(): Promise<boolean> {
    return this.createEventBtnLocator.isPresent();
  }

  public clickCreateEventButton(): CreateEventComponent {
    this.createEventBtnLocator.click();
    return new CreateEventComponent().confirmComponentIsAvailable();
  }

  public selectSpecificYear(selectYear: number) : any {
    this.readCurrentCalendarDate().then((text) => {
      let actualYear: string[] = text.toString().split(" ");
      let year = Number(actualYear[1]);
      do {
        if (year > selectYear) {
          this.clickLeftArrow();
          this.selectSpecificYear(selectYear);
        } else if (year < selectYear) {
          this.clickRightArrow();
          this.selectSpecificYear(selectYear);
        } else {
          break;
        }
      } while(year == selectYear)
    });
  }

  public specificMonth(selectMonth: number) : any {
    this.readCurrentCalendarDate().then((text) => {
      let dateArray: string[] = text.toString().split(" ");
      let monthName = dateArray[0];
      let month = this.utils.getMonthNumber(monthName);
      do {
        if (month > selectMonth) {
          this.clickLeftArrow();
          this.specificMonth(selectMonth);
        } else if (month < selectMonth) {
          this.clickRightArrow();
          this.specificMonth(selectMonth);
        } else {
          break;
        }
      }while(month == selectMonth)

    });
  }

  public selectDateFromCalendar(selectDate: string): any {
    let formattedDate = new Date(selectDate);
    let selectDay = formattedDate.getDate();
    let selectMonth = formattedDate.getMonth()+1;
    let selectYear = formattedDate.getFullYear();
    this.selectSpecificYear(selectYear);
    this.specificMonth(selectMonth);
  }

  public selectSpecificYearAndMonth(selectDate: string): any {
    let strDate = selectDate.split("-");
    let selectMonth = parseInt(strDate[1]);
    let selectYear = parseInt(strDate[0]);
    this.selectSpecificYear(selectYear);
    this.specificMonth(selectMonth);
  }
}
