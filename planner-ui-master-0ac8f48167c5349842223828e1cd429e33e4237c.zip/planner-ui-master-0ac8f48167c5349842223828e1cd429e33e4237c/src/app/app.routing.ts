import {RouterModule, Routes} from '@angular/router';

const routes: Routes = [
  {path: '', redirectTo: '/login', pathMatch: 'full'},
  {path: 'app', loadChildren: './container/container.module#ContainerModule'}
];

export const routing = RouterModule.forRoot(routes);
