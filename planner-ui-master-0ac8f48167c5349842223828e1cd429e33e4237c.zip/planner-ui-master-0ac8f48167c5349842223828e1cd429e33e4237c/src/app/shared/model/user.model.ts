export class User {
  username: string;
  userId: string;
  centerId: string;
  hqUser: boolean;
}
