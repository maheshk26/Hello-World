import {TestBed} from '@angular/core/testing';
import {Router} from '@angular/router';
import {UserService} from './user.service';
import {RouterTestingModule} from '@angular/router/testing';
import {AuthGuard} from './auth-gaurd.service';

describe('Service: Auth Guard Service', () => {

  let guard: AuthGuard;
  let userService: MockUserService;
  let router: Router;

  beforeEach(() => {

    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        AuthGuard,
        {provide: UserService, useClass: MockUserService}
      ]
    });

    guard = TestBed.get(AuthGuard);
    userService = TestBed.get(UserService);
    router = TestBed.get(Router);
  });

  it('should return when user service returns true ', () => {
    userService.state = true;
    expect(guard.checkLogin('')).toEqual(true);
  });

  it('should redirect to login when user service returns false ', () => {
    userService.state = false;
    spyOn(router, 'navigateByUrl');
    guard.checkLogin('/welcome');
    expect(router.navigateByUrl).toHaveBeenCalledWith('/login');
  });

  it('should return true when userService staff is true ', () => {
    userService.state = true;
    expect(guard.canActivate(<any>{}, <any>{})).toBe(true);
  });

});

class MockUserService {
  state: boolean;

  isLoggedIn() {
    return this.state;
  }
}
