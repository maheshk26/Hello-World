import {TestBed, inject} from '@angular/core/testing';
import {UserService} from './user.service';
import {User} from '../model/user.model';
describe('Service: UserService', () => {

  let service;
  beforeEach(() => TestBed.configureTestingModule(
    {
      providers: [
        UserService
      ]
    }
  ));

  beforeEach(inject([UserService], (_service) => {
    service = _service;
  }));

  it('should be available', () => {
    expect(service).toBeTruthy();
  });

  it('should return false when loggedIn is called initially', () => {
    sessionStorage.removeItem('user');
    expect(service.isLoggedIn()).toBeFalsy();
  });

  it('should return true when loggedIn is called after setting user', () => {
    service.loginHandler(TestDataBuilder.getUser());
    expect(service.isLoggedIn()).toBeTruthy();
    sessionStorage.removeItem('user');
  });

  it('should return true if user is hq user', () => {
    const user = TestDataBuilder.getUser();
    service.loginHandler(user);
    expect(service.isHqUser()).toBeFalsy();
    user.hqUser = true;
    service.loginHandler(user);
    expect(service.isHqUser()).toBeTruthy();
    sessionStorage.removeItem('user');
  });

  it('should return null when getCenterId is called initially', () => {
    sessionStorage.removeItem('user');
    expect(service.getCenterId()).toBeNull();
  });

  it('should return centerId when getCenterId is called after setting user', () => {
    service.loginHandler(TestDataBuilder.getUser());
    expect(service.getCenterId()).toBe('123');
    sessionStorage.removeItem('user');
  });

});

class TestDataBuilder {

  static getUser() {
    const user = new User();
    user.username = 'test';
    user.centerId = '123';
    return user;
  }
}
