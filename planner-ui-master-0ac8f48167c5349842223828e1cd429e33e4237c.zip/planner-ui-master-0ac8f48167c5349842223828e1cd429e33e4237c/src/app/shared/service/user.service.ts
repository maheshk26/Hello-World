import {Injectable} from '@angular/core';
import {User} from '../model/user.model';

@Injectable()
export class UserService {

  private user: User = null;

  public isLoggedIn(): boolean {
    let loggedIn = this.user !== null;
    if (loggedIn === false) {
      this.user = JSON.parse(sessionStorage.getItem('user'));
      if (this.user) {
        loggedIn = true;
      }
    }
    return loggedIn;
  }

  public isHqUser(): boolean {
    if (this.user.hqUser) {
      return true;
    }
    return false;
  }

  public getCenterId(): string {
    if (this.user) {
      return this.user.centerId;
    } else {
      return null;
    }
  }

  public loginHandler(user: User) {
    this.user = user;
    sessionStorage.setItem('user', JSON.stringify(user));
  }

}
