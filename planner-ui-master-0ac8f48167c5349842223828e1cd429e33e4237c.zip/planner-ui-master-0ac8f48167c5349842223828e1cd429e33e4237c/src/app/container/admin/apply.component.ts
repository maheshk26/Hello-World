import {Component, EventEmitter, Output, ViewChild} from '@angular/core';
import {ModalComponent} from 'ng2-bs3-modal/ng2-bs3-modal';
import {AdminService} from './shared/admin.service';
import {Profile} from './shared/model/profile.model';
import {DaterangePickerComponent} from 'ng2-daterangepicker';
import {Schedule} from './shared/model/schedule.model';
import {FormBuilder, FormGroup} from '@angular/forms';
declare var moment: any;

@Component({
  selector: 'app-apply',
  templateUrl: 'apply.component.html',
  styleUrls: ['apply.component.scss']
})
export class ApplyComponent {

  @ViewChild(ModalComponent)
  private modalComponent: ModalComponent;

  @ViewChild(DaterangePickerComponent)
  private picker: DaterangePickerComponent;

  @Output()
  change: EventEmitter<string> = new EventEmitter<string>();

  message: string;
  daterange: any = {};
  profile: Profile;
  schedule: Schedule;
  mode: string;

  options: any = {
    locale: {format: 'YYYY-MM-DD'},
    alwaysShowCalendars: false
  };

  singleDateOptions: any = {
    locale: {format: 'YYYY-MM-DD'},
    alwaysShowCalendars: false,
    singleDatePicker: true,
    showDropdowns: true
  };

  exceptionDate: any;
  slots: string;
  exceptionForm: FormGroup;

  constructor(private fb: FormBuilder,
              private adminService: AdminService) {
  }

  selectedDate(value: any) {
    this.daterange.start = value.start;
    this.daterange.end = value.end;
  }

  singleSelect(value: any) {
    this.exceptionDate = value.start;
  }

  openApplyModal(profile: Profile) {
    this.mode = 'apply';
    this.profile = profile;
    this.modalComponent.open('lg');
    this.clearModal();
    this.resetDateRange();
  }

  openExceptionModal(schedule: Schedule) {
    this.applyRangeToExceptionCalendar(schedule);
    this.exceptionDate = schedule.fromDate;
    this.mode = 'exception';
    this.schedule = schedule;
    this.clearModal();
    this.exceptionForm = this.fb.group({
      'eventCount': ''
    });
    this.modalComponent.open('lg');
  }

  applyRangeToExceptionCalendar(schedule: Schedule) {
    this.singleDateOptions.minDate = moment(schedule.fromDate, 'YYYY-MM-DD');
    this.singleDateOptions.maxDate = moment(schedule.toDate, 'YYYY-MM-DD');
    this.singleDateOptions.startDate = moment(schedule.fromDate, 'YYYY-MM-DD');
    this.singleDateOptions.endDate = moment(schedule.fromDate, 'YYYY-MM-DD');
    if (this.picker) {
      this.picker.datePicker.minDate = moment(schedule.fromDate, 'YYYY-MM-DD');
      this.picker.datePicker.maxDate = moment(schedule.toDate, 'YYYY-MM-DD');
      this.picker.datePicker.startDate = moment(schedule.fromDate, 'YYYY-MM-DD');
      this.picker.datePicker.endDate = moment(schedule.fromDate, 'YYYY-MM-DD');
    }
  }

  clearModal() {
    this.slots = null;
    this.message = null;
    this.daterange = {};
  }

  resetDateRange() {
    if (this.picker) {
      this.picker.datePicker.setStartDate(moment().format('YYYY-MM-DD'));
      this.picker.datePicker.setEndDate(moment().format('YYYY-MM-DD'));
    }
  }

  applyToCalendar() {
    this.adminService
      .createSchedule(this.profile.id,
        this.formatDate(this.daterange.start),
        this.formatDate(this.daterange.end))
      .subscribe((r) => {
        this.clearModal();
        this.modalComponent.dismiss();
        this.change.emit('profile-applied');
      }, (error) => {
        this.message = error.json().message;
      });
  }

  applyException() {
    if (this.message || !this.slots || this.slots.trim() === '') {
      return;
    }
    this.adminService
      .createScheduleException(this.schedule.id,
        this.formatDate(this.exceptionDate),
        this.slots).subscribe((r) => {
      this.clearModal();
      this.modalComponent.dismiss();
      this.change.emit('exception-applied');
    }, (error) => {
      this.message = error.json().message;
    });

  }

  slotChange(event) {
    this.message = null;
    const value = event.target.value;
    if (value.trim() === '') {
      this.slots = '';
      this.message = 'Availability cannot be blank';
      return;
    }
    const error = this.adminService.slotAvailabilityValidation(value);
    if (error) {
      this.message = error;
    } else {
      this.slots = value.trim();
    }

  }

  formatDate(date: Date): string {
    return moment(date).format('DD-MMM-YYYY');
  }

  openDeleteAppliedProfileModal(schedule: Schedule) {
    this.mode = 'delete';
    this.schedule = schedule;
    this.modalComponent.open('lg');
    this.clearModal();
  }

  deleteAppliedProfile() {
    this.adminService.deleteProfile(this.schedule.id)
      .subscribe((response) => {
        this.change.emit('schedule-deleted');
        this.modalComponent.dismiss();
      }, (error) => {
        this.message = error.json().message;
      });
  }

}
