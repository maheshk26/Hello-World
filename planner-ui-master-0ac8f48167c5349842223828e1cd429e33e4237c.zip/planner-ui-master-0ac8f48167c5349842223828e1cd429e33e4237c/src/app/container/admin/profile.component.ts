import {Component, EventEmitter, OnInit, Output, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {ModalComponent} from 'ng2-bs3-modal/components/modal';
import {AdminService} from './shared/admin.service';
import {Profile} from './shared/model/profile.model';
import 'rxjs/add/operator/debounceTime';
import {isNumeric} from 'rxjs/util/isNumeric';

@Component({
  selector: 'app-profile',
  templateUrl: 'profile.component.html',
  styleUrls: ['profile.component.scss']
})
export class ProfileComponent implements OnInit {

  @ViewChild(ModalComponent)
  private modalComponent: ModalComponent;

  @Output()
  change: EventEmitter<string> = new EventEmitter<string>();

  profileForm: FormGroup;
  message: string;

  formControls = {
    'profileName': '',
    'sunday': '0',
    'monday': '0',
    'tuesday': '0',
    'wednesday': '0',
    'thursday': '0',
    'friday': '0',
    'saturday': '0'
  };

  formErrors = {
    'profileName': ''
  };
  validationMessages = {
    'profileName': {
      'required': 'Profile name is required.',
      'maxlength': 'Profile name cannot be more than 25 characters long.'
    }
  };

  constructor(private fb: FormBuilder,
              private adminService: AdminService) {
  }

  ngOnInit() {
    this.profileForm = this.fb.group(this.formControls);
    this.profileForm.get('profileName').setValidators([Validators.required, Validators.maxLength(25)]);
    this.registerForChanges();
  }

  openProfileModal() {
    this.modalComponent.open('lg');
    this.clearModal();
  }

  clearModal() {
    this.message = null;
    this.profileForm.reset(this.formControls);
  }

  onSubmit() {
    const profile = this.convertToProfileObject(this.profileForm.value);
    this.adminService.createProfile(profile)
      .subscribe((res) => {
        this.clearModal();
        this.modalComponent.dismiss();
        this.change.emit('profile-created');
      }, (error) => {
        this.message = error.json().message;
      });
  }

  convertToProfileObject(value: any): Profile {
    const profile = new Profile();
    profile.profileName = value.profileName;
    profile.eventsCountOnSunday = this.validationOfEventCount(value.sunday);
    profile.eventsCountOnMonday = this.validationOfEventCount(value.monday);
    profile.eventsCountOnTuesday = this.validationOfEventCount(value.tuesday);
    profile.eventsCountOnWednesday = this.validationOfEventCount(value.wednesday);
    profile.eventsCountOnThursday = this.validationOfEventCount(value.thursday);
    profile.eventsCountOnFriday = this.validationOfEventCount(value.friday);
    profile.eventsCountOnSaturday = this.validationOfEventCount(value.saturday);
    return profile;
  }

  validationOfEventCount(value: string): number {
    if (!isNumeric(value) || (value < 0 || value > this.adminService.getMaxAvailability())) {
      return 0;
    }
    return parseInt(value, 10);
  }

  registerForChanges(): void {
    this.profileForm.valueChanges.debounceTime(400).subscribe(data => this.onValueChanged(data));
    this.onValueChanged();
  }

  onValueChanged(data?: any) {
    if (!this.profileForm) {
      return;
    }
    const form = this.profileForm;
    for (const field of Object.keys(this.formErrors)) {
      // clear previous error message (if any)
      this.formErrors[field] = '';
      const control = form.get(field);
      if (control && control.dirty && !control.valid) {
        const messages = this.validationMessages[field];
        for (const key of Object.keys(control.errors)) {
          this.formErrors[field] += messages[key] + ' ';
        }
      }
    }
    this.checkForNumeric();
  }

  checkForNumeric() {
    this.message = null;
    const errorsMap = new Map<string, string>();
    let tempError = '';
    const controls = Object.keys(this.formErrors);
    Object.keys(this.formControls).forEach(day => {
      if (controls.indexOf(day) < 0) {
        let value = this.profileForm.get(day).value;
        if (value === '') {
          value = 0;
        }
        tempError = this.adminService.slotAvailabilityValidation(value);
        if (tempError) {
          errorsMap.set(day, tempError);
        }
      }
    });

    tempError = '';
    errorsMap.forEach((value: string, key: string) => {
      tempError = key + ': ' + value + '';
    });
    this.message = tempError;
  }

}
