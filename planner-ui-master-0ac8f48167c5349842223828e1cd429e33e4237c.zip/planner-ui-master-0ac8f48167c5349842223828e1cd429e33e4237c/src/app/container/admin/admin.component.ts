import {Component, OnDestroy, OnInit, QueryList, ViewChild, ViewChildren} from '@angular/core';
import {ProfileComponent} from './profile.component';
import {AdminData} from './shared/model/admin-data.model';
import {AdminService} from './shared/admin.service';
import {Profile} from './shared/model/profile.model';
import {ApplyComponent} from './apply.component';
import {PopoverDirective} from 'ngx-bootstrap/popover';
import {Schedule} from './shared/model/schedule.model';
import {LocationService} from '../shared/location.service';
import {Center} from '../calendar/shared/model/center.model';
import {UserService} from '../../shared/service/user.service';
import {Market} from '../calendar/shared/model/market.model';
import {Location} from '../calendar/shared/model/location.model';
import {Subscription} from 'rxjs/Subscription';
declare var moment: any;

@Component({
  selector: 'app-admin',
  templateUrl: 'admin.component.html',
  styleUrls: ['admin.component.scss']
})
export class AdminComponent implements OnInit, OnDestroy {

  @ViewChild(ProfileComponent)
  private profileComponent: ProfileComponent;

  @ViewChild(ApplyComponent)
  private applyComponent: ApplyComponent;

  @ViewChildren(PopoverDirective)
  private popOverComponents: QueryList<PopoverDirective>;

  adminData = new AdminData();
  isHQUser = false;
  center: Center;
  centerView = true;
  centerOwner = true;
  currentLocation: Location;
  location$: Subscription;

  constructor(private adminService: AdminService,
              private locationService: LocationService,
              private userService: UserService) {

  }

  ngOnInit() {
    this.isHQUser = this.userService.isHqUser();
    this.updateCurrentLocation(this.locationService.getCurrentLocation());
    this.listenForLocationChanges();
    this.refreshAdminSections();
  }

  ngOnDestroy() {
    if (this.location$) {
      this.location$.unsubscribe();
    }
  }

  listenForLocationChanges() {
    this.location$ = this.locationService.currentLocationSubscribe.subscribe((location) => {
      if (!this.currentLocation || this.currentLocation.id !== location.id) {
        this.updateCurrentLocation(location);
        this.refreshAdminSections();
      }
    });
  }

  updateCurrentLocation(location: Location) {
    this.currentLocation = location;
    if (location) {
      if (location.locationCode === 'M') {
        this.centerView = false;
        this.centerOwner = false;
      } else {
        this.center = location as Center;
        this.centerView = true;
        this.determineCenterOwner(location.id);
      }
    }
  }

  determineCenterOwner(locationId: string) {
    if (this.userService.getCenterId() === locationId) {
      this.centerOwner = true;
    } else {
      this.centerOwner = false;
    }
  }

  refreshAdminSections() {
    if (this.isHQUser && this.currentLocation.locationCode !== 'C') {
      return;
    }
    this.refreshSchedules();
    this.refreshScheduleExceptions();
    this.updateProfileList();

  }

  openProfile() {
    this.profileComponent.openProfileModal();
    this.closeAllPopOvers();
  }

  openApplyToCalendar(profile: Profile) {
    this.applyComponent.openApplyModal(profile);
    this.closeAllPopOvers();
  }

  applyToCalendar(event, profile: Profile) {
    event.preventDefault();
    this.openApplyToCalendar(profile);
  }

  updateProfileList(type?: string) {
    this.adminService.getProfiles().subscribe((profiles) => {
      this.adminData.profiles = profiles;
    });
  }

  updateFromAppliedModal(type?: string) {
    if (type === 'profile-applied') {
      this.refreshSchedules();
    } else if (type === 'exception-applied') {
      this.refreshScheduleExceptions();
    } else if (type === 'schedule-deleted') {
      this.refreshSchedules();
      this.refreshScheduleExceptions();
    } else {
      // nothing to do
    }
  }

  refreshSchedules() {
    this.adminService.getSchedules().subscribe((schedules) => {
      this.adminData.schedules = schedules;
    });
  }

  refreshScheduleExceptions() {
    this.adminService.getScheduleExceptions().subscribe((exceptions) => {
      this.adminData.scheduleExceptions = exceptions;
    });
  }

  formatDate(date: Date): string {
    return moment(date).format('MM/DD/YYYY');
  }

  closeAllPopOvers() {
    this.popOverComponents.forEach(popOver => {
      popOver.hide();
    });
  }

  applyException(event, schedule: Schedule) {
    event.preventDefault();
    this.openExceptionsToSchedule(schedule);
  }

  openExceptionsToSchedule(schedule: Schedule) {
    this.applyComponent.openExceptionModal(schedule);
    this.closeAllPopOvers();
  }

  deleteProfile(event, schedule: Schedule) {
    event.preventDefault();
    this.openDeleteAppliedProfileModal(schedule);
  }

  openDeleteAppliedProfileModal(schedule: Schedule) {
    this.applyComponent.openDeleteAppliedProfileModal(schedule);
    this.closeAllPopOvers();
  }
}
