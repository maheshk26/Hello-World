import {AdminComponent} from './admin.component';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {AdminService} from './shared/admin.service';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {PopoverModule} from 'ngx-bootstrap';
import {Observable} from 'rxjs/Observable';
import {AdminData} from './shared/model/admin-data.model';
import {Profile} from './shared/model/profile.model';
import {Schedule} from './shared/model/schedule.model';
import {ScheduleException} from './shared/model/schedule-exception.model';
import {UserService} from '../../shared/service/user.service';
import {LocationService} from '../shared/location.service';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {Location} from '../calendar/shared/model/location.model';

describe('Component: Admin Component', () => {

  let component: AdminComponent;
  let fixture: ComponentFixture<AdminComponent>;

  beforeEach(async(() => {

    TestBed.configureTestingModule({
        imports: [PopoverModule.forRoot()],
        providers: [
          {provide: AdminService, useClass: MockAdminService},
          {provide: UserService, useClass: MockUserService},
          {provide: LocationService, useClass: MockLocationService}
        ],
        declarations: [AdminComponent],
        schemas: [CUSTOM_ELEMENTS_SCHEMA]
      }
    ).compileComponents();
  }));

  beforeEach(async(() => {
    fixture = TestBed.createComponent(AdminComponent);
    fixture.whenStable().then(() => {
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

  }));

  it('should create', () => {
    expect(component).toBeTruthy();

  });

  it('should format date in MM/dd/yyyy format', () => {
    expect(component.formatDate(new Date('09-09-2017'))).toBe('09/09/2017');

  });

  it('should update admin data profiles when updateProfileList is called', () => {

    const service = fixture.debugElement.injector.get(AdminService);
    const spy = spyOn(service, 'getProfiles').and.returnValue(Observable.of([new Profile()]));
    component.updateProfileList();
    expect(spy).toHaveBeenCalled();
    expect(component.adminData.profiles.length).toBe(1);
  });

  it('should update admin data schedules when updateAppliedProfilesList is called with profile-applied', () => {

    const service = fixture.debugElement.injector.get(AdminService);
    const spy = spyOn(service, 'getSchedules').and.returnValue(Observable.of([new Schedule()]));
    component.updateFromAppliedModal('profile-applied');
    expect(spy).toHaveBeenCalled();
    expect(component.adminData.schedules.length).toBe(1);
  });

  it('should update admin data schedules when updateAppliedProfilesList is called with exception-applied', () => {
    const service = fixture.debugElement.injector.get(AdminService);
    const spy = spyOn(service, 'getScheduleExceptions').and.returnValue(Observable.of([new ScheduleException()]));
    component.updateFromAppliedModal('exception-applied');
    expect(spy).toHaveBeenCalled();
    expect(component.adminData.scheduleExceptions.length).toBe(1);
  });

  it('should call openExceptionsToSchedule when applyException is called', () => {
    const event = new Event('click');
    const spyEvent = spyOn(event, 'preventDefault');
    const spyComp = spyOn(component, 'openExceptionsToSchedule');
    const schedule = TestDataBuilder.getSchedule();
    component.applyException(event, schedule);
    expect(spyEvent).toHaveBeenCalled();
    expect(spyComp).toHaveBeenCalledWith(schedule);
  });

  it('should call openApplyToCalendar when applyToCalendar is called', () => {
    const event = new Event('click');
    const spyEvent = spyOn(event, 'preventDefault');
    const spyComp = spyOn(component, 'openApplyToCalendar');
    const profile = TestDataBuilder.getProfile();
    component.applyToCalendar(event, profile);
    expect(spyEvent).toHaveBeenCalled();
    expect(spyComp).toHaveBeenCalledWith(profile);
  });

  it('should call openDeleteAppliedProfileModal when deleteProfile is called', () => {
    const event = new Event('click');
    const spyEvent = spyOn(event, 'preventDefault');
    const spyComp = spyOn(component, 'openDeleteAppliedProfileModal');
    const schedule = TestDataBuilder.getSchedule();
    component.deleteProfile(event, schedule);
    expect(spyEvent).toHaveBeenCalled();
    expect(spyComp).toHaveBeenCalledWith(schedule);
  });

  it('should create component for hq user', () => {
    const service = fixture.debugElement.injector.get(UserService);
    const spy = spyOn(service, 'isHqUser').and.returnValue(true);
    fixture = TestBed.createComponent(AdminComponent);
    fixture.whenStable().then(() => {
      component = fixture.componentInstance;
      fixture.detectChanges();
      expect(component).toBeTruthy();
    });
  });

  it('should update current location when market', () => {
    const location = TestDataBuilder.getLocationMarket();

    component.updateCurrentLocation(location);
    expect(component.centerView).toBeFalsy();
    expect(component.centerOwner).toBeFalsy();
    expect(component.currentLocation).toBe(location);
  });

  it('should update current location when center owner', () => {
    const location = TestDataBuilder.getLocationCenter();
    const service = fixture.debugElement.injector.get(UserService);
    const spy = spyOn(service, 'getCenterId').and.returnValue(location.id);

    component.updateCurrentLocation(location);
    expect(component.centerView).toBeTruthy();
    expect(component.centerOwner).toBeTruthy();
    expect(component.currentLocation).toBe(location);
  });

  it('should update current location when not center owner', () => {
    const location = TestDataBuilder.getLocationCenter();
    const service = fixture.debugElement.injector.get(UserService);
    const spy = spyOn(service, 'getCenterId').and.returnValue('foo');

    component.updateCurrentLocation(location);
    expect(component.centerView).toBeTruthy();
    expect(component.centerOwner).toBeFalsy();
    expect(component.currentLocation).toBe(location);
  });

});

class MockAdminService {

  getProfiles() {
    return Observable.of([]);
  }

  getSchedules() {
    return Observable.of([]);
  }

  getScheduleExceptions() {
    return Observable.of([]);
  }

}

class MockUserService {
  isHqUser() {
    return false;
  }

  getCenterId() {
    return '1';
  }
}

class MockLocationService {
  currentLocationSubscribe: BehaviorSubject<Location> = new BehaviorSubject(new Location());

  getCurrentLocation() {
    return new Location();
  }


}

class TestDataBuilder {
  static getAdminData(): AdminData {
    const adminData = new AdminData();
    adminData.schedules = [];
    adminData.profiles = [];
    return adminData;
  }

  static getProfile(): Profile {
    const profile = new Profile();
    profile.id = '1';
    profile.eventsCountOnSunday = 1;
    return profile;
  }

  static getProfiles(): Profile[] {
    return [TestDataBuilder.getProfile()];
  }

  static getSchedule(): Schedule {
    const schedule = new Schedule();
    schedule.id = '1';
    return schedule;
  }

  static getLocationMarket(): Location {
    const location = new Location();
    location.locationCode = 'M';
    return location;
  }

  static getLocationCenter(): Location {
    const location = new Location();
    location.locationCode = 'C';
    location.id = 'center1';
    location.displayName = 'Center 1';
    return location;
  }
}
