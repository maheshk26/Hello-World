import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {Ng2Bs3ModalModule} from 'ng2-bs3-modal/ng2-bs3-modal';
import {AdminService} from './shared/admin.service';
import {ProfileComponent} from './profile.component';
import {ReactiveFormsModule} from '@angular/forms';
import {Profile} from './shared/model/profile.model';
import {Observable} from 'rxjs/Observable';
describe('Component: Profile Component', () => {

  let component: ProfileComponent;
  let fixture: ComponentFixture<ProfileComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [Ng2Bs3ModalModule, ReactiveFormsModule],
      providers: [
        {provide: AdminService, useClass: MockAdminService}
      ],
      declarations: [
        ProfileComponent
      ]
    });
  });

  beforeEach(async(() => {
    fixture = TestBed.createComponent(ProfileComponent);
    fixture.whenStable().then(() => {
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  }));

  it('should create', () => {
    expect(component).toBeTruthy();

  });

  it('should create profile object when convertToProfileObject is called', () => {
    const profile: Profile = component.convertToProfileObject(component.formControls);
    expect(profile.profileName).toBe('');
    expect(profile.eventsCountOnSunday).toBe(0);
    expect(profile.eventsCountOnMonday).toBe(0);
    expect(profile.eventsCountOnTuesday).toBe(0);
    expect(profile.eventsCountOnWednesday).toBe(0);
    expect(profile.eventsCountOnThursday).toBe(0);
    expect(profile.eventsCountOnFriday).toBe(0);
    expect(profile.eventsCountOnSaturday).toBe(0);
  });

  it('should clear all data', () => {
    component.message = 'Some message';
    component.profileForm.patchValue({'profileName' : 'test'});
    expect(component.profileForm.get('profileName').value).toBe('test');
    component.clearModal();
    expect(component.message).toBe(null);
    expect(component.profileForm.get('profileName').value).toBe('');
  });

  it('should call admin service when onSubmit is called', () => {
    const service = fixture.debugElement.injector.get(AdminService);
    const spy = spyOn(service, 'createProfile').and.returnValue(Observable.of(''));
    component.change.subscribe((response) => {
      expect(response).toBe('profile-created');
    });
    component.onSubmit();
    expect(spy).toHaveBeenCalledWith(jasmine.any(Profile));
  });

  it('should return zero or actual value based on condition', () => {
    expect(component.validationOfEventCount('-1')).toBe(0);
    expect(component.validationOfEventCount('0')).toBe(0);
    expect(component.validationOfEventCount('1')).toBe(1);
    expect(component.validationOfEventCount('10')).toBe(10);
    expect(component.validationOfEventCount('50')).toBe(50);
    expect(component.validationOfEventCount('51')).toBe(0);
    expect(component.validationOfEventCount('500')).toBe(0);
    expect(component.validationOfEventCount('text')).toBe(0);
  });

});

class MockAdminService {

  getProfiles() {
  }

  getSchedules() {
  }

  createProfile() {
  }

  slotAvailabilityValidation() {
    return null;
  }

  getMaxAvailability() {
    return 50;
  }

}
