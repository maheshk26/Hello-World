import {NgModule} from '@angular/core';
import {AdminComponent} from './admin.component';
import {ProfileComponent} from './profile.component';
import {Ng2Bs3ModalModule} from 'ng2-bs3-modal/ng2-bs3-modal';
import {SharedModule} from '../../shared/shared.module';
import {AdminService} from './shared/admin.service';
import {PopoverModule} from 'ngx-bootstrap/popover';
import {ApplyComponent} from './apply.component';
import {Daterangepicker} from 'ng2-daterangepicker';

@NgModule({
  imports: [
    SharedModule,
    Ng2Bs3ModalModule,
    PopoverModule.forRoot(),
    Daterangepicker
  ],
  declarations: [
    AdminComponent,
    ProfileComponent,
    ApplyComponent
  ],
  providers: [
    AdminService
  ]
})
export class AdminModule {
}
