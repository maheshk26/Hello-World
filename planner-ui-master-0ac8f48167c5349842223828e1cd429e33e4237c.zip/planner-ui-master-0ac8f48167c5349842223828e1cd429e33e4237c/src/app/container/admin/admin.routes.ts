import {Routes} from '@angular/router';
import {AdminComponent} from './admin.component';

export const adminRoutes: Routes = [
  {
    path: 'administration',
    component: AdminComponent
  }
];
