import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {ApplyComponent} from './apply.component';
import {Ng2Bs3ModalModule} from 'ng2-bs3-modal/ng2-bs3-modal';
import {Daterangepicker} from 'ng2-daterangepicker';
import {AdminService} from './shared/admin.service';
import {Profile} from './shared/model/profile.model';
import {Observable} from 'rxjs/Observable';
import {Schedule} from './shared/model/schedule.model';
import {ReactiveFormsModule} from '@angular/forms';

describe('Component: Apply Component', () => {

  let component: ApplyComponent;
  let fixture: ComponentFixture<ApplyComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [Ng2Bs3ModalModule, Daterangepicker, ReactiveFormsModule],
      providers: [
        {provide: AdminService, useClass: MockAdminService}
      ],
      declarations: [
        ApplyComponent
      ]
    });
  });

  beforeEach(async(() => {
    fixture = TestBed.createComponent(ApplyComponent);
    fixture.whenStable().then(() => {
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  }));

  it('should create', () => {
    expect(component).toBeTruthy();

  });

  it('should apply selected date to date range object', () => {
    const value = {
      'start': 'start',
      'end': 'end'
    };
    component.selectedDate(value);
    expect(component.daterange.start).toBe('start');
    expect(component.daterange.end).toBe('end');
  });

  it('should apply selected date to exceptionDate', () => {
    const value = {
      'start': 'start'
    };
    component.singleSelect(value);
    expect(component.exceptionDate).toBe('start');
  });

  it('should format date in dd-MMM-yyyy format', () => {
    expect(component.formatDate(new Date('09-09-2017'))).toBe('09-Sep-2017');
  });

  it('should call admin service when apply is called', () => {
    component.profile = TestDataBuilder.getProfile();
    component.daterange = TestDataBuilder.getDateRange();
    const service = fixture.debugElement.injector.get(AdminService);
    const spy = spyOn(service, 'createSchedule').and.returnValue(Observable.of(''));
    component.change.subscribe((response) => {
      expect(response).toBe('profile-applied');
    });
    component.applyToCalendar();
    expect(spy).toHaveBeenCalledWith('1', '09-Sep-2017', '09-Sep-2017');
  });

  it('should call admin service when applyException is called', () => {
    component.slots = '4';
    component.schedule = TestDataBuilder.getSchedule();
    component.exceptionDate = '2017-09-09';
    const service = fixture.debugElement.injector.get(AdminService);
    const spy = spyOn(service, 'createScheduleException').and.returnValue(Observable.of(''));
    component.change.subscribe((response) => {
      expect(response).toBe('exception-applied');
    });
    component.applyException();
    expect(spy).toHaveBeenCalledWith('1', '09-Sep-2017', '4');
  });

  it('should clear all data', () => {
    component.message = 'Some message';
    component.daterange = TestDataBuilder.getDateRange();
    component.clearModal();
    expect(component.message).toBe(null);
  });

  it('should set mode and open apply modal', () => {
    const spyClearModal = spyOn(component, 'clearModal');
    const spyReset = spyOn(component, 'resetDateRange');
    const profile = new Profile();
    component.openApplyModal(profile);
    expect(component.mode).toBe('apply');
    expect(component.profile).toBe(profile);
    expect(spyClearModal).toHaveBeenCalled();
    expect(spyReset).toHaveBeenCalled();
  });

  it('should set mode and open apply modal', () => {
    const spyClearModal = spyOn(component, 'clearModal');
    const schedule = new Schedule();
    component.openExceptionModal(schedule);
    expect(component.mode).toBe('exception');
    expect(component.schedule).toBe(schedule);
    expect(spyClearModal).toHaveBeenCalled();
  });

  it('should call admin service when deleteProfile is called', () => {
    component.schedule = TestDataBuilder.getSchedule();
    const service = fixture.debugElement.injector.get(AdminService);
    const spy = spyOn(service, 'deleteProfile').and.returnValue(Observable.of(''));
    component.change.subscribe((response) => {
      expect(response).toBe('schedule-deleted');
    });
    component.deleteAppliedProfile();
    expect(spy).toHaveBeenCalledWith('1');
  });

  it('should set mode and open delete modal', () => {
    const spyClearModal = spyOn(component, 'clearModal');
    const schedule = new Schedule();
    component.openDeleteAppliedProfileModal(schedule);
    expect(component.mode).toBe('delete');
    expect(component.schedule).toBe(schedule);
    expect(spyClearModal).toHaveBeenCalled();
  });

  class MockAdminService {

    createSchedule() {
    }

    createScheduleException() {
    }

    deleteProfile() {

    }

    slotAvailabilityValidation() {
      return null;
    }

  }

  class TestDataBuilder {
    static getDateRange(): any {
      return {
        'start': '2017-09-09',
        'end': '2017-09-09'
      };
    }

    static getProfile() {
      const profile = new Profile();
      profile.id = '1';
      return profile;
    }

    static getSchedule() {
      const schedule = new Schedule();
      schedule.id = '1';
      return schedule;
    }

  }
});
