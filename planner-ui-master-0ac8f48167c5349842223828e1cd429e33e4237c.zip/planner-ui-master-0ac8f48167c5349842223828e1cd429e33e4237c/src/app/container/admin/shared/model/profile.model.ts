export class Profile {
  id: string;
  profileName: string;
  eventsCountOnSunday: number;
  eventsCountOnMonday: number;
  eventsCountOnTuesday: number;
  eventsCountOnWednesday: number;
  eventsCountOnThursday: number;
  eventsCountOnFriday: number;
  eventsCountOnSaturday: number;
}
