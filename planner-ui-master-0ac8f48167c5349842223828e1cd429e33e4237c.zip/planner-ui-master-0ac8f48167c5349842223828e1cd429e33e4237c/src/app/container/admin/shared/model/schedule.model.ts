export class Schedule {
  id: string;
  profileName: string;
  profileId: string;
  fromDate: string;
  toDate: string;
  createTime: string;
}
