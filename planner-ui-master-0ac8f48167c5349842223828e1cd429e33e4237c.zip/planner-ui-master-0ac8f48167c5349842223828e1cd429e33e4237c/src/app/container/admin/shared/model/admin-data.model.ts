import {Profile} from './profile.model';
import {Schedule} from './schedule.model';
import {ScheduleException} from './schedule-exception.model';
export class AdminData {

  profiles: Profile[];
  schedules: Schedule[];
  scheduleExceptions: ScheduleException[];
}
