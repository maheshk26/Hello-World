export class ScheduleException {
  scheduleId: string;
  date: string;
  eventsCount: string;
  updateTime: string;
}
