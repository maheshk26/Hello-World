import {Injectable} from '@angular/core';
import {Http} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import {Profile} from './model/profile.model';
import {Schedule} from './model/schedule.model';
import {ScheduleException} from './model/schedule-exception.model';
import {isNumeric} from 'rxjs/util/isNumeric';

@Injectable()
export class AdminService {

  private maxAvailability = 50;

  constructor(private http: Http) {
  }

  getMaxAvailability(): number {
    return this.maxAvailability;
  }

  createProfile(profile: Profile): Observable<String> {
    return this.http.post('/api/manage/profile/', profile).map(
      (response) => {
        return response.json();
      }
    );
  }

  getProfiles(): Observable<Profile[]> {
    return this.http.get('/api/manage/profiles/', {}).map(
      (response) => {
        return response.json();
      }
    );
  }

  createSchedule(profileId: string, from: string, to: string): Observable<String> {
    return this.http.post('/api/manage/schedule/', null, {
      params: {
        'profileId': profileId,
        'from': from,
        'to': to
      }
    }).map(
      (response) => {
        return '';
      }
    );
  }

  getSchedules(): Observable<Schedule[]> {
    return this.http.get('/api/manage/schedules/', {}).map(
      (response) => {
        return response.json();
      }
    );
  }

  getScheduleExceptions(): Observable<ScheduleException[]> {
    return this.http.get('/api/manage/schedules/exceptions', {}).map(
      (response) => {
        return response.json();
      }
    );
  }

  createScheduleException(scheduleId: string, date: string, events_count: string): Observable<string> {
    return this.http.post('/api/manage/schedules/' + scheduleId + '/exception', null, {
      params: {
        'date': date,
        'events_count': events_count
      }
    }).map(
      (response) => {
        return '';
      }
    );
  }

  slotAvailabilityValidation(value: string): string {
    let message = null;
    if (!isNumeric(value)) {
      message = 'Only numeric values are allowed';
    } else {
      if (value < 0 || value > this.maxAvailability) {
        message = 'Availability should be between 0 and ' + this.getMaxAvailability();
      }
      if (value.toString().indexOf('.') >= 0 || value % 1 !== 0) {
        message = 'Availability cannot be a fraction';
      }
    }
    return message;
  }

  deleteProfile(scheduleId: string): Observable<String> {
    return this.http.delete('/api/manage/schedule/' + scheduleId).map(
      (response) => {
        return '';
      }
    );
  }
}
