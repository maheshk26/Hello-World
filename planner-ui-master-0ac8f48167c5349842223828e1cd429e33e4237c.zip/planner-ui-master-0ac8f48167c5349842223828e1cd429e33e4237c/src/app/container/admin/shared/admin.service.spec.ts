import {async, inject, TestBed} from '@angular/core/testing';
import {AdminService} from './admin.service';
import {HttpModule, RequestMethod, ResponseOptions, XHRBackend} from '@angular/http';
import {MockBackend} from '@angular/http/testing';
import {Observable} from 'rxjs/Observable';
import {Profile} from './model/profile.model';
import {Schedule} from './model/schedule.model';
import {ScheduleException} from './model/schedule-exception.model';
describe('Service: Admin Service', () => {

  let service, mockBackend;

  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpModule],
    providers: [AdminService, {
      provide: XHRBackend, useClass: MockBackend
    }]
  }));

  beforeEach(inject([AdminService, XHRBackend], (_service, _mockBackend) => {
    service = _service;
    mockBackend = _mockBackend;
  }));

  it('should be available', () => {
    expect(service).toBeTruthy();
  });

  it('should return observable when createProfile is called', () => {
    expect(service.createProfile(new Profile())).toEqual(jasmine.any(Observable));
  });

  it('should make expected http calls ', () => {
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Post);
      expect(connection.request.url).toBe('/api/manage/profile/');
      connection.mockRespond(new Response(new ResponseOptions({
        body: JSON.stringify(new Profile()),
        status: 200
      })));
    });

    service.createProfile(new Profile()).subscribe(res => {
    });
  });

  it('should return observable when getProfiles is called', () => {
    expect(service.getProfiles()).toEqual(jasmine.any(Observable));
  });

  it('should make expected http calls ', () => {
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.url).toBe('/api/manage/profiles/');
      connection.mockRespond(new Response(new ResponseOptions({
        body: JSON.stringify(new Profile()),
        status: 200
      })));
    });

    service.getProfiles().subscribe(res => {
    });
  });

  it('should return observable when getSchedules is called', () => {
    expect(service.getSchedules()).toEqual(jasmine.any(Observable));
  });

  it('should make expected http calls ', () => {
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.url).toBe('/api/manage/schedules/');
      connection.mockRespond(new Response(new ResponseOptions({
        body: JSON.stringify(TestDataBuilder.getSchedules()),
        status: 200
      })));
    });

    service.getSchedules().subscribe(res => {
    });
  });

  it('should return observable when createSchedule is called', () => {
    expect(service.createSchedule('', '', '')).toEqual(jasmine.any(Observable));
  });

  it('should make expected http calls ', () => {
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Post);
      expect(connection.request.url).toBe('/api/manage/schedule/?profileId=id&from=f&to=t');
      connection.mockRespond(new Response(new ResponseOptions({
        body: JSON.stringify(new Profile()),
        status: 200
      })));
    });

    service.createSchedule('id', 'f', 't').subscribe(res => {
      expect(res).toBe('');
    });
  });


  it('should return observable when getScheduleExceptions is called', () => {
    expect(service.getScheduleExceptions()).toEqual(jasmine.any(Observable));
  });

  it('should make expected http calls ', async(() => {
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.url).toBe('/api/manage/schedules/exceptions');
      connection.mockRespond(new Response(new ResponseOptions({
        body: JSON.stringify(TestDataBuilder.getScheduleExceptions()),
        status: 200
      })));
    });

    service.getScheduleExceptions().subscribe(res => {
    });
  }));

  it('should return observable when createScheduleException is called', () => {
    expect(service.createScheduleException('', '', '')).toEqual(jasmine.any(Observable));
  });

  it('should make expected http calls ', () => {
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Post);
      expect(connection.request.url).toBe('/api/manage/schedules/id/exception?date=d&events_count=c');
      connection.mockRespond(new Response(new ResponseOptions({
        body: JSON.stringify(new Profile()),
        status: 200
      })));
    });

    service.createScheduleException('id', 'd', 'c').subscribe(res => {
      expect(res).toBe('');
    });
  });

  it('should return max availability', () => {
    expect(service.getMaxAvailability()).toEqual(50);
  });

  it('should return correct error message ', () => {
    expect(service.slotAvailabilityValidation(10)).toBeNull();
    expect(service.slotAvailabilityValidation(0)).toBeNull();
    expect(service.slotAvailabilityValidation(-10)).toBe('Availability should be between 0 and 50');
    expect(service.slotAvailabilityValidation(100)).toBe('Availability should be between 0 and 50');
    expect(service.slotAvailabilityValidation(.10)).toBe('Availability cannot be a fraction');
    expect(service.slotAvailabilityValidation('aa')).toBe('Only numeric values are allowed');
  });

  it('should return observable when deleteProfile is called', () => {
    expect(service.deleteProfile('')).toEqual(jasmine.any(Observable));
  });

  it('should make expected http calls ', () => {
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Delete);
      expect(connection.request.url).toBe('/api/manage/schedule/id');
      connection.mockRespond(new Response(new ResponseOptions({
        body: JSON.stringify(new Profile()),
        status: 200
      })));
    });

    service.deleteProfile('id').subscribe(res => {
      expect(res).toBe('');
    });
  });

});


class TestDataBuilder {

  static getSchedules(): Schedule[] {
    const schedule = new Schedule();
    schedule.id = '1';
    return [schedule];
  }

  static getScheduleExceptions(): ScheduleException[] {
    const scheduleException = new ScheduleException();
    return [scheduleException];
}
}
