import {Http, RequestOptions, XHRBackend} from '@angular/http';
import {PlannerHttp} from './planner-http.service';
import {UserService} from '../../shared/service/user.service';

export function getHttpImplByRole(backend: XHRBackend, options: RequestOptions, userService: UserService): Http {
  if (userService.isHqUser()) {
    return new PlannerHttp(backend, options);
  }
  return new Http(backend, options);
}
