import {Injectable} from '@angular/core';
import {Headers, Http, Request, RequestOptions, RequestOptionsArgs, Response, XHRBackend} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class PlannerHttp extends Http {

  private static CENTER_ID = 'CENTER_ID';
  private centerId = '';

  constructor(backend: XHRBackend, options: RequestOptions) {
    super(backend, options);
  }

  getCenterId(): string {
    return this.centerId;
  }

  setCenterId(centerId: string) {
    this.centerId = centerId;
  }

  request(url: string | Request, options?: RequestOptionsArgs): Observable<Response> {
    if (typeof url === 'string') {
      options = this.requestOptionsHelper(options);
    } else {
      url = this.requestUrlHelper(url);
    }
    return super.request(url, options);
  }

  get(url: string, options?: RequestOptionsArgs): Observable<Response> {
    options = this.requestOptionsHelper(options);
    return super.get(url, options);
  }

  post(url: string, body: any, options?: RequestOptionsArgs): Observable<Response> {
    options = this.requestOptionsHelper(options);
    return super.post(url, body, options);
  }

  put(url: string, body: any, options?: RequestOptionsArgs): Observable<Response> {
    options = this.requestOptionsHelper(options);
    return super.put(url, body, options);
  }

  delete(url: string, options?: RequestOptionsArgs): Observable<Response> {
    options = this.requestOptionsHelper(options);
    return super.delete(url, options);
  }

  patch(url: string, body: any, options?: RequestOptionsArgs): Observable<Response> {
    options = this.requestOptionsHelper(options);
    return super.patch(url, body, options);
  }

  head(url: string, options?: RequestOptionsArgs): Observable<Response> {
    options = this.requestOptionsHelper(options);
    return super.head(url, options);
  }

  options(url: string, options?: RequestOptionsArgs): Observable<Response> {
    options = this.requestOptionsHelper(options);
    return super.options(url, options);
  }

  private requestUrlHelper(url: Request): Request {
    if (!this.centerId) {
      return url;
    }
    if (!url.headers) {
      url.headers = new Headers();
    }
    url.headers.set(PlannerHttp.CENTER_ID, this.centerId);
    return url;
  }

  private requestOptionsHelper(options?: RequestOptionsArgs): RequestOptionsArgs {
    if (!this.centerId) {
      return options;
    }
    if (!options) {
      options = {headers: new Headers()};
    } else if (!options.headers) {
      options.headers = new Headers();
    }
    options.headers.set(PlannerHttp.CENTER_ID, this.centerId);
    return options;
  }
}
