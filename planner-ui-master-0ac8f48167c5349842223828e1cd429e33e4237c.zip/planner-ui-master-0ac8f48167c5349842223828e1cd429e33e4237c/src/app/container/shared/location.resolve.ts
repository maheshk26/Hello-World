import {Injectable} from '@angular/core';
import {ActivatedRouteSnapshot, Resolve} from '@angular/router';
import {LocationService} from './location.service';
import {UserService} from '../../shared/service/user.service';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/zip';

@Injectable()
export class LocationResolve implements Resolve<any> {

  constructor(private locationService: LocationService,
              private userService: UserService) {
  }

  resolve(route: ActivatedRouteSnapshot): Observable<any> {
    if (this.userService.isHqUser()) {
      return Observable.zip(this.locationService.fetchCenters(), this.locationService.fetchMarkets());
    } else {
      return Observable.zip(this.locationService.fetchCentersInSameMarket(this.userService.getCenterId()), this.locationService.fetchMarketForCenter());
    }

  }

}
