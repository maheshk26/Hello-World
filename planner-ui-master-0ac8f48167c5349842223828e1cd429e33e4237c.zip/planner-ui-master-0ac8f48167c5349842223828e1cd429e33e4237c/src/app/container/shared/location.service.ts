import {Injectable} from '@angular/core';
import {Http} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import {Center} from '../calendar/shared/model/center.model';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {PlannerHttp} from './planner-http.service';
import {Market} from '../calendar/shared/model/market.model';
import {Location} from '../calendar/shared/model/location.model';

@Injectable()
export class LocationService {

  private currentLocation: Location;
  private centersMap: Map<string, string>;

  centersSubscribe: BehaviorSubject<Center[]> = new BehaviorSubject([]);
  marketsSubscribe: BehaviorSubject<Market[]> = new BehaviorSubject([]);
  currentLocationSubscribe: BehaviorSubject<Location> = new BehaviorSubject(null);


  constructor(private http: Http) {
  }

  fetchCenters(): Observable<void> {
    return this.http.get('/api/centers').map(
      (response) => {
        const centers: Center[] = response.json();
        this.centersSubscribe.next(centers);
      }
    );
  }

  fetchCentersInSameMarket(centerId: string): Observable<void> {
    return this.http.get('/api/centers').map(
      (response) => {
        const allCenters: Center[] = response.json();
        const myCenter = allCenters.find(center => center.id === centerId);

        // filter centers by market id
        const centersInSameMarket = allCenters.filter(
          center => center.marketId === myCenter.marketId);
        this.centersSubscribe.next(centersInSameMarket);
      }
    );
  }

  fetchMarkets(): Observable<void> {
    return this.http.get('/api/markets').map(
      (response) => {
        const markets: Market[] = response.json();
        this.marketsSubscribe.next(markets);
      }
    );
  }

  fetchMarketForCenter(): Observable<void> {
    return this.http.get('/api/market').map(
      (response) => {
        const market: Market = response.json();
        const markets: Market[] = [];
        markets.push(market);
        this.marketsSubscribe.next(markets);
      }
    );
  }

  getCurrentLocation(): Location {
    return this.currentLocation;
  }

  setCurrentLocation(location: Location) {
    this.currentLocation = location;
    if (this.http instanceof PlannerHttp) {
      this.http.setCenterId(location.id);
    }
    this.currentLocationSubscribe.next(location);
  }

  setCenterDisplayNameMap(centersMap: Map<string, string>) {
    this.centersMap = centersMap;
  }

  getCenterDisplayName(id: string): string {
    if (!this.centersMap) {
      return '';
    }
    return this.centersMap.get(id);
  }

}
