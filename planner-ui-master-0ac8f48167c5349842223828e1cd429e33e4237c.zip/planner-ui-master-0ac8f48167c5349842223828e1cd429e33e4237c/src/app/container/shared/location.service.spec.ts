import {inject, TestBed} from '@angular/core/testing';
import {HttpModule, RequestMethod, ResponseOptions, XHRBackend, Response} from '@angular/http';
import {LocationService} from './location.service';
import {MockBackend} from '@angular/http/testing';
import {Observable} from 'rxjs/Observable';
import {Center} from '../calendar/shared/model/center.model';
import {Market} from '../calendar/shared/model/market.model';

describe('Service: Location Service', () => {
  let service, mockBackend;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpModule],
      providers: [
        LocationService,
        {provide: XHRBackend, useClass: MockBackend}
      ]
    });
  });

  beforeEach(inject([LocationService, XHRBackend], (_service, _mockBackend) => {
    service = _service;
    mockBackend = _mockBackend;
  }));

  it('should be available', () => {
    expect(service).toBeTruthy();
  });

  it('should return observable when fetchCenters is called', () => {
    expect(service.fetchCenters()).toEqual(jasmine.any(Observable));
  });

  it('should return observable when fetchMarkets is called', () => {
    expect(service.fetchMarkets()).toEqual(jasmine.any(Observable));
  });

  it('should return observable when fetchCentersInSameMarket is called', () => {
    expect(service.fetchCentersInSameMarket('123')).toEqual(jasmine.any(Observable));
  });

  it('should return observable when fetchMarketForCenter is called', () => {
    expect(service.fetchMarketForCenter()).toEqual(jasmine.any(Observable));
  });

  it('should return mocked summary response when fetch Centers is called', () => {
    const response = TestDataBuilder.getCenters();
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.url).toBe('/api/centers');
      connection.mockRespond(new Response(new ResponseOptions({
        body: JSON.stringify(response),
        status: 200
      })));
    });

    service.fetchCenters().subscribe();
    expect(service.centersSubscribe.getValue().length).toBe(3);
  });

  it('should return mocked summary response when fetch Markets is called', () => {
    const response = TestDataBuilder.getMarkets();
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.url).toBe('/api/markets');
      connection.mockRespond(new Response(new ResponseOptions({
        body: JSON.stringify(response),
        status: 200
      })));
    });

    service.fetchMarkets().subscribe();
    expect(service.marketsSubscribe.getValue().length).toBe(2);
  });

  it('should return mocked summary response when fetchCentersInSameMarket is called', () => {
    const response = TestDataBuilder.getCenters();
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.url).toBe('/api/centers');
      connection.mockRespond(new Response(new ResponseOptions({
        body: JSON.stringify(response),
        status: 200
      })));
    });

    service.fetchCentersInSameMarket('1').subscribe();
    expect(service.centersSubscribe.getValue()).not.toBeNull();
    expect(service.centersSubscribe.getValue().length).toBe(2);
  });

  it('should return mocked summary response when fetchMarketForCenter is called', () => {
    const response = TestDataBuilder.getMarket();
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.url).toBe('/api/market');
      connection.mockRespond(new Response(new ResponseOptions({
        body: JSON.stringify(response),
        status: 200
      })));
    });

    service.fetchMarketForCenter().subscribe();
  });

  it('should be able to set and get locations', () => {
    const location = TestDataBuilder.getMarket();
    service.setCurrentLocation(location);
    expect(service.getCurrentLocation().id).toBe('1');
  });

  it('should be get location display names', () => {
    const centersMap = new Map();
    centersMap.set('1', 'location');
    service.setCenterDisplayNameMap(centersMap);
    expect(service.getCenterDisplayName('1')).toBe('location');
    expect(service.getCenterDisplayName('2')).toBeFalsy();
    service.setCenterDisplayNameMap(null);
    expect(service.getCenterDisplayName('2')).toBe('');
  });


});

class TestDataBuilder {

  static getCenters(): Center[] {

    const center1 = new Center();
    center1.centerCode = 'CTRSTL01';
    center1.id = '1';
    center1.marketId = '1';

    const center2 = new Center();
    center2.centerCode = 'CTRSTL02';
    center2.id = '2';
    center2.marketId = '1';

    const center3 = new Center();
    center3.centerCode = 'CTRSTL03';
    center3.id = '3';
    center3.marketId = '2';

    return [center1, center2, center3];
  }

  static getCenter(): Center {
    const center = new Center();
    center.centerCode = 'CTRSTL01';
    center.id = '1';
    return center;
  }

  static getMarket(): Market {
    const market = new Market();
    market.marketCode = 'M001';
    market.id = '1';
    return market;
  }

  static getMarkets(): Market[] {

    const market1 = new Market();
    market1.marketCode = 'M001';
    market1.id = '1';

    const market2 = new Market();
    market2.marketCode = 'M002';
    market2.id = '2';

    return [market1, market2];
  }

}


