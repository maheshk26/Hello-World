import {inject, TestBed} from '@angular/core/testing';
import {
  HttpModule, RequestMethod, RequestOptions, RequestOptionsArgs, ResponseOptions,
  XHRBackend
} from '@angular/http';
import {PlannerHttp} from './planner-http.service';
import {MockBackend} from '@angular/http/testing';
describe('Service: Center Service', () => {
  let service, mockBackend;
  const url = 'http://foo.bar';
  const baseResponse = new Response(new ResponseOptions({body: 'base response'}));

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpModule],
      providers: [
        PlannerHttp,
        {provide: XHRBackend, useClass: MockBackend}
      ]
    });
  });

  beforeEach(inject([PlannerHttp, XHRBackend], (_service, _mockBackend) => {
    service = _service;
    mockBackend = _mockBackend;
  }));

  it('should be available', () => {
    expect(service).toBeTruthy();
  });

  it('should be able to set and retrieve center ids', () => {
    service.setCenterId('test');
    expect(service.getCenterId()).toBe('test');
  });

  it('should be able to make get call', () => {
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.url).toBe(url);
      connection.mockRespond(baseResponse);
    });

    service.get(url).subscribe((res: Response) => {
    });
  });

  it('should be able to make post call', () => {
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Post);
      expect(connection.request.url).toBe(url);
      connection.mockRespond(baseResponse);
    });

    service.post(url, {}).subscribe((res: Response) => {
    });
  });

  it('should be able to make put call', () => {
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Put);
      expect(connection.request.url).toBe(url);
      connection.mockRespond(baseResponse);
    });

    service.put(url, {}).subscribe((res: Response) => {
    });
  });

  it('should be able to make delete call', () => {
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Delete);
      expect(connection.request.url).toBe(url);
      connection.mockRespond(baseResponse);
    });

    service.delete(url).subscribe((res: Response) => {
    });
  });

  it('should be able to make patch call', () => {
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Patch);
      expect(connection.request.url).toBe(url);
      connection.mockRespond(baseResponse);
    });

    service.patch(url, {}).subscribe((res: Response) => {
    });
  });

  it('should be able to make head call', () => {
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Head);
      expect(connection.request.url).toBe(url);
      connection.mockRespond(baseResponse);
    });

    service.head(url).subscribe((res: Response) => {
    });
  });

  it('should be able to make options call', () => {
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Options);
      expect(connection.request.url).toBe(url);
      connection.mockRespond(baseResponse);
    });

    service.options(url).subscribe((res: Response) => {
    });
  });

  it('should be able to make get call with options', () => {

    service.setCenterId('center');
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.url).toBe(url);
      expect(connection.request.headers.get('CENTER_ID')).toBe('center');
      connection.mockRespond(baseResponse);
    });

    service.get(url).subscribe((res: Response) => {
    });
  });

  it('should be able to make get call with options', () => {

    service.setCenterId('center');
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.url).toBe('http://foo.bar?puppies=');
      expect(connection.request.headers.get('CENTER_ID')).toBe('center');
      connection.mockRespond(baseResponse);
    });

    service.get(url, new RequestOptions({search: 'puppies'})).
      subscribe((res: Response) => {
    });
  });

});
