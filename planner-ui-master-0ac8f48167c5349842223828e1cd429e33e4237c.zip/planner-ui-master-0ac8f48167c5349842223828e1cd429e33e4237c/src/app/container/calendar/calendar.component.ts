import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {CalendarService} from './shared/calendar.service';
import {EventSummary} from './shared/model/summary.model';
import {CalEvent} from './shared/model/cal-event.model';
import {Schedule} from 'primeng/components/schedule/schedule';
import {EventComponent} from './event.component';
import {Event} from './shared/model/event.model';
import {LocationService} from '../shared/location.service';
import 'rxjs/add/observable/zip';
import {Location} from './shared/model/location.model';
import {UserService} from '../../shared/service/user.service';
import {Subscription} from 'rxjs/Subscription';
import {CalendarUtil} from './shared/calendar.util';

declare var moment: any;

@Component({
  selector: 'app-calendar',
  templateUrl: 'calendar.component.html',
  styleUrls: ['calendar.component.scss']
})

export class CalendarComponent implements OnInit, OnDestroy {

  @ViewChild(Schedule)
  calendarComponent: Schedule;

  @ViewChild(EventComponent)
  eventComponent: EventComponent;

  private currentView: string;
  private currentStart: string;
  private currentEnd: string;

  events = [];
  headerConfig = {
    left: 'title',
    right: 'month,basicWeek,basicDay prev,today,next'
  };

  options = {
    customButtons: {
      createEventButton: {
        text: 'Create Event',
        click: function () {
          this.openEvent(null);
        }
      }
    }
  };

  defaultView = 'month';
  defaultDate = moment();
  currentLocation: Location;
  isHQUser: boolean;
  centerView = true;
  location$: Subscription;

  constructor(private calendarService: CalendarService,
              private locationService: LocationService,
              private userService: UserService) {
  }

  ngOnInit() {

    const view = JSON.parse(sessionStorage.getItem('view'));
    if (view) {
      this.defaultView = view;
    }

    const start = JSON.parse(sessionStorage.getItem('startDate'));
    if (start) {
      this.defaultDate = start;
    }

    this.isHQUser = this.userService.isHqUser();
    this.currentLocation = this.locationService.getCurrentLocation();
    this.listenForLocationChanges();
    this.determineLocationType();
  }

  ngOnDestroy() {
    if (this.location$) {
      this.location$.unsubscribe();
    }
  }

  listenForLocationChanges() {
    this.location$ = this.locationService.currentLocationSubscribe.subscribe((location) => {
      if (!this.currentLocation || this.currentLocation.id !== location.id) {
        this.currentLocation = location;
        this.updateCalender();
        this.determineLocationType();
      }
    });
  }

  determineLocationType() {
    if (this.currentLocation && this.currentLocation.locationCode === 'C') {
      this.centerView = true;
    } else {
      this.centerView = false;
    }
  }

  loadEvents(event) {
    this.currentStart = this.formatDate(event.view.intervalStart);
    const endMinusOne = moment(event.view.intervalEnd).subtract(1, 'days');
    this.currentEnd = this.formatDate(endMinusOne);

    this.currentView = event.view.name;
    this.refreshEventsOnCalendar();
    sessionStorage.setItem('view', JSON.stringify(this.currentView));
    sessionStorage.setItem('startDate', JSON.stringify(event.view.intervalStart));
  }

  refreshEventsOnCalendar() {
    if (this.isHQUser && !this.currentLocation) {
      return;
    }
    if (this.currentView === 'month') {
      this.calendarService
        .getMonthlySummary(this.currentStart, this.currentEnd, this.currentLocation)
        .subscribe((events) => {
          this.events = this.convertSummaryToCalEvents(events);
        });
    } else {
      this.calendarService
        .getEvents(this.currentStart, this.currentEnd, this.currentLocation)
        .subscribe((events) => {
          this.events = this.covertEventsToCalEvents(events);
        });
    }
  }

  convertSummaryToCalEvents(eventSummaryList: EventSummary[]): CalEvent[] {

    const events: CalEvent[] = [];
    eventSummaryList.forEach(eventSummary => {
      if (eventSummary.bookedEvents > 0) {
        const bookedEvent = new CalEvent();
        bookedEvent.date = eventSummary.eventDate;
        bookedEvent.title = this.getMonthlyViewEventDisplayText(eventSummary.bookedEvents, 'booked');
        bookedEvent.status = 'BOOKED';
        bookedEvent.flexCount = eventSummary.bookedFlexEvents;
        this.changeEventStyle(bookedEvent);
        events.push(bookedEvent);
      }

      if (eventSummary.availableEvents > 0) {
        const availableEvent = new CalEvent();
        availableEvent.date = eventSummary.eventDate;
        availableEvent.title = this.getMonthlyViewEventDisplayText(eventSummary.availableEvents, 'available');
        availableEvent.status = 'AVAILABLE';
        this.changeEventStyle(availableEvent);
        events.push(availableEvent);
      }

      if (eventSummary.reservedEvents > 0) {
        const reservedEvent = new CalEvent();
        reservedEvent.date = eventSummary.eventDate;
        reservedEvent.title = this.getMonthlyViewEventDisplayText(eventSummary.reservedEvents, 'reserved');
        reservedEvent.status = 'RESERVED';
        reservedEvent.flexCount = eventSummary.reservedFlexEvents;
        this.changeEventStyle(reservedEvent);
        events.push(reservedEvent);
      }

    });
    return events;
  }

  covertEventsToCalEvents(response: Event[]): CalEvent[] {
    const events: CalEvent[] = [];
    response.forEach(res => {
      const event = new CalEvent();
      if (res.status === 'AVAILABLE') {
        event.title = '- Open slot -';
      } else {
        event.title = res.bookingInformation.customerName;
        event.centerDisplayName = this.centerView ? '' : this.locationService.getCenterDisplayName(res.centerId);
        event.bookingInformation = res.bookingInformation;
      }
      event.date = res.eventDate;
      event.eventType = res.eventType;
      event.status = res.status;
      this.changeEventStyle(event);
      events.push(event);
    });
    return events;
  }

  getMonthlyViewEventDisplayText(prefix: number, suffix: string) {
    return prefix + (prefix === 1 ? ' slot ' : ' slots ') + suffix;
  }

  changeView(view: string) {
    if (view === this.currentView) {
      return;
    }
    this.removeEvents();
    this.calendarComponent.changeView(view);
  }

  changeDate(date: Date) {
    this.calendarComponent.gotoDate(date);
  }

  formatDate(date: Date): string {
    return moment(date).format('DD-MMM-YYYY');
  }

  openEvent(calEvent?: any) {
    this.eventComponent.openEventModal(calEvent);
  }

  previous() {
    this.calendarComponent.prev();
  }

  next() {
    this.calendarComponent.next();
  }

  today() {
    this.calendarComponent.today();
  }

  updateCalender(event?) {
    this.refreshEventsOnCalendar();
  }

  removeEvents() {
    this.events = [];
  }

  handleEventClick(e) {
    if (this.centerView) {
      if (this.isHQUser) {
        this.handleEventClickForHqUser(e);
      } else {
        this.handleEventClickForCenterUser(e);
      }
    } else {
      if ((this.currentView === 'month' || this.currentView === 'basicWeek') &&
        (e.calEvent.status === 'BOOKED' || e.calEvent.status === 'RESERVED')) {
        this.changeDate(e.calEvent.date);
        this.changeView('basicDay');
      }
    }
  }

  handleEventClickForHqUser(e) {
    if (e.calEvent.status === 'AVAILABLE') {
      this.openEvent(e.calEvent);
    } else if (e.calEvent.status === 'BOOKED' || e.calEvent.status === 'RESERVED') {
      if (this.currentView === 'month') {
        this.changeDate(e.calEvent.date);
        this.changeView('basicDay');
      } else {
        this.openEvent(e.calEvent);
      }
    } else {
      // do nothing. Invalid state
    }
  }

  handleEventClickForCenterUser(e) {
    if (e.calEvent.status === 'BOOKED' || e.calEvent.status === 'RESERVED') {
      this.changeDate(e.calEvent.date);
      this.changeView('basicDay');
    } else {
      // do nothing for available status
    }
  }

  changeEventStyle(event) {

    if (event.bookingInformation && this.currentView === 'basicDay') {
      event.className = 'event-no-bckgrd';
    } else if (CalendarUtil.isPastEvent(event.date)) {
      event.className = 'event-past';
    } else {
      if (event.status === 'BOOKED') {
        event.className = 'event-booked';
      } else if (event.status === 'AVAILABLE') {
        event.className = 'event-open';
      } else if (event.status === 'RESERVED') {
        event.className = 'event-reserved';
      }
    }
  }

  modifyEventRender(event, element, currentView) {
    if (event.status === 'BOOKED' ||
      event.status === 'RESERVED') {
      if (currentView.name === 'basicDay') {
        CalendarUtil.basicDayViewRenderer(event, element);
      } else if (currentView.name === 'basicWeek') {
        CalendarUtil.basicWeekViewRenderer(event, element);
      } else if (currentView.name === 'month') {
        CalendarUtil.monthViewRenderer(event, element);
      } else {
        // wrong view
      }
    }
  }

}
