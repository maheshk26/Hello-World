import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {CalendarService} from './shared/calendar.service';
import {CalendarComponent} from './calendar.component';
import {ScheduleModule} from 'primeng/components/schedule/schedule';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import {CalEvent} from './shared/model/cal-event.model';
import {BookingInformation} from './shared/model/booking-info.model';
import {EventSummary} from './shared/model/summary.model';
import {Event} from './shared/model/event.model';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {UserService} from '../../shared/service/user.service';
import {LocationService} from '../shared/location.service';
import {Center} from './shared/model/center.model';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {Location} from './shared/model/location.model';

declare var moment: any;

describe('Component: Calendar Component', () => {

  let component: CalendarComponent;
  let fixture: ComponentFixture<CalendarComponent>;

  beforeEach(async(() => {

    TestBed.configureTestingModule({
        imports: [
          ScheduleModule
        ],
        providers: [
          {provide: CalendarService, useClass: MockCalendarService},
          {provide: UserService, useClass: MockUserService},
          {provide: LocationService, useClass: MockLocationService}
        ],
        declarations: [CalendarComponent],
        schemas: [CUSTOM_ELEMENTS_SCHEMA]
      }
    ).compileComponents();
  }));

  beforeEach(async(() => {
    fixture = TestBed.createComponent(CalendarComponent);
    fixture.whenStable().then(() => {
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

  }));

  it('should create the component', async(() => {
    expect(component).toBeTruthy();
  }));

  it('should change date correctly in the calendar', async(() => {
    component.changeDate(new Date('2-APR-2011'));
    expect(component.calendarComponent.getDate().format('YYYY')).toBe('2011');
  }));

  it('should format date correctly', async(() => {
    expect(component.formatDate(new Date('2-APR-2011'))).toBe('02-Apr-2011');
  }));

  it('should remove all events from calendar', async(() => {
    component.events = ['test', 'test'];
    expect(component.events.length).toBe(2);
    component.removeEvents();
    expect(component.events.length).toBe(0);
  }));

  it('should call calendars prev function', () => {
    const spy = spyOn(component.calendarComponent, 'prev');
    component.previous();
    expect(spy).toHaveBeenCalled();

  });

  it('should call calendars next function', () => {
    const spy = spyOn(component.calendarComponent, 'next');
    component.next();
    expect(spy).toHaveBeenCalled();

  });

  it('should call calendars today function', () => {
    const spy = spyOn(component.calendarComponent, 'today');
    component.today();
    expect(spy).toHaveBeenCalled();
  });

  it('should change event style based on the date', () => {
    const calEvent = TestDataBuilder.getCalEvent();

    component.changeEventStyle(calEvent);
    expect(calEvent.className).toBe('event-past');
  });

  it('should change event style to event open for current date', () => {
    const calEvent = TestDataBuilder.getCalEvent();
    calEvent.date = moment();

    component.changeEventStyle(calEvent);
    expect(calEvent.className).toBe('event-open');
  });

  it('should change event style to event booked for current date with event status booked', () => {
    const calEvent = TestDataBuilder.getCalEvent();
    calEvent.date = moment();
    calEvent.status = 'BOOKED';

    component.changeEventStyle(calEvent);
    expect(calEvent.className).toBe('event-booked');
  });

  it('should convert summary to cal events', () => {
    const calEvents = component.convertSummaryToCalEvents(TestDataBuilder.getEventSummary());
    expect(calEvents.length).toBe(6);
  });

  it('should convert summary to cal events', () => {
    const calEvents = component.covertEventsToCalEvents(TestDataBuilder.getEvents());
    expect(calEvents.length).toBe(2);
  });

  it('should save view and start in session storage', () => {
    sessionStorage.removeItem('view');
    sessionStorage.removeItem('startDate');

    expect(sessionStorage.getItem('view')).toBeNull();
    expect(sessionStorage.getItem('startDate')).toBeNull();
    component.loadEvents(TestDataBuilder.getViewRenderEvent());
    expect(JSON.parse(sessionStorage.getItem('view'))).toBe('month');
    expect(JSON.parse(sessionStorage.getItem('startDate'))).not.toBeNull();
  });

  it('should not change view while loading events if not refreshed', () => {
    const spyRemoveEvents = spyOn(component, 'removeEvents');
    const spyCalendarView = spyOn(component.calendarComponent, 'changeView');

    component.loadEvents(TestDataBuilder.getViewRenderEvent());

    expect(spyRemoveEvents).not.toHaveBeenCalled();
    expect(spyCalendarView).not.toHaveBeenCalled();
  });

  it('should change view with passed parameter', () => {
    const spyRemoveEvents = spyOn(component, 'removeEvents');
    const spyCalendarView = spyOn(component.calendarComponent, 'changeView');
    component.changeView('month');
    expect(spyCalendarView).not.toHaveBeenCalled();
    component.changeView('basicDay');
    expect(spyCalendarView).toHaveBeenCalledWith('basicDay');
    expect(spyRemoveEvents).toHaveBeenCalled();
  });

  it('should refresh view when calender update call is made', () => {
    const spyRefresh = spyOn(component, 'refreshEventsOnCalendar');
    component.updateCalender(null);
    expect(spyRefresh).toHaveBeenCalled();
  });

  it('should call open event for available event on center view of head quarters user', () => {
    const spyOpenEvent = spyOn(component, 'openEvent');
    const event = TestDataBuilder.getClickEvent();
    component.isHQUser = true;
    component.centerView = true;
    component.handleEventClick(event);
    expect(spyOpenEvent).toHaveBeenCalled();
  });

  it('should not call open event for available event on center non-head quarters user', () => {
    const spyOpenEvent = spyOn(component, 'openEvent');
    const event = TestDataBuilder.getClickEvent();
    component.isHQUser = false;
    component.centerView = true;
    component.handleEventClick(event);
    expect(spyOpenEvent).not.toHaveBeenCalled();
  });

  it('should call change date and view for booked event in month view for hq user', () => {
    const spyChangeDate = spyOn(component, 'changeDate');
    const spyChangeView = spyOn(component, 'changeView');
    component.isHQUser = true;
    component.centerView = true;
    let event: any = TestDataBuilder.getClickEvent();
    event.calEvent.status = 'BOOKED';
    component.changeView('month');

    fixture.detectChanges();
    fixture.whenStable().then(() => {
      component.handleEventClick(event);
      expect(spyChangeDate).toHaveBeenCalledTimes(1);
      expect(spyChangeView).toHaveBeenCalledTimes(2);
    });

  });

  it('should call open event for booked event in week view for hq user', () => {
    const spyOpenEvent = spyOn(component, 'openEvent');
    component.isHQUser = true;
    component.centerView = true;
    let event: any = TestDataBuilder.getClickEvent();
    event.calEvent.status = 'BOOKED';
    component.changeView('basicWeek');

    fixture.detectChanges();
    fixture.whenStable().then(() => {
      component.handleEventClick(event);
      expect(spyOpenEvent).toHaveBeenCalled();
    });

  });

  it('should call change date and view for booked event in month view', () => {
    const spyChangeDate = spyOn(component, 'changeDate');
    const spyChangeView = spyOn(component, 'changeView');
    component.isHQUser = false;
    component.centerView = true;
    let event: any = TestDataBuilder.getClickEvent();
    event.calEvent.status = 'BOOKED';
    component.changeView('month');

    fixture.detectChanges();
    fixture.whenStable().then(() => {
      component.handleEventClick(event);
      expect(spyChangeDate).toHaveBeenCalledTimes(1);
      expect(spyChangeView).toHaveBeenCalledTimes(2);
    });

  });

  it('should call change date and view for booked event in week view for market view', () => {
    const spyChangeDate = spyOn(component, 'changeDate');
    const spyChangeView = spyOn(component, 'changeView');
    component.centerView = false;
    let event: any = TestDataBuilder.getClickEvent();
    event.calEvent.status = 'BOOKED';
    component.changeView('basicWeek');

    fixture.detectChanges();
    fixture.whenStable().then(() => {
      component.handleEventClick(event);
      expect(spyChangeDate).toHaveBeenCalledTimes(1);
      expect(spyChangeView).toHaveBeenCalledTimes(2);
    });

  });

  it('should create the component for head quarters user', async(() => {
    const userService = TestBed.get(UserService);
    const locationService = TestBed.get(LocationService);
    spyOn(userService, 'isHqUser').and.returnValue(true);
    fixture = TestBed.createComponent(CalendarComponent);
    fixture.whenStable().then(() => {
      component = fixture.componentInstance;
      fixture.detectChanges();
      expect(component).toBeTruthy();
    });

  }));

  it('should modify the event correctly when date is past', async(() => {
    const element = $('<div>');
    const event = TestDataBuilder.getCalEvent();
    const currentView = {
      name: 'basicDay'
    };
    event.status = 'RESERVED';
    component.modifyEventRender(event, element, currentView);
    expect(element.html()).toContain('panel-heading-past');
    expect(element.html()).toContain('panel-default-past');
    expect(element.html()).toContain('ZIP Code: 63146');
    expect(element.html()).toContain('Shipment Type: CONTAINER');
    expect(element.html()).toContain('Location Type: ORIGIN');
    expect(element.html()).toContain('Order Number: ORD-12345');
    expect(element.html()).toContain('Tracking Number: OPTY-12345');
    expect(element.html()).toContain('Quote Number: Estimate Number');
  }));

  it('should modify the event correctly when date is future and reserved', async(() => {
    const element = $('<div>');
    const event = TestDataBuilder.getCalEvent();
    event.date = '2100-01-01';
    const currentView = {
      name: 'basicDay'
    };
    event.status = 'RESERVED';
    component.modifyEventRender(event, element, currentView);
    expect(element.html()).toContain('panel-heading-reserved');
    expect(element.html()).toContain('panel-default-reserved');

  }));

  it('should modify the event correctly when date is future and booked', async(() => {
    const element = $('<div>');
    const event = TestDataBuilder.getCalEvent();
    event.date = '2100-01-01';
    const currentView = {
      name: 'basicDay'
    };
    event.status = 'BOOKED';
    component.modifyEventRender(event, element, currentView);
    expect(element.html()).toContain('panel-heading-booked');
    expect(element.html()).toContain('panel-default-booked');

  }));

});

class MockCalendarService {
  getMonthlySummary() {
    return Observable.of([]);
  }

  getEvents() {
    return Observable.of([]);
  }
}

class MockUserService {
  isHqUser() {
    return false;
  }
}

class MockLocationService {

  currentLocationSubscribe: BehaviorSubject<Location> = new BehaviorSubject(new Location());

  getCurrentLocation() {
    return new Location();
  }

  getCenterDisplayName() {
    return 'foo';
  }

}

class TestDataBuilder {
  static getCalEvent(): CalEvent {
    const calEvent = new CalEvent();
    calEvent.date = '2017-03-22';
    calEvent.className = 'test_class_name';
    calEvent.status = 'AVAILABLE';
    calEvent.eventType = 'CONTAINER';
    calEvent.bookingInformation = TestDataBuilder.getBookingInfo();
    return calEvent;
  }

  static getBookingInfo(): BookingInformation {
    const bookingInformation = new BookingInformation();
    bookingInformation.customerName = 'test_customer';
    bookingInformation.opportunityNumber = 'OPTY-12345';
    bookingInformation.orderNumber = 'ORD-12345';
    bookingInformation.locationType = 'ORIGIN';
    bookingInformation.zipCode = '63146';
    bookingInformation.estimateNumber = 'Estimate Number';
    return bookingInformation;
  }

  static getEventSummary(): EventSummary[] {

    const eventSummary1 = new EventSummary();
    eventSummary1.availableEvents = 1;
    eventSummary1.bookedEvents = 1;
    eventSummary1.reservedEvents = 1;
    eventSummary1.eventDate = '2017-01-01';

    const eventSummary2 = new EventSummary();
    eventSummary2.availableEvents = 2;
    eventSummary2.bookedEvents = 2;
    eventSummary2.reservedEvents = 2;
    eventSummary2.eventDate = '2017-01-02';

    return Array.of(eventSummary1, eventSummary2);

  }

  static getEvents(): Event[] {

    const event1 = new Event();
    event1.status = 'AVAILABLE';
    event1.eventType = 'Container';
    event1.eventDate = '2017-01-01';

    const event2 = new Event();
    event2.status = 'BOOKED';
    event2.eventType = 'Container';
    event2.eventDate = '2017-01-02';
    event2.bookingInformation = TestDataBuilder.getBookingInfo();

    return Array.of(event1, event2);

  }

  static getCenters(): Center[] {

    const center1 = new Center();
    center1.centerCode = 'CTRSTL01';
    center1.centerName = 'St. Louis Center 1';

    const center2 = new Center();
    center2.centerCode = 'CTRSTL02';
    center1.centerName = 'St. Louis Center 2';

    return [center1, center2];
  }

  static getClickEvent() {
    const event: any = {};
    event.calEvent = TestDataBuilder.getCalEvent();
    return event;
  }

  static getViewRenderEvent() {
    const view: any = {};
    view.intervalStart = moment.now();
    view.intervalEnd = moment.now();
    view.name = 'month';

    const event: any = {};
    event.view = view;

    return event;
  }
}
