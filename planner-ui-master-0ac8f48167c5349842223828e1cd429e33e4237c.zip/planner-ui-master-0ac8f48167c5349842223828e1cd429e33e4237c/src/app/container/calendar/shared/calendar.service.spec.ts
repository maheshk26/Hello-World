import {TestBed, inject} from '@angular/core/testing';
import {CalendarService} from './calendar.service';
import {HttpModule, XHRBackend, Response, ResponseOptions, RequestMethod} from '@angular/http';
import {MockBackend} from '@angular/http/testing';
import {EventSummary} from './model/summary.model';
import {Observable} from 'rxjs/Observable';
import {Event} from './model/event.model';
import {BookingInformation} from './model/booking-info.model';

describe('Service: Calendar Service', () => {

  let service, mockBackend;

  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpModule],
    providers: [
      CalendarService,
      {provide: XHRBackend, useClass: MockBackend}
    ]
  }));

  beforeEach(inject([CalendarService, XHRBackend], (_service, _mockBackend) => {
    service = _service;
    mockBackend = _mockBackend;
  }));

  it('should be available', () => {
    expect(service).toBeTruthy();
  });

  it('should return observable when getSummary is called', () => {
    expect(service.getMonthlySummary('', '')).toEqual(jasmine.any(Observable));
  });

  it('should return mocked summary response ', () => {
    const response = TestDataBuilder.getSummary();
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.url).toBe('/api/summary?from=from&to=to');
      connection.mockRespond(new Response(new ResponseOptions({
        body: JSON.stringify(response),
        status: 200
      })));
    });

    service.getMonthlySummary('from', 'to').subscribe(summary => {
      expect(summary[0].availableEvents).toBe(1);
      expect(summary[1].availableEvents).toBe(2);
      expect(summary.length).toBe(2);
    });
  });

  it('should return observable when getEvents is called', () => {
    expect(service.getEvents('', '')).toEqual(jasmine.any(Observable));
  });

  it('should return mocked events response ', () => {
    const response = TestDataBuilder.getEvents();
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.url).toBe('/api/events?from=from&to=to');
      connection.mockRespond(new Response(new ResponseOptions({
        body: JSON.stringify(response),
        status: 200
      })));
    });

    service.getEvents('from', 'to').subscribe(events => {
      expect(events[0].status).toBe('AVAILABLE');
      expect(events[1].status).toBe('BOOKED');
      expect(events.length).toBe(2);
    });
  });

  it('should return observable when createBooking is called', () => {
    expect(service.createBooking('', {})).toEqual(jasmine.any(Observable));
  });

  it('should accept a booking and submit a post request when createBooking is called', () => {
    const bookingInfo = TestDataBuilder.getBookingInfo();
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Post);
      expect(connection.request.url).toBe('/api/booking/date');
      expect(connection.request.getBody()).toContain('Test Customer');

      connection.mockRespond(new Response(new ResponseOptions({
        status: 200
      })));
    });

    service.createBooking('date', bookingInfo).subscribe(events => {
    });
  });


  it('should return observable when updateBooking is called', () => {
    expect(service.updateBooking('', '', {})).toEqual(jasmine.any(Observable));
  });

  it('should accept a booking and submit a post request when updateBooking is called', () => {
    const bookingInfo = TestDataBuilder.getBookingInfo();
    bookingInfo.flex = true;
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Post);
      expect(connection.request.url).toBe('/api/booking/id/date');
      expect(connection.request.getBody()).toContain('Test Customer');
      expect(connection.request.getBody()).toContain('"flex": true');

      connection.mockRespond(new Response(new ResponseOptions({
        status: 200
      })));
    });

    service.updateBooking('date', 'id', bookingInfo).subscribe(events => {
    });
  });


  it('should return observable when deleteBooking is called', () => {
    expect(service.deleteBooking('')).toEqual(jasmine.any(Observable));
  });

  it('should accept a booking and submit a post request when deleteBooking is called', () => {
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Delete);
      expect(connection.request.url).toBe('/api/booking/id');

      connection.mockRespond(new Response(new ResponseOptions({
        status: 200
      })));
    });

    service.deleteBooking('id').subscribe(events => {
    });
  });

});

class TestDataBuilder {

  static getSummary() {

    const summary1 = new EventSummary();
    summary1.availableEvents = 1;
    summary1.bookedEvents = 1;
    summary1.eventDate = '1-1-2017';

    const summary2 = new EventSummary();
    summary2.availableEvents = 2;
    summary2.bookedEvents = 2;
    summary2.eventDate = '1-2-2017';

    return [summary1, summary2];
  }

  static getEvents(): Event[] {

    const event1 = new Event();
    event1.centerId = 'abc';
    event1.status = 'AVAILABLE';
    event1.eventDate = '1-1-2017';

    const event2 = new Event();
    event2.centerId = 'abc';
    event2.status = 'BOOKED';
    event2.eventDate = '1-2-2017';

    return [event1, event2];
  }

  static getBookingInfo() {
    const bookingInfo = new BookingInformation();
    bookingInfo.customerName = 'Test Customer';
    return bookingInfo;
  }

}
