import {CalendarUtil} from './calendar.util';
import {CalEvent} from './model/cal-event.model';
import {BookingInformation} from './model/booking-info.model';
describe('Service: Calendar Util', () => {

  it('past event should return false for today', () => {
    expect(CalendarUtil.isPastEvent(new Date())).toBeFalsy();
  });

  it('past event should return true for yesterday', () => {
    expect(CalendarUtil.isPastEvent(new Date(1, 1, 2000))).toBeTruthy();
  });

  it('monthViewRenderer should add flex icons if flex events greater than 0', () => {
    const event: any = {};
    event.flexCount = 5;
    const element = $('<div></div>').append('<span></span>');
    CalendarUtil.monthViewRenderer(event, element);
    expect(element.html()).toContain('fa-arrow-left', 'fa-arrow-right');
  });

  it('monthViewRenderer should not add flex icons if no flex events', () => {
    const event: any = {};
    event.flexCount = 0;
    const element = $('<div></div>').append('<span></span>');
    CalendarUtil.monthViewRenderer(event, element);
    expect(element.html()).toBe('<span></span>');
  });

  it('basicWeekViewRenderer should add flex icons if flex events is true', () => {
    const event: any = {};
    event.bookingInformation = {};
    event.bookingInformation.flex = true;
    const element = $('<div></div>').append('<span></span>');
    CalendarUtil.basicWeekViewRenderer(event, element);
    expect(element.html()).toContain('fa-arrow-left', 'fa-arrow-right');
  });

  it('basicWeekViewRenderer should not add flex icons if no flex events', () => {
    const event: any = {};
    event.bookingInformation = {};
    event.bookingInformation.flex = false;
    const element = $('<div></div>').append('<span></span>');
    CalendarUtil.basicWeekViewRenderer(event, element);
    expect(element.html()).toBe('<span></span>');
  });

  it('basicWeekViewRenderer should add flex icons if flex events is true', () => {
    const event: any = {};
    event.bookingInformation = {};
    event.bookingInformation.flex = true;
    const element = $('<div></div>').append('<span></span>');
    CalendarUtil.basicWeekViewRenderer(event, element);
    expect(element.html()).toContain('fa-arrow-left', 'fa-arrow-right');
  });

  it('basicWeekViewRenderer should not add flex icons if no flex events', () => {
    const event: any = {};
    event.bookingInformation = {};
    event.bookingInformation.flex = false;
    const element = $('<div></div>').append('<span></span>');
    CalendarUtil.basicWeekViewRenderer(event, element);
    expect(element.html()).toBe('<span></span>');
  });

  it('basicDayViewRenderer should add panel for past events', () => {
    const element = $('<div>');
    const event = TestDataBuilder.getCalEvent();
    event.status = 'RESERVED';
    CalendarUtil.basicDayViewRenderer(event, element);
    expect(element.html()).toContain('panel-heading-past');
    expect(element.html()).toContain('panel-default-past');
    expect(element.html()).toContain('ZIP Code: 63146');
    expect(element.html()).toContain('Shipment Type: CONTAINER');
    expect(element.html()).toContain('Location Type: ORIGIN');
    expect(element.html()).toContain('Order Number: ORD-12345');
    expect(element.html()).toContain('Tracking Number: OPTY-12345');
    expect(element.html()).toContain('Quote Number: Estimate Number');
  });

  it('basicDayViewRenderer  should add panel for booked events', () => {
    const element = $('<div>');
    const event = TestDataBuilder.getCalEvent();
    const today = new Date();
    event.date = today.toISOString();
    event.status = 'BOOKED';
    CalendarUtil.basicDayViewRenderer(event, element);
    expect(element.html()).toContain('panel-heading-booked');
    expect(element.html()).toContain('panel-default-booked');
    expect(element.html()).toContain('fa-arrow-left', 'fa-arrow-right');
    expect(element.html()).toContain('01/01/2017');
  });

  it('basicDayViewRenderer should add panel for reserved events', () => {
    const element = $('<div>');
    const event = TestDataBuilder.getCalEvent();
    const today = new Date();
    event.date = today.toISOString();
    event.status = 'RESERVED';
    CalendarUtil.basicDayViewRenderer(event, element);
    expect(element.html()).toContain('panel-heading-reserved');
    expect(element.html()).toContain('panel-default-reserved');
  });

  it('basicDayViewRenderer should add panel by default', () => {
    const element = $('<div>');
    const event = TestDataBuilder.getCalEvent();
    const today = new Date();
    event.date = today.toISOString();
    event.status = 'TEST';
    CalendarUtil.basicDayViewRenderer(event, element);
    expect(element.html()).toContain('panel-heading');
    expect(element.html()).toContain('panel-default');
  });

  it('basicDayViewRenderer should add panel by default', () => {
    const element = $('<div>');
    const event = TestDataBuilder.getCalEvent();
    event.bookingInformation.flex = false;
    const today = new Date();
    event.date = today.toISOString();
    event.status = 'TEST';
    CalendarUtil.basicDayViewRenderer(event, element);
    expect(element.html()).toContain('panel-heading');
    expect(element.html()).toContain('panel-default');
    expect(element.html()).not.toContain('fa-arrow-left', 'fa-arrow-right');
  });

});


class TestDataBuilder {
  static getCalEvent(): CalEvent {
    const calEvent = new CalEvent();
    calEvent.date = '2017-03-22';
    calEvent.className = 'test_class_name';
    calEvent.status = 'AVAILABLE';
    calEvent.eventType = 'CONTAINER';
    calEvent.bookingInformation = TestDataBuilder.getBookingInfo();
    return calEvent;
  }

  static getBookingInfo(): BookingInformation {
    const bookingInformation = new BookingInformation();
    bookingInformation.customerName = 'test_customer';
    bookingInformation.opportunityNumber = 'OPTY-12345';
    bookingInformation.orderNumber = 'ORD-12345';
    bookingInformation.locationType = 'ORIGIN';
    bookingInformation.zipCode = '63146';
    bookingInformation.estimateNumber = 'Estimate Number';
    bookingInformation.flex = true;
    bookingInformation.earlyDate = '2017-01-01';
    return bookingInformation;
  }
}
