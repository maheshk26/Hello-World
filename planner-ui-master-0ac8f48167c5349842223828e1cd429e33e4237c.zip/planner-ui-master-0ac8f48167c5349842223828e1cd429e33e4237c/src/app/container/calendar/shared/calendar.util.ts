declare var moment: any;

export class CalendarUtil {

  static isPastEvent(date): boolean {
    if (moment().diff(date, 'days') > 0) {
      return true;
    }
    return false;
  }

  static convertTimeToString(time: String) {
    if (!time) {
      return '';
    }
    const localExpiryTime = moment(time);
    return localExpiryTime.format('MM/DD/YYYY h:mm A');
  }

  static convertDateToString(time: String) {
    if (!time) {
      return '';
    }
    const localExpiryTime = moment(time);
    return localExpiryTime.format('MM/DD/YYYY');
  }

  static monthViewRenderer(event, element) {
    if (event.flexCount === 0) {
      return;
    }
    let html = element.html();
    html = html.replace('</span>',
      `</span><div class="LKflexDateIcon pull-right">${event.flexCount}
            <span><i class="fa fa-arrow-left" aria-hidden="true"></i><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
            </div>`);
    element.html(html);
  }

  static basicWeekViewRenderer(event, element) {
    if (event.bookingInformation !== undefined && event.bookingInformation.flex) {
      let html = element.html();
      html = html.replace('</span>',
        `</span><div class="LKflexDateIcon pull-right">
            <span><i class="fa fa-arrow-left" aria-hidden="true"></i><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
            </div>`);
      element.html(html);

    }
  }

  static basicDayViewRenderer(event, element) {

    if (event.bookingInformation === undefined) {
      return;
    }
    let panelDefaultClass, headingClass, expiryTime;
    if (CalendarUtil.isPastEvent(event.date)) {
      headingClass = 'panel-heading-past';
      panelDefaultClass = 'panel-default-past';
    } else if (event.status === 'BOOKED') {
      headingClass = 'panel-heading-booked';
      panelDefaultClass = 'panel-default-booked';
    } else if (event.status === 'RESERVED') {
      headingClass = 'panel-heading-reserved';
      panelDefaultClass = 'panel-default-reserved';
      expiryTime = CalendarUtil.convertTimeToString(event.bookingInformation.expiryTime);
    } else {
      headingClass = 'panel-heading';
      panelDefaultClass = 'panel-default';
    }

    element.html(
      `<div>
            <div class="panel ${panelDefaultClass} panel-no-margin">
                <div class="${headingClass}">${event.bookingInformation.customerName}
                <div class="pull-right">${event.centerDisplayName}</div></div>
                <div class="panel-body">
                    <div class="row"> 
                        <div class="col-md-3"><p>Location Type: ${event.bookingInformation.locationType}</p></div>
                        <div class="col-md-3"><p>Tracking Number: ${event.bookingInformation.opportunityNumber}</p></div>
                        <div class="col-md-2"><p>ZIP Code: ${event.bookingInformation.zipCode}</p></div>
                        <div class="col-md-2"><p>Shipment Type: ${event.eventType}</p></div>
                    </div>
                    <div class="row"> 
                        <div class="col-md-3"><p>Order Number: ${event.bookingInformation.orderNumber}</p></div>
                        <div class="col-md-3"><p>Quote Number: ${event.bookingInformation.estimateNumber}</p></div>
                        ${event.bookingInformation.flex ?
        `<div class="col-md-2"><div class="LKflexDateIcon pull-left">
                            <p><span><i class="fa fa-arrow-left" aria-hidden="true"></i>
                            <i class="fa fa-arrow-right" aria-hidden="true"></i>&nbsp;</span></div>
                            <p>${CalendarUtil.convertDateToString(event.bookingInformation.earlyDate)} - 
                                ${CalendarUtil.convertDateToString(event.bookingInformation.lateDate)}</p></div>` : ''}
                        ${expiryTime ? `<div class="col-md-2"><p>Expires: ${expiryTime}</p></div>` : ''}
                    </div>
                </div>
            </div>
        </div>`
    );
  }

}
