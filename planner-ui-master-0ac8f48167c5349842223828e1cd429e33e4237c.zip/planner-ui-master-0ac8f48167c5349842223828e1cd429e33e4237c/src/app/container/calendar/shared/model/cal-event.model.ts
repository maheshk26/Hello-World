import {BookingInformation} from './booking-info.model';
export class CalEvent {
  date: string;
  start: Date;
  end: Date;
  title: string;
  className: string;
  status: string;
  allDay = true;
  eventType: string;
  centerDisplayName: string;
  // For Summaries in month view
  flexCount: number;
  bookingInformation: BookingInformation;
}
