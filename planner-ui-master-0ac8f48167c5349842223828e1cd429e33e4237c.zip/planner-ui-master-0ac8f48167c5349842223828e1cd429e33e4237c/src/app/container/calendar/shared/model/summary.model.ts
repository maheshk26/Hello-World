export class EventSummary {
  eventDate: string;
  availableEvents: number;
  bookedEvents: number;
  reservedEvents: number;
  bookedFlexEvents: number;
  reservedFlexEvents: number;
}
