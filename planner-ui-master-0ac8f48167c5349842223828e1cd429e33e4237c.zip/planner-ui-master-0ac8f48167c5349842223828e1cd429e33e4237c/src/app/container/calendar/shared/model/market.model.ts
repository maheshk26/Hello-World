import {Location} from './location.model';

export class Market extends Location {
  marketName: string;
  marketCode: string;
}
