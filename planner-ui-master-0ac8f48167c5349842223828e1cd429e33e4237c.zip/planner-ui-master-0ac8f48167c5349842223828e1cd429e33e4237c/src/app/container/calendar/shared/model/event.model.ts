import {BookingInformation} from './booking-info.model';
export class Event {
  eventDate: string;
  startTime: string;
  endTime: string;
  status: string;
  centerId: string;
  eventType: string;
  bookingInformation: BookingInformation;
}
