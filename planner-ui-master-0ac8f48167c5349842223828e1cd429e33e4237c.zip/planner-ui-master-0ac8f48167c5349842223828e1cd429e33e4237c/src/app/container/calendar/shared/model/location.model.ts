export class Location {
  id: string;
  displayName: string;
  locationCode: string;
}
