export class BookingInformation {
  id: string;
  zipCode: string;
  customerName: string;
  orderNumber: string;
  opportunityNumber: string;
  estimateNumber: string;
  locationType: string;
  expiryTime: string;
  earlyDate: string;
  lateDate: string;
  flex: boolean;
}
