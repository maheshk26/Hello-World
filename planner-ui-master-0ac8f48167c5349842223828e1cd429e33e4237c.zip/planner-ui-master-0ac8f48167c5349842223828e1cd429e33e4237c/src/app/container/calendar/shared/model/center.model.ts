import {Location} from './location.model';

export class Center extends Location {
  centerName: string;
  centerCode: string;
  marketId: string;
}
