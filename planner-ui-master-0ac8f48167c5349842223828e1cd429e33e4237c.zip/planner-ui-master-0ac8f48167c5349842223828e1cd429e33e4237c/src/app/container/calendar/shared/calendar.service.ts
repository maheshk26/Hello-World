import {Injectable} from '@angular/core';
import {Http, URLSearchParams} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import {Event} from './model/event.model';
import {Location} from './model/location.model';

@Injectable()
export class CalendarService {

  constructor(private http: Http) {

  }

  getMonthlySummary(from: string, to: string, location: Location): Observable<any[]> {

    const params: URLSearchParams = new URLSearchParams();
    params.set('from', from);
    params.set('to', to);
    if (location) {
      params.set('locationId', location.id);
      params.set('locationCode', location.locationCode);
    }
    return this.http.get('/api/summary', {
      search: params
    }).map(
      (response) => {
        return response.json();
      }
    );
  }

  getEvents(from: string, to: string, location: Location): Observable<Event[]> {

    const params: URLSearchParams = new URLSearchParams();
    params.set('from', from);
    params.set('to', to);
    if (location) {
      params.set('locationId', location.id);
      params.set('locationCode', location.locationCode);
    }
    return this.http.get('/api/events', {
      search: params
    }).map(
      (response) => {
        return response.json();
      }
    );
  }

  createBooking(date: string, bookingInfo: any): Observable<any[]> {
    return this.http.post('/api/booking/' + date, bookingInfo).map(
      (response) => {
        return response.json();
      }
    );
  }

  updateBooking(date: string, bookingId: string, bookingInfo: any): Observable<any[]> {
    return this.http.post('/api/booking/' + bookingId + '/' + date, bookingInfo).map(
      (response) => {
        return response.json();
      }
    );
  }

  deleteBooking(id: string): Observable<void> {
    return this.http.delete('/api/booking/' + id).map(
      () => {
        return;
      }
    );
  }

}
