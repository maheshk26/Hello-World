import {Routes} from '@angular/router';
import {CalendarComponent} from './calendar.component';

export const calendarRoutes: Routes = [
  {
    path: 'calendar/:centerId',
    component: CalendarComponent
  },
  {
    path: 'calendar',
    component: CalendarComponent
  }
];
