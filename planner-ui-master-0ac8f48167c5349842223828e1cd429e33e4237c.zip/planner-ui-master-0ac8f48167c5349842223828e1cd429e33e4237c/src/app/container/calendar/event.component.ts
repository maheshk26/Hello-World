import {Component, EventEmitter, OnInit, Output, ViewChild} from '@angular/core';
import {ModalComponent} from 'ng2-bs3-modal/components/modal';
import {IMyDateModel, IMyOptions} from 'mydatepicker';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {CalendarService} from './shared/calendar.service';
import {BookingInformation} from './shared/model/booking-info.model';
declare var moment: any;

@Component({
  selector: 'app-event',
  templateUrl: 'event.component.html',
  styleUrls: ['event.component.scss']
})
export class EventComponent implements OnInit {

  @ViewChild(ModalComponent)
  modalComponent: ModalComponent;

  @Output()
  eventChange: EventEmitter<string>
    = new EventEmitter<string>();

  myDatePickerOptions: IMyOptions = {
    dateFormat: 'dd-M-yyyy',
    inline: true,
    firstDayOfWeek: 'su'
  };

  displayDatePicker = false;
  monthOfTheYear: string;
  dayOfTheWeek: string;
  dayOfTheMonth: number;
  eventForm: FormGroup;
  eventDate: string;
  message: string;
  edit = false;
  delete = false;
  bookingInfo: BookingInformation;
  title: string;
  statusText: string;
  reserved = false;

  formErrors = {
    'customerName': '',
    'orderNumber': '',
    'zipCode': '',
    'opportunityNumber': '',
    'estimateNumber': '',
    'shipmentType': '',
    'locationType': '',
  };
  validationMessages = {
    'customerName': {
      'required': 'Customer name is required.',
      'maxlength': 'Customer name cannot be more than 32 characters long.'
    },
    'orderNumber': {
      'required': 'Order Number is required.',
      'maxlength': 'Order Number cannot be more than 32 characters long.'
    },
    'zipCode': {
      'required': 'Zip Code is required.',
      'maxlength': 'Zip Code cannot be more than 5 digits long.',
      'minlength': 'Zip Code cannot be less than 5 digits long.',
      'pattern': 'Zip Code should only contain digits.'
    },
    'opportunityNumber': {
      'required': 'Tracking Number is required.',
      'maxlength': 'Tracking Number cannot be more than 32 characters long.'
    },
    'estimateNumber': {
      'required': 'Quote Number is required.',
      'maxlength': 'Quote Number cannot be more than 32 characters long.',
    },
    'locationType': {
      'required': 'Location Type is required.'
    },
    'shipmentType': {
      'required': 'Shipment Type is required.'
    }
  };

  constructor(private fb: FormBuilder,
              private calendarService: CalendarService) {
  }

  ngOnInit() {
    this.eventForm = this.fb.group({
      'customerName': ['', [Validators.required, Validators.maxLength(32)]],
      'orderNumber': ['', [Validators.required, Validators.maxLength(32)]],
      'zipCode': ['', [Validators.required, Validators.minLength(5), Validators.maxLength(5), Validators.pattern('[0-9]+')]],
      'opportunityNumber': ['', [Validators.required, Validators.maxLength(32)]],
      'estimateNumber': ['', [Validators.required, Validators.maxLength(32)]],
      'shipmentType': ['Container', [Validators.required]],
      'locationType': ['ORIGIN', [Validators.required]]
    });
    this.registerForChanges();
    this.onDismiss();

  }

  openEventModal(event: any) {
    this.setEventDate(event ? event.date : new Date());
    if (event && event.bookingInformation) {
      this.eventForm.patchValue(event.bookingInformation);
      this.edit = true;
      this.bookingInfo = event.bookingInformation;
      this.title = 'Edit Event';
      this.setStatusBanner(event);
    } else {
      this.eventForm.reset();
      this.prePopulatePulldowns();
      this.edit = false;
      this.bookingInfo = null;
      this.title = 'New Event';
    }
    this.message = null;
    this.modalComponent.open('lg');
    this.delete = false;
  }

  setStatusBanner(event: any) {
    if (event.status === 'BOOKED') {
      this.statusText = 'Booked';
      this.reserved = false;
    } else if (event.status === 'RESERVED') {
      const localExpiryTime = moment(event.bookingInformation.expiryTime);
      this.statusText = 'Reserved - Expires: ' + localExpiryTime.format('dddd, MMMM Do YYYY, h:mm A');
      this.reserved = true;
    }
  }

  setEventDate(date: Date) {
    this.eventDate = moment(date).format('DD-MMM-YYYY');
    this.formatDateForDisplay(date);
  }

  onDateChanged(event: IMyDateModel) {
    this.setEventDate(event.jsdate);
  }

  formatDateForDisplay(date: Date) {
    const momentDate = moment(date);
    this.dayOfTheWeek = momentDate.format('dddd');
    this.monthOfTheYear = moment.months()[momentDate.format('M') - 1].toUpperCase();
    this.dayOfTheMonth = momentDate.format('D');
  }

  toggleCalendar() {
    this.displayDatePicker = !this.displayDatePicker;
  }

  onSubmit() {
    if (!this.edit) {
      this.calendarService.createBooking(this.eventDate, this.eventForm.value)
        .subscribe((event) => {
          this.clearModal();
          this.modalComponent.dismiss();
          this.eventChange.emit('create');
        }, (error) => {
          this.message = error.json().message;
        });
    } else {
      this.calendarService.updateBooking(this.eventDate, this.bookingInfo.id, this.eventForm.value)
        .subscribe((event) => {
          this.clearModal();
          this.modalComponent.dismiss();
          this.eventChange.emit('update');
        }, (error) => {
          this.message = error.json().message;
        });
    }

  }

  onDeleteConfirm() {
    this.calendarService.deleteBooking(this.bookingInfo.id)
      .subscribe(() => {
        this.clearModal();
        this.modalComponent.dismiss();
        this.delete = false;
        this.eventChange.emit('delete');
      }, (error) => {
        this.message = error.json().message;
      });
  }

  onDelete() {
    this.delete = true;
  }

  onDismiss() {
    this.modalComponent.onDismiss.subscribe(() => {
      this.clearModal();
    });
  }

  prePopulatePulldowns() {
    this.eventForm.patchValue({'shipmentType': 'Container', 'locationType': 'ORIGIN'});
  }

  clearModal() {
    this.eventForm.reset();
    this.prePopulatePulldowns();
    this.message = null;
    this.displayDatePicker = false;
  }

  registerForChanges(): void {

    this.eventForm.valueChanges.subscribe(data => this.onValueChanged(data));
    this.onValueChanged();
  }

  onValueChanged(data?: any) {
    if (!this.eventForm) {
      return;
    }
    const form = this.eventForm;
    for (const field of Object.keys(this.formErrors)) {
      // clear previous error message (if any)
      this.formErrors[field] = '';
      const control = form.get(field);
      if (control && control.dirty && !control.valid) {
        const messages = this.validationMessages[field];
        for (const key of Object.keys(control.errors)) {
          this.formErrors[field] += messages[key] + ' ';
        }
      }
    }
  }

}
