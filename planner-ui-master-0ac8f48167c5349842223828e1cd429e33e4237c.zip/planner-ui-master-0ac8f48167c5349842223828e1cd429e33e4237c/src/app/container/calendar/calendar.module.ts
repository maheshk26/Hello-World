import {NgModule} from '@angular/core';
import {CalendarComponent} from './calendar.component';
import {CalendarService} from './shared/calendar.service';
import {ScheduleModule} from 'primeng/components/schedule/schedule';
import {AutoCompleteModule} from 'primeng/components/autocomplete/autocomplete';
import {Ng2Bs3ModalModule} from 'ng2-bs3-modal/ng2-bs3-modal';
import {MyDatePickerModule} from 'mydatepicker';
import {EventComponent} from './event.component';
import {SharedModule} from '../../shared/shared.module';
import {Daterangepicker} from 'ng2-daterangepicker';

@NgModule({
  imports: [
    SharedModule,
    ScheduleModule,
    Ng2Bs3ModalModule,
    MyDatePickerModule,
    Daterangepicker
  ],
  declarations: [
    CalendarComponent,
    EventComponent
  ],
  providers: [
    CalendarService
  ]
})
export class CrewCalendarModule {
}
