import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {MyDatePickerModule} from 'mydatepicker';
import {Ng2Bs3ModalModule} from 'ng2-bs3-modal/ng2-bs3-modal';
import {EventComponent} from './event.component';
import {ReactiveFormsModule} from '@angular/forms';
import {CalendarService} from './shared/calendar.service';
import {Observable} from 'rxjs/Observable';
import {BookingInformation} from './shared/model/booking-info.model';
import {Response, ResponseOptions} from '@angular/http';
import 'rxjs/add/observable/throw';
import {CalEvent} from './shared/model/cal-event.model';
declare var moment: any;
describe('Component: Event Component', () => {

  let component: EventComponent;
  let fixture: ComponentFixture<EventComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [Ng2Bs3ModalModule,
        MyDatePickerModule, ReactiveFormsModule],
      declarations: [EventComponent],
      providers: [
        {provide: CalendarService, useClass: MockCalendarService}
      ]
    });

  });

  beforeEach(async(() => {
    fixture = TestBed.createComponent(EventComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should set delete to false', () => {
    expect(component.delete).toBeFalsy();
    component.onDelete();
    expect(component.delete).toBeTruthy();
  });

  it('should toggle calender visibility', () => {
    const val = component.displayDatePicker;
    component.toggleCalendar();
    expect(component.displayDatePicker).toBe(!val);
  });

  it('should format date and populate component properties', () => {
    const date = new Date();
    component.formatDateForDisplay(new Date());
    expect(component.dayOfTheMonth).toBe('' + date.getDate());
    expect(component.monthOfTheYear).toBe('' + moment.months()[date.getMonth()].toUpperCase());
  });

  it('should make service call when delete is confirmed', () => {
    component.bookingInfo = TestDataBuilder.getBookingInfo();
    fixture.detectChanges();
    const calendarService = fixture.debugElement.injector.get(CalendarService);
    const spyService = spyOn(calendarService, 'deleteBooking').and.returnValue(Observable.of(''));
    component.onDeleteConfirm();
    expect(spyService).toHaveBeenCalledWith('1');
    expect(component.delete).toBeFalsy();
    component.eventChange.subscribe((value) => {
      expect(value).toBe('delete');
    });
  });

  it('should make service call when delete is confirmed', () => {
    component.bookingInfo = TestDataBuilder.getBookingInfo();
    fixture.detectChanges();
    const calendarService = fixture.debugElement.injector.get(CalendarService);
    spyOn(calendarService, 'deleteBooking').and.returnValue(Observable.throw(TestDataBuilder.getErrorResponse()));
    component.onDeleteConfirm();
    expect(component.message).toBe('Reason for error');
  });

  it('should reset form values correctly', () => {
    component.eventForm.reset();
    expect(component.eventForm.get('shipmentType').value).toBeNull();
    expect(component.eventForm.get('locationType').value).toBeNull();
    component.prePopulatePulldowns();
    expect(component.eventForm.get('shipmentType').value).toBe('Container');
    expect(component.eventForm.get('locationType').value).toBe('ORIGIN');
  });

  it('should open event modal with booking info passed in edit mode', () => {
    component.delete = true;
    component.bookingInfo = null;
    component.openEventModal(TestDataBuilder.getCalEvent());
    expect(component.eventForm.get('shipmentType').value).toBe('Container');
    expect(component.eventForm.get('locationType').value).toBe('ORIGIN');
    expect(component.eventForm.get('orderNumber').value).toBe('orderNumber');
    expect(component.eventForm.get('opportunityNumber').value).toBe('opportunityNumber');
    expect(component.eventForm.get('estimateNumber').value).toBe('estimateNumber');
    expect(component.eventForm.get('customerName').value).toBe('Test Customer');
    expect(component.edit).toBeTruthy();
    expect(component.delete).toBeFalsy();
    expect(component.bookingInfo).not.toBeNull();
    expect(component.title).toBe('Edit Event');
  });

  it('should open event modal with no booking info passed in create mode', () => {
    component.delete = true;
    component.bookingInfo = null;
    component.openEventModal(null);
    expect(component.eventForm.get('shipmentType').value).toBe('Container');
    expect(component.eventForm.get('locationType').value).toBe('ORIGIN');
    expect(component.eventForm.get('orderNumber').value).toBeNull();
    expect(component.eventForm.get('opportunityNumber').value).toBeNull();
    expect(component.eventForm.get('customerName').value).toBeNull();
    expect(component.eventForm.get('estimateNumber').value).toBeNull();
    expect(component.edit).toBeFalsy();
    expect(component.delete).toBeFalsy();
    expect(component.bookingInfo).toBeNull();
    expect(component.title).toBe('New Event');
  });

  it('should clear modal and reset data when clear modal is called', () => {
    component.eventForm.patchValue({'customerName': 'Arjun'});
    component.displayDatePicker = true;
    component.message = 'message';
    component.clearModal();
    expect(component.eventForm.get('shipmentType').value).toBe('Container');
    expect(component.eventForm.get('locationType').value).toBe('ORIGIN');
    expect(component.eventForm.get('customerName').value).toBeNull();
    expect(component.displayDatePicker).toBeFalsy();
    expect(component.message).toBeNull();
  });

  it('should call createBooking in create mode', () => {
    const calendarService = fixture.debugElement.injector.get(CalendarService);
    const spyService = spyOn(calendarService, 'createBooking').and.returnValue(Observable.of(''));
    component.onSubmit();
    expect(spyService).toHaveBeenCalled();
    component.eventChange.subscribe((value) => {
      expect(value).toBe('create');
    });
  });

  it('should update message when createBooking throws error', () => {
    const calendarService = fixture.debugElement.injector.get(CalendarService);
    const spyService = spyOn(calendarService, 'createBooking').and.returnValue(Observable.throw(TestDataBuilder.getErrorResponse()));
    component.onSubmit();
    expect(spyService).toHaveBeenCalled();
    expect(component.message).toBe('Reason for error');
  });

  it('should update message when updateBooking throws error', () => {
    component.bookingInfo = TestDataBuilder.getBookingInfo();
    component.edit = true;
    const calendarService = fixture.debugElement.injector.get(CalendarService);
    const spyService = spyOn(calendarService, 'updateBooking').and.returnValue(Observable.throw(TestDataBuilder.getErrorResponse()));
    component.onSubmit();
    expect(spyService).toHaveBeenCalled();
    expect(component.message).toBe('Reason for error');
  });

  it('should call updateBooking in update mode', () => {
    component.bookingInfo = TestDataBuilder.getBookingInfo();
    component.edit = true;
    const calendarService = fixture.debugElement.injector.get(CalendarService);
    const spyService = spyOn(calendarService, 'updateBooking').and.returnValue(Observable.of(''));
    component.onSubmit();
    expect(spyService).toHaveBeenCalled();
    component.eventChange.subscribe((value) => {
      expect(value).toBe('update');
    });
  });

});

class MockCalendarService {

  deleteBooking(id: string) {
  }

  createBooking(date: string, bookingInfo: any) {

  }

  updateBooking(date: string, id: string, bookingInfo: any) {

  }
}

class TestDataBuilder {

  static getCalEvent() {
    const calEvent = new CalEvent();
    calEvent.bookingInformation = TestDataBuilder.getBookingInfo();
    calEvent.date = '2017-01-01';
    calEvent.status = 'BOOKED';
    return calEvent;
  }

  static getBookingInfo() {
    const booking = new BookingInformation();
    booking.id = '1';
    booking.locationType = 'ORIGIN';
    booking.customerName = 'Test Customer';
    booking.orderNumber = 'orderNumber';
    booking.estimateNumber = 'estimateNumber';
    booking.opportunityNumber = 'opportunityNumber';
    return booking;
  }

  static getErrorResponse() {
    const ro = new ResponseOptions();
    ro.body = '{ "message" : "Reason for error" }';
    ro.status = 500;
    return new Response(ro);
  }
}
