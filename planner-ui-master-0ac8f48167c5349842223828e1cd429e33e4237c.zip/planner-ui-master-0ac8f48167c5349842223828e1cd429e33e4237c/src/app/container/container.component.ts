import {Component, OnInit} from '@angular/core';
import {animate, state, style, transition, trigger} from '@angular/animations';
import {FormControl} from '@angular/forms';
import {Location} from './calendar/shared/model/location.model';
import {UserService} from '../shared/service/user.service';
import {Observable} from 'rxjs/Observable';
import {LocationService} from './shared/location.service';
import {Market} from './calendar/shared/model/market.model';
import {Center} from './calendar/shared/model/center.model';

@Component({
  selector: 'app-container',
  templateUrl: './container.component.html',
  styleUrls: ['container.component.scss'],
  animations: [
    trigger('slideMenuState', [
      state('open', style({
        width: '250px', display: 'block'
      })),
      state('close', style({
        width: '0', display: 'none'
      })),
      transition('open => close', animate('200ms ease-in')),
      transition('close => open', animate('300ms ease-out'))
    ])]
})
export class ContainerComponent implements OnInit {

  slideMenuState = 'close';
  filteredLocations: Location[];
  locationControl: FormControl;
  locations: Location[];
  isHQUser: boolean;
  currentLocation: Location;

  constructor(private userService: UserService,
              private locationService: LocationService) {
  }

  ngOnInit() {

    this.isHQUser = this.userService.isHqUser();
    this.locationControl = new FormControl();
    this.loadLocations();
    this.chooseDefaultLocation();
  }

  loadLocations() {
    Observable.zip(this.locationService.centersSubscribe, this.locationService.marketsSubscribe).subscribe((values) => {
      this.locations = [];
      this.sortMarketsAndCenters(values[0], values[1]);
    });
  }

  sortMarketsAndCenters(centers: Center[], markets: Market[]) {
    const centerMap: Map<string, string> = new Map();
    markets.forEach((market) => {
      market.locationCode = 'M';
      market.displayName = market.marketName;
      this.locations.push(market);
      const marketCenters = centers.filter((center) =>
        center.marketId === market.id
      );
      marketCenters.forEach((center) => {
        center.locationCode = 'C';
        center.displayName = center.centerCode + ' (' + center.centerName + ')';
        this.locations.push(center);
        centerMap.set(center.id, center.displayName);
      });
    });
    this.locationService.setCenterDisplayNameMap(centerMap);
  }

  chooseDefaultLocation() {
    if (this.locations.length > 0) {
      const locationId = JSON.parse(sessionStorage.getItem('location'));
      const location = this.locations.find(loc =>
        loc.id === locationId
      );

      if (location) {
        this.setCurrentLocation(location);
      } else {
        if (!this.isHQUser) {
          this.determineMyCentersLocation();
        } else {
          this.setCurrentLocation(this.locations[0]);
        }
      }
      this.locationControl.patchValue(this.currentLocation);
    }
  }

  determineMyCentersLocation() {
    const myLocation = this.locations.find(loc =>
      loc.id === this.userService.getCenterId()
    );
    if (myLocation) {
      this.setCurrentLocation(myLocation);
    } else {
      this.setCurrentLocation(this.locations[0]);
    }
  }

  onLocationSelect(event) {
    this.setCurrentLocation(event);
  }

  setCurrentLocation(location: Location) {
    this.locationService.setCurrentLocation(location);
    sessionStorage.setItem('location', JSON.stringify(location.id));
    this.currentLocation = location;
  }

  slideMenuToggle(): void {
    this.slideMenuState = this.slideMenuState === 'open' ? 'close' : 'open';
  }

  filterCenterHandler(event) {
    this.filteredLocations = this.filterLocations(event.query);
  }

  filterLocations(query): Location[] {
    const filtered: Location[] = [];
    for (let i = 0; i < this.locations.length; i++) {
      const location = this.locations[i];
      if (location.displayName.toLowerCase().indexOf(query.toLowerCase()) >= 0) {
        filtered.push(location);
      }
    }
    return filtered;
  }

  handleCenterDropdown() {
    this.filteredLocations = [];
    setTimeout(() => {
      this.filteredLocations = this.locations;
    }, 100);
  }
}
