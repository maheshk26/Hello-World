import {ContainerComponent} from './container.component';
import {RouterModule, Routes} from '@angular/router';
import {AuthGuard} from '../shared/service/auth-gaurd.service';
import {adminRoutes} from './admin/admin.routes';
import {calendarRoutes} from './calendar/calendar.routes';
import {LocationResolve} from './shared/location.resolve';

const routes: Routes = [
  {
    path: '',
    component: ContainerComponent,
    children: [
      ...adminRoutes,
      ...calendarRoutes,
      {
        path: '',
        redirectTo: 'calendar',
        pathMatch: 'full'
      }
    ],
    canActivate: [AuthGuard],
    resolve: {
      locations: LocationResolve
    }
  }
];

export const containerRouting = RouterModule.forChild(routes);
