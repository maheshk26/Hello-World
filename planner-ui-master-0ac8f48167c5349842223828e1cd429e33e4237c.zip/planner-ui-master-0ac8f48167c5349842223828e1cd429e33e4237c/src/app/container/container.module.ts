import {AdminModule} from './admin/admin.module';
import {containerRouting} from './container.routes';
import {NgModule} from '@angular/core';
import {ContainerComponent} from './container.component';
import {CrewCalendarModule} from './calendar/calendar.module';
import {SharedModule} from '../shared/shared.module';
import {Daterangepicker} from 'ng2-daterangepicker';
import {Http, RequestOptions, XHRBackend} from '@angular/http';
import {getHttpImplByRole} from './shared/http.factory';
import {UserService} from '../shared/service/user.service';
import {LocationService} from './shared/location.service';
import {LocationResolve} from './shared/location.resolve';
import {AutoCompleteModule} from 'primeng/primeng';

@NgModule({
  imports: [
    SharedModule,
    CrewCalendarModule,
    AdminModule,
    containerRouting,
    Daterangepicker,
    AutoCompleteModule
  ],
  declarations: [ContainerComponent],
  providers: [
    {
      provide: Http,
      useFactory: getHttpImplByRole,
      deps: [XHRBackend, RequestOptions, UserService]
    },
    LocationService,
    LocationResolve
  ]
})
export class ContainerModule {
}
