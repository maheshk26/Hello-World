import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {ContainerComponent} from './container.component';
import {RouterTestingModule} from '@angular/router/testing';
import {NoopAnimationsModule} from '@angular/platform-browser/animations';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {UserService} from '../shared/service/user.service';
import {LocationService} from './shared/location.service';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {Center} from './calendar/shared/model/center.model';
import {Market} from './calendar/shared/model/market.model';
import {Location} from './calendar/shared/model/location.model';

describe('Component: ContainerComponent', () => {
  let component: ContainerComponent;
  let fixture: ComponentFixture<ContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, NoopAnimationsModule],
      declarations: [ContainerComponent],
      providers: [
        {provide: UserService, useClass: MockUserService},
        {provide: LocationService, useClass: MockLocationService}
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should toggle slideMenuState', () => {
    expect(component.slideMenuState).toBe('close');
    component.slideMenuToggle();
    expect(component.slideMenuState).toBe('open');
  });

  it('should create component for user', () => {
    fixture = TestBed.createComponent(ContainerComponent);
    fixture.whenStable().then(() => {
      component = fixture.componentInstance;
      fixture.detectChanges();
      expect(component).toBeTruthy();
    });
  });

  it('should filter centers on user input - type ahead', async(() => {
    fixture = TestBed.createComponent(ContainerComponent);
    fixture.whenStable().then(() => {
      component = fixture.componentInstance;
      fixture.detectChanges();
      expect(component).toBeTruthy();
      const filteredLocations = component.filterLocations('CTRSTL01');
      expect(filteredLocations.length).toBe(1);
    });
  }));

  it('should set current location for hq user to first market', () => {
    const service = fixture.debugElement.injector.get(UserService);
    const spy = spyOn(service, 'isHqUser').and.returnValue(true);
    sessionStorage.clear();
    fixture = TestBed.createComponent(ContainerComponent);
    fixture.whenStable().then(() => {
      component = fixture.componentInstance;
      fixture.detectChanges();
      expect(component.currentLocation.displayName).toBe(TestDataBuilder.getMarkets()[0].marketName);
    });
  });

  it('should set current location to own center for center user', () => {
    sessionStorage.removeItem('location');
    const service = fixture.debugElement.injector.get(UserService);
    const spy = spyOn(service, 'getCenterId').and.returnValue('center1');

    fixture = TestBed.createComponent(ContainerComponent);
    fixture.whenStable().then(() => {
      component = fixture.componentInstance;
      fixture.detectChanges();
      expect(component.currentLocation.id).toBe(TestDataBuilder.getCenters()[0].id);
    });
  });

});

class MockUserService {
  isHqUser() {
    return false;
  }

  getCenterId() {
    return '1';
  }
}

class MockLocationService {

  centersSubscribe: BehaviorSubject<Center[]> = new BehaviorSubject(TestDataBuilder.getCenters());
  marketsSubscribe: BehaviorSubject<Market[]> = new BehaviorSubject(TestDataBuilder.getMarkets());

  setCenterDisplayNameMap(centersMap: Map<string, string>) {
  }

  setCurrentLocation(location: Location) {

  }

}

class TestDataBuilder {
  static getCenters(): Center[] {

    const center1 = new Center();
    center1.centerCode = 'CTRSTL01';
    center1.centerName = 'St. Louis Center 1';
    center1.marketId = '1';
    center1.id = 'center1';

    const center2 = new Center();
    center2.centerCode = 'CTRSTL02';
    center2.centerName = 'St. Louis Center 2';
    center2.marketId = '1';
    center2.id = 'center2';

    return [center1, center2];
  }

  static getMarkets(): Market[] {

    const market1 = new Market();
    market1.marketName = 'M001';
    market1.id = '1';

    const market2 = new Market();
    market2.marketName = 'M002';
    market2.id = '2';

    return [market1, market2];
  }
}
