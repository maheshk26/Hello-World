import {NgModule} from '@angular/core';
import {LoginComponent} from './login.component';
import {loginRoutes} from './login.routes';
import {SharedModule} from '../shared/shared.module';
import {LoginService} from './shared/login.service';

@NgModule({
  imports: [
    loginRoutes,
    SharedModule
  ],
  declarations: [
    LoginComponent
  ],
  providers: [
    LoginService
  ]
})
export class LoginModule {
}
