import {inject, TestBed} from '@angular/core/testing';
import {HttpModule, RequestMethod, Response, ResponseOptions, XHRBackend} from '@angular/http';
import {LoginService} from './login.service';
import {MockBackend} from '@angular/http/testing';
import {Observable} from 'rxjs/Observable';
describe('Service: Login Service', () => {

  let service, mockBackend;

  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpModule],
    providers: [
      LoginService,
      {provide: XHRBackend, useClass: MockBackend}
    ]
  }));

  beforeEach((inject([LoginService, XHRBackend], (_service, _mockBackend) => {
    service = _service;
    mockBackend = _mockBackend;
  })));

  it('it should be available', () => {
    expect(service).toBeTruthy();
  });

  it('should return observable when getEvents is called', () => {
    expect(service.authenticate({})).toEqual(jasmine.any(Observable));
  });

  it('should return user object when authenticate is called', () => {
    mockBackend.connections.subscribe(connection => {
      expect(connection.request.method).toBe(RequestMethod.Post);
      expect(connection.request.getBody()).toContain('username');
      expect(connection.request.getBody()).toContain('password');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 200,
        body: JSON.stringify(TestDataBuilder.getLoginResponse())
      })));
    });
    expect(service.authenticate(TestDataBuilder.getLoginRequest()).subscribe(
      (user) => {
        expect(user['username']).toContain('UNIGROUP');
      }));
  });

});

class TestDataBuilder {

  static getLoginRequest() {
    return {
      'username': 'username',
      'password': 'password'
    };
  }

  static getLoginResponse() {
    const obj: any = {};
    obj.user = '{\"userId\":\"e0feca43f9ab5bf133e9244cb0133046\",\"username\":\"UNIGROUP\",\"centerId\":null,\"hqUser\":true}';
    return obj;
  }
}
