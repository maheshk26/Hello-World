import {Injectable} from '@angular/core';
import {Http} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import {User} from '../../shared/model/user.model';

@Injectable()
export class LoginService {

  constructor(private http: Http) {
  }

  authenticate(user: any): Observable<User> {

    return this.http.post('/api/auth/login', user).map(response => {
      return JSON.parse(response.json().user);
    });
  }

}
