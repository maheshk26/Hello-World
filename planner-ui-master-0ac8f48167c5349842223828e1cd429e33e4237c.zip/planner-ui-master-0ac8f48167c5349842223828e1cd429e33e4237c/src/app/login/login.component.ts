import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {Router} from '@angular/router';
import {LoginService} from './shared/login.service';
import {UserService} from '../shared/service/user.service';

@Component({
  selector: 'app-login',
  templateUrl: 'login.component.html',
  styleUrls: ['login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  errorMessage: string;

  constructor(private fb: FormBuilder,
              private router: Router,
              private loginService: LoginService,
              private userService: UserService) {

  }

  ngOnInit() {
    if (this.userService.isLoggedIn()) {
      this.goToCalendar();
    }
    this.buildForm();
  }

  buildForm(): void {
    this.loginForm = this.fb.group({
      'username': ['', [Validators.required]],
      'password': ['', [Validators.required]]
    });
  };

  onSubmit() {
    this.errorMessage = null;
    this.loginService.authenticate(this.loginForm.value)
      .subscribe(
        (user) => {
          this.userService.loginHandler(user);
          this.goToCalendar();
        },
        (error) => {
          this.errorMessage = error.json().message;
        }
      );
  }

  goToCalendar() {
    this.router.navigateByUrl('app');
  }

}
