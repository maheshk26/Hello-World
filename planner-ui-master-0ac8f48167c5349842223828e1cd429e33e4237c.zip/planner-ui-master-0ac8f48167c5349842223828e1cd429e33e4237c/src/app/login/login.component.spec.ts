/* tslint:disable:no-unused-variable */
import {async, ComponentFixture, fakeAsync, TestBed, tick} from '@angular/core/testing';
import {LoginComponent} from './login.component';
import {RouterTestingModule} from '@angular/router/testing';
import {ReactiveFormsModule} from '@angular/forms';
import {LoginService} from './shared/login.service';
import {UserService} from '../shared/service/user.service';
import {Router} from '@angular/router';
import {LoginModule} from './login.module';
import {User} from '../shared/model/user.model';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/observable/throw';

import Spy = jasmine;
import {ResponseOptions} from '@angular/http';

describe('Component: LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        LoginModule,
        RouterTestingModule,
        ReactiveFormsModule],
      providers: [
        {provide: LoginService, useClass: MockLoginService},
        {provide: UserService, useClass: MockUserService}
      ]
    }).compileComponents();
  }));

  beforeEach(async(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create the component', async(() => {
    expect(component).toBeTruthy();
  }));

  it('should go to component calendar', async(() => {
    const userService = fixture.debugElement.injector.get(UserService);
    spyOn(userService, 'isLoggedIn').and.returnValue(true);
    const router = fixture.debugElement.injector.get(Router);
    const spyRouter = spyOn(router, 'navigateByUrl');
    component.goToCalendar();
    expect(spyRouter).toHaveBeenCalledWith('app');
  }));

  it('should call login service when onSubmit is called', async(() => {
    const userService = fixture.debugElement.injector.get(UserService);
    const spyUserService = spyOn(userService, 'loginHandler');
    const router = fixture.debugElement.injector.get(Router);
    const spyRouter = spyOn(router, 'navigateByUrl');
    const user = TestDataBuilder.getUser();
    const loginService = fixture.debugElement.injector.get(LoginService);
    const spyLoginService = spyOn(loginService, 'authenticate')
      .and.returnValue(Observable.of(TestDataBuilder.getUser()));
    component.loginForm.patchValue({
      'username': 'user',
      'password': 'password'
    });
    component.errorMessage = 'Error message';
    component.onSubmit();
    expect(spyRouter).toHaveBeenCalledWith('app');
    expect(component.errorMessage).toBeNull();
    expect(spyLoginService).toHaveBeenCalled();
    expect(spyUserService).toHaveBeenCalledWith(user);
  }));


  it('should update error message when onSubmit errors', fakeAsync(() => {
    const loginService = fixture.debugElement.injector.get(LoginService);
    const spyService = spyOn(loginService, 'authenticate')
      .and.returnValue(Observable.throw(TestDataBuilder.getErrorResponse()));
    component.errorMessage = 'Error message';
    component.onSubmit();
    tick();
    expect(spyService).toHaveBeenCalled();
  }));

});

class MockLoginService {

  authenticate(value: any) {}

}

class MockUserService {

  isLoggedIn(): boolean {
    return false;
  }

  loginHandler(user: User) {

  }

}

class TestDataBuilder {

  static getUser(): User {
    const user = new User();
    user.username = 'Test User';
    return user;
  }

  static getErrorResponse(): Response {
    const ro = new ResponseOptions();
    ro.body = '{ "message" : "Reason for error" }';
    ro.status = 500;
    return new Response(ro);
  }
}
