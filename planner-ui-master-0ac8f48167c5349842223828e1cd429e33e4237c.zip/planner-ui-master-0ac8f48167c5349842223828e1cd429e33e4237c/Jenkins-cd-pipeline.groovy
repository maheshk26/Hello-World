node('unigroup-jenkins-slave-nodejs') {

  try {

    def gitUrl = "git@gitee.unigroupinc.com:planner/planner-ui.git"

    def appName = "plannerui"

    def devProject = readFile("../../../run/secrets/kubernetes.io/serviceaccount/namespace")

    def stgProject = devProject.replaceFirst(/dev$/, "stg")

    def token = readFile('/var/run/secrets/kubernetes.io/serviceaccount/token').trim()

    def numberrOfIntervals = "120"

    def intervalSleepSec = "5"

    println "stgProject = ${stgProject}"

    //git url: gitUrl
    git url: gitUrl, credentialsId: "${appName}dev-jenkins-deploy-key"

    // Build
    stage('Install') {
      sh "node -v"
      sh "npm prune"
      sh "npm install"
    }

    // Unit Tests
    stage('Unit Tests') {
      sh "npm run test-pipeline"
      println "Unit tests just ran fine..!"
    }

    // Build
    stage('Build') {
      sh "npm run build"
      println "Build succeeded!"
    }

    //DEV
    stage('Deploy DEV') {
      buildAndInstall(appName, devProject, "html")
      openshiftCheckService(token, appName, devProject, numberrOfIntervals, intervalSleepSec)

      // Arjun Curat
      mail body: "Application ${appName} is ready for Stage deploy.", from: 'Jenkins@devunigroup01', subject: "Application ${appName} is ready for Stage deployment.", to: 'TAZC2@unigroupinc.com'
    }

    // Integration Tests
    stage('Integration Tests') {
      sh "npm run pree2e"
      sh "npm run e2e-pipeline"
      println "Integration tests just ran fine..!"
    }

    // Stage
    stage('Deploy STAGE') {
      promoteLatest(appName, devProject, stgProject)
      openshiftCheckService(token, appName, stgProject, numberrOfIntervals, intervalSleepSec)

      // Arjun Curat
      mail body: "Application ${appName} is ready for Production deploy.", from: 'Jenkins@devunigroup01', subject: "Application ${appName} is ready for Production deployment.", to: 'TAZC2@unigroupinc.com'
    }

  } catch (err) {

    currentBuild.result = "FAILURE"

    mail body: "Planner UI failed in the pipeline",
      from: 'Jenkins@devunigroup01',
      subject: 'Planner UI build failed',
      to: 'TAZC2@unigroupinc.com'

    throw err
  }

}
